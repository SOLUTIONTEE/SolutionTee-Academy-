"""Configuration for SolutionTee Edu Academy.

Every credential is read from the environment. Nothing sensitive is
hard-coded here, and nothing sensitive belongs in .env.example either.

Choose a configuration with FLASK_ENV=development|production|testing.
"""
from __future__ import annotations

import os
from datetime import timedelta
from pathlib import Path

try:
    from dotenv import load_dotenv
except ModuleNotFoundError:  # dotenv is optional; real env vars still work
    def load_dotenv(*_args, **_kwargs):
        return False

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _str(name: str, default: str = "") -> str:
    """Read a string, tolerating quotes pasted in from a shell."""
    value = (os.getenv(name) or default).strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1]
    return value


def _bool(name: str, default: bool = False) -> bool:
    """Read a boolean. A blank value counts as unset and falls back.

    Without this, a bare `KEY=` in .env would read as False and silently
    override a default of True.
    """
    raw = (os.getenv(name) or "").strip()
    if not raw:
        return default
    return raw.lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    try:
        return int((os.getenv(name) or "").strip() or default)
    except (TypeError, ValueError):
        return default


def _database_url(value: str) -> str:
    """Normalise a provider URL onto the psycopg 3 driver.

    Railway hands out a bare ``postgresql://`` scheme, which SQLAlchemy
    resolves to psycopg2. This project installs psycopg 3. Some providers
    still emit the legacy ``postgres://`` scheme, which SQLAlchemy rejects
    outright, so both are rewritten.
    """
    value = (value or "").strip()
    for prefix in ("postgres://", "postgresql://"):
        if value.startswith(prefix):
            return "postgresql+psycopg://" + value[len(prefix):]
    return value


class BaseConfig:
    # -- Core --------------------------------------------------------------
    SECRET_KEY = _str("SECRET_KEY", "dev-only-insecure-key-change-me")
    SECURITY_PASSWORD_SALT = _str("SECURITY_PASSWORD_SALT", "dev-only-insecure-salt")

    # -- Database ----------------------------------------------------------
    # Pool sized for Railway, not for a large dedicated server. Two workers
    # at pool_size 5 plus overflow stays well inside a small plan's limit.
    SQLALCHEMY_DATABASE_URI = _database_url(
        _str("DATABASE_URL", "postgresql://postgres@localhost:5432/solutiontee_edu")
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_size": _int("DB_POOL_SIZE", 5),
        "max_overflow": _int("DB_MAX_OVERFLOW", 5),
        "pool_recycle": _int("DB_POOL_RECYCLE", 1800),
        "pool_timeout": _int("DB_POOL_TIMEOUT", 30),
        "pool_pre_ping": True,
    }

    # -- Session -----------------------------------------------------------
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = False
    PERMANENT_SESSION_LIFETIME = timedelta(hours=_int("SESSION_LIFETIME_HOURS", 12))

    # -- Storage -----------------------------------------------------------
    STORAGE_BACKEND = _str("STORAGE_BACKEND", "local")
    LOCAL_STORAGE_ROOT = _str("LOCAL_STORAGE_ROOT", str(BASE_DIR / "instance" / "media"))
    R2_ACCESS_KEY = _str("R2_ACCESS_KEY")
    R2_SECRET_KEY = _str("R2_SECRET_KEY")
    R2_ENDPOINT = _str("R2_ENDPOINT")
    R2_BUCKET = _str("R2_BUCKET")
    R2_PUBLIC_URL = _str("R2_PUBLIC_URL")
    MAX_CONTENT_LENGTH = _int("MAX_UPLOAD_MB", 25) * 1024 * 1024

    # -- Email -------------------------------------------------------------
    # "console" prints to the terminal so development never sends real mail.
    EMAIL_TRANSPORT = _str("EMAIL_TRANSPORT", "console")
    BREVO_API_KEY = _str("BREVO_API_KEY")
    MAIL_FROM_NAME = _str("MAIL_FROM_NAME", "SolutionTee Edu Academy")
    MAIL_SENDER_NOREPLY = _str("MAIL_SENDER_NOREPLY", "noreply@mail.solutiontee.com")
    MAIL_SENDER_INFO = _str("MAIL_SENDER_INFO", "info@mail.solutiontee.com")
    MAIL_SENDER_SUPPORT = _str("MAIL_SENDER_SUPPORT", "support@mail.solutiontee.com")
    CONTACT_INBOX = _str("CONTACT_INBOX", "info@mail.solutiontee.com")

    # -- Bot protection ----------------------------------------------------
    TURNSTILE_ENABLED = _bool("TURNSTILE_ENABLED", True)
    TURNSTILE_SITE_KEY = _str("TURNSTILE_SITE_KEY")
    TURNSTILE_SECRET_KEY = _str("TURNSTILE_SECRET_KEY")
    TURNSTILE_TIMEOUT = _int("TURNSTILE_TIMEOUT", 6)

    # -- Payments ----------------------------------------------------------
    PAYSTACK_PUBLIC_KEY = _str("PAYSTACK_PUBLIC_KEY")
    PAYSTACK_SECRET_KEY = _str("PAYSTACK_SECRET_KEY")
    PAYSTACK_WEBHOOK_SECRET = _str("PAYSTACK_WEBHOOK_SECRET")
    PAYSTACK_CURRENCY = _str("PAYSTACK_CURRENCY", "NGN")

    # -- Identity policy ---------------------------------------------------
    OTP_TTL_MINUTES = _int("OTP_TTL_MINUTES", 10)
    OTP_MAX_ATTEMPTS = _int("OTP_MAX_ATTEMPTS", 5)
    OTP_RESEND_COOLDOWN_SECONDS = _int("OTP_RESEND_COOLDOWN_SECONDS", 60)
    MINOR_AGE_THRESHOLD = _int("MINOR_AGE_THRESHOLD", 18)

    # -- Rate limiting / caching -------------------------------------------
    # memory:// is per-process. With more than one Gunicorn worker each
    # worker keeps its own counters, so production wants a shared backend.
    RATELIMIT_STORAGE_URI = _str("RATELIMIT_STORAGE_URI", "memory://")
    RATELIMIT_ENABLED = True
    CACHE_TYPE = "SimpleCache"
    CACHE_DEFAULT_TIMEOUT = _int("CACHE_DEFAULT_TIMEOUT", 300)

    # -- Organisation ------------------------------------------------------
    # Factual detail. Do not invent or alter without the developer's word.
    ORG_NAME = "SolutionTee Edu Academy"
    ORG_SHORT_NAME = "SolutionTee"
    ORG_TAGLINE = "Learn. Think. Solve."
    TIMEZONE = "Africa/Lagos"

    LOG_LEVEL = _str("LOG_LEVEL", "INFO")
    FORCE_HTTPS = False


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    TEMPLATES_AUTO_RELOAD = True


class ConfigurationError(RuntimeError):
    """Production is configured in a way that must not be allowed to boot."""


class ProductionConfig(BaseConfig):
    DEBUG = False
    SESSION_COOKIE_SECURE = True
    FORCE_HTTPS = _bool("FORCE_HTTPS", True)
    PREFERRED_URL_SCHEME = "https"


class TestingConfig(BaseConfig):
    TESTING = True
    # Pool options are PostgreSQL-specific; SQLite raises on them. The
    # isolated test suite may run on SQLite, so it takes engine defaults.
    SQLALCHEMY_ENGINE_OPTIONS: dict = {}
    DEBUG = False
    WTF_CSRF_ENABLED = False
    RATELIMIT_ENABLED = False
    EMAIL_TRANSPORT = "console"
    TURNSTILE_ENABLED = False
    STORAGE_BACKEND = "local"
    SQLALCHEMY_DATABASE_URI = _database_url(
        _str("TEST_DATABASE_URL",
             "postgresql://postgres@localhost:5432/solutiontee_edu_test")
    )


_CONFIGS = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
}


def check_production_config(config) -> None:
    """Refuse to start production with a configuration that cannot be safe.

    A guard rather than a test, because the thing being guarded against
    is an environment variable - something no test can see at the moment
    it actually matters. Failing loudly at boot is far better than
    serving traffic from a SQLite file that vanishes on the next deploy,
    or signing sessions with the development key.
    """
    problems = []

    uri = (config.SQLALCHEMY_DATABASE_URI or "").lower()
    if not uri:
        problems.append("DATABASE_URL is not set")
    elif not uri.startswith("postgresql"):
        # Deliberately reports the scheme only. The URL holds a password.
        scheme = uri.split("://", 1)[0] or "(none)"
        problems.append(
            f"DATABASE_URL must be PostgreSQL in production, got {scheme!r}"
        )

    if config.SECRET_KEY == "dev-only-insecure-key-change-me":
        problems.append("SECRET_KEY is still the development default")
    if config.SECURITY_PASSWORD_SALT == "dev-only-insecure-salt":
        problems.append("SECURITY_PASSWORD_SALT is still the development default")

    if problems:
        raise ConfigurationError(
            "Refusing to start in production: " + "; ".join(problems)
        )


def get_config(name: str | None = None):
    key = (name or os.getenv("FLASK_ENV") or "development").strip().lower()
    config = _CONFIGS.get(key, DevelopmentConfig)
    if key == "production":
        check_production_config(config)
    return config
