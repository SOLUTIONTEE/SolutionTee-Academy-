"""WSGI entry point. Gunicorn on Railway loads `application` from here."""
from app import create_app

application = create_app()
app = application
