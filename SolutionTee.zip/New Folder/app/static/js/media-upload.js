/* Batch media upload.
   =========================================================================
   Each file is posted on its own request and tracked independently, so
   one rejected image among forty never discards the other thirty-nine.
   Uploads run a few at a time rather than all at once: forty parallel
   requests on a Nigerian mobile connection is slower than four, and it
   is a good way to be rate-limited.

   Progressive enhancement. The form works without this script - it just
   posts one file at a time - so a failure here degrades rather than
   breaks.
   ====================================================================== */
(function () {
  'use strict';

  var form = document.querySelector('[data-dropzone]');
  if (!form || !window.FormData || !window.XMLHttpRequest) { return; }

  var input = form.querySelector('[data-file-input]');
  var queue = document.querySelector('[data-upload-queue]');
  var list = document.querySelector('[data-queue-list]');
  var summary = document.querySelector('[data-queue-summary]');
  var live = document.querySelector('[data-queue-live]');
  var bar = document.querySelector('[data-queue-progress]');
  var clearBtn = document.querySelector('[data-queue-clear]');

  var MAX_PARALLEL = 3;
  var pending = [];
  var active = 0;
  var counts = {total: 0, done: 0, failed: 0};

  /* ---- Queue rendering -------------------------------------------------- */

  function humanSize(bytes) {
    if (bytes < 1024) { return bytes + 'B'; }
    if (bytes < 1024 * 1024) { return Math.round(bytes / 1024) + 'KB'; }
    return (bytes / (1024 * 1024)).toFixed(1) + 'MB';
  }

  function addRow(file) {
    var row = document.createElement('li');
    row.className = 'queue-item is-waiting';

    var name = document.createElement('span');
    name.className = 'queue-item__name';
    name.textContent = file.name;

    var size = document.createElement('span');
    size.className = 'queue-item__size';
    size.textContent = humanSize(file.size);

    var state = document.createElement('span');
    state.className = 'queue-item__state';
    state.textContent = 'Waiting';

    row.appendChild(name);
    row.appendChild(size);
    row.appendChild(state);
    list.appendChild(row);

    return {row: row, state: state};
  }

  function setState(entry, cls, text) {
    entry.row.className = 'queue-item ' + cls;
    entry.state.textContent = text;
  }

  function updateSummary() {
    var finished = counts.done + counts.failed;
    if (summary) {
      summary.textContent = finished < counts.total
        ? 'Uploading ' + (finished + 1) + ' of ' + counts.total
        : 'Finished ' + counts.total + ' file' + (counts.total === 1 ? '' : 's')
          + (counts.failed ? ' — ' + counts.failed + ' failed' : '');
    }
    if (bar) {
      var pct = counts.total ? Math.round((finished / counts.total) * 100) : 0;
      bar.style.width = pct + '%';
    }
    /* Announced only on completion: a per-file announcement during a
       forty-image batch would flood a screen reader. */
    if (live && finished === counts.total && counts.total > 0) {
      live.textContent = 'Upload finished. ' + counts.done + ' succeeded'
        + (counts.failed ? ', ' + counts.failed + ' failed' : '') + '.';
    }
  }

  /* ---- Transfer --------------------------------------------------------- */

  function send(job) {
    var data = new FormData();
    data.append('file', job.file);
    var csrf = form.querySelector('[name=csrf_token]');
    if (csrf) { data.append('csrf_token', csrf.value); }
    var folder = form.querySelector('[name=folder]');
    if (folder) { data.append('folder', folder.value); }

    var xhr = new XMLHttpRequest();
    xhr.open('POST', form.action, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    xhr.upload.addEventListener('progress', function (event) {
      if (!event.lengthComputable) { return; }
      var pct = Math.round((event.loaded / event.total) * 100);
      setState(job.entry, 'is-uploading', pct + '%');
    });

    xhr.addEventListener('load', function () {
      var payload = null;
      try { payload = JSON.parse(xhr.responseText); } catch (e) { payload = null; }

      if (xhr.status >= 200 && xhr.status < 300 && payload && payload.ok) {
        counts.done += 1;
        var reused = payload.media && payload.media.public_id
                     && xhr.getResponseHeader('X-Media-Reused');
        setState(job.entry, 'is-done', reused ? 'Already stored' : 'Uploaded');
        if (payload.media && payload.media.needs_alt_text) {
          var warn = document.createElement('a');
          warn.className = 'queue-item__alt';
          warn.href = payload.media.detail_url;
          warn.textContent = 'Add alt text';
          job.entry.row.appendChild(warn);
        }
      } else {
        counts.failed += 1;
        var message = (payload && payload.error) || 'Upload failed';
        setState(job.entry, 'is-failed', message);
        addRetry(job);
      }
      finish();
    });

    xhr.addEventListener('error', function () {
      counts.failed += 1;
      setState(job.entry, 'is-failed', 'Network error');
      addRetry(job);
      finish();
    });

    xhr.addEventListener('abort', function () {
      counts.failed += 1;
      setState(job.entry, 'is-failed', 'Cancelled');
      finish();
    });

    xhr.send(data);
  }

  function addRetry(job) {
    if (job.entry.row.querySelector('[data-retry]')) { return; }
    var retry = document.createElement('button');
    retry.type = 'button';
    retry.className = 'queue-item__retry';
    retry.setAttribute('data-retry', '');
    retry.textContent = 'Retry';
    retry.addEventListener('click', function () {
      retry.remove();
      counts.failed -= 1;
      setState(job.entry, 'is-waiting', 'Waiting');
      pending.push(job);
      updateSummary();
      pump();
    });
    job.entry.row.appendChild(retry);
  }

  function finish() {
    active -= 1;
    updateSummary();
    pump();
  }

  function pump() {
    while (active < MAX_PARALLEL && pending.length) {
      var job = pending.shift();
      active += 1;
      setState(job.entry, 'is-uploading', 'Starting');
      send(job);
    }
  }

  /* ---- Intake ----------------------------------------------------------- */

  function enqueue(files) {
    if (!files || !files.length) { return; }
    if (queue) { queue.hidden = false; }

    for (var i = 0; i < files.length; i += 1) {
      var file = files[i];
      /* Filter obvious non-images here purely to save the round trip.
         The server re-checks by decoding the file: a browser-reported
         type is a hint, never a guarantee. */
      if (file.type && file.type.indexOf('image/') !== 0) {
        counts.total += 1;
        counts.failed += 1;
        setState(addRow(file), 'is-failed', 'Not an image');
        continue;
      }
      counts.total += 1;
      pending.push({file: file, entry: addRow(file)});
    }
    updateSummary();
    pump();
  }

  if (input) {
    input.addEventListener('change', function () {
      enqueue(input.files);
      // Lets the same file be chosen again after a failure.
      input.value = '';
    });
  }

  /* ---- Drag and drop ---------------------------------------------------- */

  ['dragenter', 'dragover'].forEach(function (name) {
    form.addEventListener(name, function (event) {
      event.preventDefault();
      form.classList.add('is-dragging');
    });
  });

  ['dragleave', 'drop'].forEach(function (name) {
    form.addEventListener(name, function (event) {
      event.preventDefault();
      // dragleave fires when crossing a child element, so only drop and
      // a genuine exit clear the state.
      if (name === 'drop' || !form.contains(event.relatedTarget)) {
        form.classList.remove('is-dragging');
      }
    });
  });

  form.addEventListener('drop', function (event) {
    if (event.dataTransfer && event.dataTransfer.files) {
      enqueue(event.dataTransfer.files);
    }
  });

  // The script handles submission; the plain form post is the no-JS path.
  form.addEventListener('submit', function (event) {
    if (input && input.files && input.files.length) {
      event.preventDefault();
      enqueue(input.files);
      input.value = '';
    }
  });

  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      list.querySelectorAll('.is-done').forEach(function (row) {
        row.remove();
      });
      if (!list.children.length && queue) {
        queue.hidden = true;
        counts = {total: 0, done: 0, failed: 0};
        updateSummary();
      }
    });
  }

  /* A batch mid-flight is lost on navigation, and the browser's own
     confirm dialog is the only thing that can prevent it. */
  window.addEventListener('beforeunload', function (event) {
    if (active > 0 || pending.length) {
      event.preventDefault();
      event.returnValue = '';
    }
  });
}());
