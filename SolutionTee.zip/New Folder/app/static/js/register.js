/* Registration form: show the guardian fields only when they apply.
   =========================================================================
   Convenience only. Whether a guardian address is actually required is
   decided on the server, in RegisterForm.validate_guardian_email - a
   student cannot skip consent by disabling JavaScript, and the fields
   are visible by default so a failed script never hides a required
   input.
   ====================================================================== */
(function () {
  'use strict';

  var form = document.querySelector('[data-register-form]');
  if (!form) { return; }

  var wrapper = form.querySelector('[data-guardian-fields]');
  var types = form.querySelectorAll('[data-account-type]');
  var dob = form.querySelector('#date_of_birth');
  if (!wrapper || !types.length) { return; }

  var threshold = parseInt(wrapper.getAttribute('data-threshold'), 10) || 18;

  function selectedType() {
    for (var i = 0; i < types.length; i += 1) {
      if (types[i].checked) { return types[i].value; }
    }
    return '';
  }

  function ageFrom(value) {
    if (!value) { return null; }
    var born = new Date(value);
    if (isNaN(born.getTime())) { return null; }
    var today = new Date();
    var years = today.getFullYear() - born.getFullYear();
    var monthDelta = today.getMonth() - born.getMonth();
    if (monthDelta < 0 || (monthDelta === 0 && today.getDate() < born.getDate())) {
      years -= 1;
    }
    return years;
  }

  function update() {
    var isStudent = selectedType() === 'student';
    var years = dob ? ageFrom(dob.value) : null;
    /* An unknown date of birth keeps the fields visible: the server
       treats unknown as a minor, so hiding them would guarantee a
       validation error the person could not see the cause of. */
    var needed = isStudent && (years === null || years < threshold);
    wrapper.hidden = !needed;
  }

  types.forEach(function (input) {
    input.addEventListener('change', update);
  });
  if (dob) { dob.addEventListener('change', update); }

  update();
}());
