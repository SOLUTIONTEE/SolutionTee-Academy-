/* Media picker.
   =========================================================================
   One dialog, shared by every image field on the page. The field that
   opened it is remembered, and the chosen image is written back into
   that field only.

   Built on the native <dialog>: showModal() supplies focus trapping,
   Escape-to-close, background inertness and top-layer stacking, none of
   which is reimplemented here.

   Without JavaScript the fields still render their current image and the
   form still submits, so a failure here loses the ability to change an
   image - not the page.
   ====================================================================== */
(function () {
  'use strict';

  var dialog = document.querySelector('[data-picker]');
  if (!dialog || typeof dialog.showModal !== 'function') { return; }

  var results = dialog.querySelector('[data-picker-results]');
  var search = dialog.querySelector('[data-picker-search]');
  var folder = dialog.querySelector('[data-picker-folder]');
  var uploadInput = dialog.querySelector('[data-picker-upload]');
  var uploadStatus = dialog.querySelector('[data-picker-uploading]');
  var closeBtn = dialog.querySelector('[data-picker-close]');

  var activeField = null;
  var searchTimer = null;
  /* Every fetch carries a token; a response whose token is stale is
     discarded. Without this, a slow "cbt" response can land after a
     fast "waec" one and show the wrong results for the query on screen. */
  var requestToken = 0;

  /* ---- Fetching --------------------------------------------------------- */

  function buildUrl(page) {
    var params = new URLSearchParams();
    if (search && search.value.trim()) { params.set('q', search.value.trim()); }
    if (folder && folder.value) { params.set('folder', folder.value); }
    if (page && page > 1) { params.set('page', page); }
    var query = params.toString();
    return '/admin/media/picker' + (query ? '?' + query : '');
  }

  function load(page, append) {
    var token = ++requestToken;
    results.setAttribute('aria-busy', 'true');
    if (!append) { results.innerHTML = '<p class="picker__loading">Loading…</p>'; }

    fetch(buildUrl(page), {
      headers: {'X-Requested-With': 'XMLHttpRequest'},
      credentials: 'same-origin'
    })
      .then(function (response) {
        if (!response.ok) { throw new Error('HTTP ' + response.status); }
        return response.text();
      })
      .then(function (html) {
        if (token !== requestToken) { return; }  // superseded
        if (append) {
          var more = results.querySelector('[data-picker-more]');
          var host = document.createElement('div');
          host.innerHTML = html;
          var grid = results.querySelector('.picker-grid');
          var newGrid = host.querySelector('.picker-grid');
          if (grid && newGrid) {
            while (newGrid.firstChild) { grid.appendChild(newGrid.firstChild); }
            var status = results.querySelector('.picker-status');
            var newStatus = host.querySelector('.picker-status');
            if (status) { status.remove(); }
            if (newStatus) { results.appendChild(newStatus); }
          }
          if (more && !host.querySelector('[data-picker-more]')) { more.remove(); }
        } else {
          results.innerHTML = html;
        }
        results.setAttribute('aria-busy', 'false');
      })
      .catch(function () {
        if (token !== requestToken) { return; }
        results.setAttribute('aria-busy', 'false');
        results.innerHTML =
          '<p class="picker__error">Could not load the library. ' +
          'Check your connection and try again.</p>';
      });
  }

  /* ---- Opening and choosing --------------------------------------------- */

  function open(field) {
    activeField = field;
    if (search) { search.value = ''; }
    if (folder) { folder.value = ''; }
    if (uploadStatus) { uploadStatus.hidden = true; }
    dialog.showModal();
    load(1, false);
    /* Focus the search box rather than the first image: an administrator
       with a large library is far more likely to type than to scroll. */
    if (search) { search.focus(); }
  }

  function applyChoice(button) {
    if (!activeField) { return; }

    var input = activeField.querySelector('[data-media-input]');
    var preview = activeField.querySelector('[data-media-preview]');
    var name = activeField.querySelector('[data-media-name]');
    var clear = activeField.querySelector('[data-media-clear]');
    var chooseLabel = activeField.querySelector('[data-media-choose-label]');
    var altWarn = activeField.querySelector('[data-media-altwarn]');

    var alt = button.getAttribute('data-media-alt') || '';

    input.value = button.getAttribute('data-media-id');

    preview.classList.remove('media--awaiting');
    preview.innerHTML = '';
    var img = document.createElement('img');
    img.src = button.getAttribute('data-media-url');
    img.alt = alt;
    img.setAttribute('data-media-thumb', '');
    preview.appendChild(img);

    if (name) { name.textContent = button.getAttribute('data-media-filename'); }
    if (clear) { clear.hidden = false; }
    if (chooseLabel) { chooseLabel.textContent = 'Replace image'; }
    if (altWarn) {
      /* The picker card carries a "No alt text" flag; mirror it here so
         the warning follows the image into the form. */
      altWarn.hidden = !button.querySelector('.picker-card__flag');
    }

    /* The value changed without a keystroke, so nothing else would know
       the form is dirty. */
    input.dispatchEvent(new Event('change', {bubbles: true}));

    closePicker();
  }

  function clearField(field) {
    var input = field.querySelector('[data-media-input]');
    var preview = field.querySelector('[data-media-preview]');
    var name = field.querySelector('[data-media-name]');
    var clear = field.querySelector('[data-media-clear]');
    var chooseLabel = field.querySelector('[data-media-choose-label]');
    var altWarn = field.querySelector('[data-media-altwarn]');

    input.value = '';
    preview.classList.add('media--awaiting');
    preview.innerHTML =
      '<span class="media__await-label">No image yet</span>' +
      '<span class="media__await-note">The public page shows a sized ' +
      'placeholder until one is chosen.</span>';
    if (name) { name.textContent = ''; }
    if (clear) { clear.hidden = true; }
    if (chooseLabel) { chooseLabel.textContent = 'Choose image'; }
    if (altWarn) { altWarn.hidden = true; }
    input.dispatchEvent(new Event('change', {bubbles: true}));
  }

  /* ---- Wiring ----------------------------------------------------------- */

  document.querySelectorAll('[data-media-field]').forEach(function (field) {
    var choose = field.querySelector('[data-media-choose]');
    var clear = field.querySelector('[data-media-clear]');
    if (choose) {
      choose.addEventListener('click', function () { open(field); });
    }
    if (clear) {
      clear.addEventListener('click', function () { clearField(field); });
    }
  });

  results.addEventListener('click', function (event) {
    var choice = event.target.closest('[data-picker-choice]');
    if (choice) { applyChoice(choice); return; }

    var more = event.target.closest('[data-picker-more]');
    if (more) {
      load(parseInt(more.getAttribute('data-next-page'), 10) || 2, true);
    }
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', closePicker);
  }

  /* Clicking the backdrop closes. The dialog element itself is the
     backdrop's event target, so a click landing on the dialog rather
     than on its contents means the backdrop was hit. */
  dialog.addEventListener('click', function (event) {
    if (event.target === dialog) { closePicker(); }
  });

  /* Close, and put focus back on the control that opened the dialog.

     Focus restoration is done here rather than only in a `close` event
     listener because that event is not reliably delivered everywhere -
     it does not fire at all in some embedded browsers - and a keyboard
     user left with focus on nothing has no way back into the page.
     Escape closes without going through here, so the event listener
     below stays as a fallback for that path. */
  function closePicker() {
    var field = activeField;
    activeField = null;
    dialog.close();

    if (!field) { return; }
    var choose = field.querySelector('[data-media-choose]');
    if (!choose) { return; }

    /* Deferred to the next task, not the next frame: the browser does
       its own focus handling around closing, and rAF is suspended while
       the page is not painting, so in a background tab the focus would
       never be restored at all. */
    setTimeout(function () { choose.focus(); }, 0);
  }

  dialog.addEventListener('close', function () {
    // Only reached when something other than closePicker closed it -
    // in practice, Escape.
    var field = activeField;
    activeField = null;
    if (!field) { return; }
    var choose = field.querySelector('[data-media-choose]');
    if (choose) { setTimeout(function () { choose.focus(); }, 0); }
  });

  if (search) {
    search.addEventListener('input', function () {
      // Debounced: one request per pause, not one per keystroke.
      clearTimeout(searchTimer);
      searchTimer = setTimeout(function () { load(1, false); }, 250);
    });
    search.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        // Inside a <dialog> this would otherwise submit something.
        event.preventDefault();
        clearTimeout(searchTimer);
        load(1, false);
      }
    });
  }

  if (folder) {
    folder.addEventListener('change', function () { load(1, false); });
  }

  /* ---- Upload from inside the picker ------------------------------------ */

  if (uploadInput) {
    uploadInput.addEventListener('change', function () {
      var files = Array.prototype.slice.call(uploadInput.files || []);
      if (!files.length) { return; }

      var token = document.querySelector('[data-csrf-token]');
      var csrf = token ? token.getAttribute('content') : '';
      var done = 0;
      var failed = 0;

      uploadStatus.hidden = false;
      uploadStatus.textContent = 'Uploading 0 of ' + files.length + '…';

      function report() {
        if (done + failed < files.length) {
          uploadStatus.textContent =
            'Uploading ' + (done + failed) + ' of ' + files.length + '…';
          return;
        }
        uploadStatus.textContent =
          'Uploaded ' + done + (failed ? ', ' + failed + ' failed' : '') + '.';
        // Newest first, so a fresh upload is at the top of the results.
        if (search) { search.value = ''; }
        if (folder) { folder.value = ''; }
        load(1, false);
      }

      files.forEach(function (file) {
        var body = new FormData();
        body.append('file', file);
        body.append('csrf_token', csrf);

        fetch('/admin/media/upload', {
          method: 'POST',
          body: body,
          headers: {'X-Requested-With': 'XMLHttpRequest'},
          credentials: 'same-origin'
        })
          .then(function (response) { return response.json(); })
          .then(function (payload) {
            if (payload && payload.ok) { done += 1; } else { failed += 1; }
            report();
          })
          .catch(function () { failed += 1; report(); });
      });

      uploadInput.value = '';
    });
  }
}());
