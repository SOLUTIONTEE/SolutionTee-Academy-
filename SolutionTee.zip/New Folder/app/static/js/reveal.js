/* Entrance reveals.
   =========================================================================
   Applied only to elements that opt in with .reveal, and only a few per
   page. Anything critical is visible without this script running: the
   hidden state lives behind .js, so a failed script leaves content shown
   rather than blank.

   Skipped entirely when the visitor has asked for reduced motion.
   ====================================================================== */
(function () {
  'use strict';

  var targets = document.querySelectorAll('.reveal');
  if (!targets.length) { return; }

  var reduced = window.matchMedia &&
                window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function showAll() {
    targets.forEach(function (el) { el.classList.add('is-visible'); });
  }

  if (reduced || !('IntersectionObserver' in window)) {
    showAll();
    return;
  }

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) { return; }
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    });
  }, { rootMargin: '0px 0px -10% 0px', threshold: 0.1 });

  targets.forEach(function (el) { observer.observe(el); });
}());
