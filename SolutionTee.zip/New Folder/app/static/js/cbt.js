/* Sitting a paper.
   =========================================================================
   Three jobs: move between questions, autosave answers, and show a
   countdown.

   The countdown is a COURTESY. The server stores the deadline and
   refuses a late answer whatever this clock says, and every save
   response carries the real remaining time so a tab that was asleep
   corrects itself instead of drifting.

   Without JavaScript the whole paper is still in the page and every
   answer is a real form control - a candidate could still read it and
   submit. What they would lose is autosave, which is why the submit
   button is a plain form post.
   ====================================================================== */
(function () {
  'use strict';

  var paper = document.querySelector('.paper');
  if (!paper) { return; }

  var questions = Array.prototype.slice.call(
    paper.querySelectorAll('[data-question]')
  );
  if (!questions.length) { return; }

  var answerUrl = paper.getAttribute('data-answer-url');
  var clockEl = paper.querySelector('[data-clock]');
  var statusEl = paper.querySelector('[data-save-status]');
  var countEl = paper.querySelector('[data-answered-count]');
  var submitForm = paper.querySelector('[data-submit-form]');
  var navButtons = Array.prototype.slice.call(
    paper.querySelectorAll('[data-goto]')
  );

  var csrfMeta = document.querySelector('meta[name="csrf-token"]');
  var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

  var remaining = parseInt(paper.getAttribute('data-remaining'), 10) || 0;
  var current = 0;
  var closed = false;

  /* ---- Moving between questions ----------------------------------------- */

  function show(index) {
    if (index < 0 || index >= questions.length) { return; }
    questions[current].hidden = true;
    current = index;
    questions[current].hidden = false;

    navButtons.forEach(function (button, i) {
      button.setAttribute('aria-current', i === index ? 'true' : 'false');
    });

    /* Move focus to the question itself so a screen reader announces the
       new question rather than leaving the user where they were. */
    var heading = questions[current].querySelector('.question__position');
    if (heading) {
      heading.setAttribute('tabindex', '-1');
      heading.focus({preventScroll: true});
    }
    questions[current].scrollIntoView({block: 'start'});
  }

  navButtons.forEach(function (button) {
    button.addEventListener('click', function () {
      show(parseInt(button.getAttribute('data-goto'), 10));
    });
  });

  paper.addEventListener('click', function (event) {
    if (event.target.closest('[data-next]')) { show(current + 1); }
    if (event.target.closest('[data-prev]')) { show(current - 1); }
  });

  /* ---- State of each question ------------------------------------------- */

  function isAnswered(article) {
    var checked = article.querySelector('[data-choice]:checked');
    if (checked) { return true; }
    var value = article.querySelector('[data-value]');
    return !!(value && value.value.trim());
  }

  function refreshState() {
    var answered = 0;
    questions.forEach(function (article, index) {
      var done = isAnswered(article);
      if (done) { answered += 1; }
      var flagged = article.querySelector('[data-flag]');
      var button = navButtons[index];
      if (!button) { return; }
      button.classList.toggle('is-answered', done);
      button.classList.toggle('is-flagged', !!(flagged && flagged.checked));
    });
    if (countEl) { countEl.textContent = String(answered); }
  }

  /* ---- Autosave ----------------------------------------------------------
     One request per change. Small enough that batching would add
     complexity without saving anything, and it means a crash loses at
     most the answer being typed. */

  function saveAnswer(article) {
    if (closed) { return; }

    var questionId = parseInt(article.getAttribute('data-question-id'), 10);
    var chosen = Array.prototype.slice
      .call(article.querySelectorAll('[data-choice]:checked'))
      .map(function (input) { return parseInt(input.value, 10); });
    var valueInput = article.querySelector('[data-value]');
    var flagInput = article.querySelector('[data-flag]');

    if (statusEl) { statusEl.textContent = 'Saving'; }

    fetch(answerUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        // Flask-WTF checks this header for requests that carry no form.
        'X-CSRFToken': csrfToken
      },
      credentials: 'same-origin',
      body: JSON.stringify({
        question_id: questionId,
        choice_ids: chosen,
        value: valueInput ? valueInput.value : '',
        flagged: flagInput ? flagInput.checked : false
      })
    })
      .then(function (response) {
        return response.json().then(function (payload) {
          return {status: response.status, payload: payload};
        });
      })
      .then(function (result) {
        if (result.payload && result.payload.ok) {
          // Re-sync from the server rather than trusting the local tick.
          if (typeof result.payload.seconds_remaining === 'number') {
            remaining = result.payload.seconds_remaining;
          }
          if (statusEl) { statusEl.textContent = 'Saved'; }
          return;
        }

        if (result.status === 409 && result.payload.closed) {
          // Time ran out while this was in flight. The server has already
          // marked the paper; sending the candidate to the result is the
          // honest thing rather than letting them keep typing.
          closed = true;
          window.location.reload();
          return;
        }
        if (statusEl) {
          statusEl.textContent = (result.payload && result.payload.error)
            || 'Could not save';
        }
      })
      .catch(function () {
        /* A dropped connection is common on a mobile network. The answer
           stays in the page, so retrying on the next change or on submit
           recovers it. */
        if (statusEl) {
          statusEl.textContent = 'Not saved — check your connection';
        }
      });
  }

  questions.forEach(function (article) {
    article.addEventListener('change', function () {
      refreshState();
      saveAnswer(article);
    });

    // Typed answers save on pause, not on every keystroke.
    var valueInput = article.querySelector('[data-value]');
    if (valueInput) {
      var timer = null;
      valueInput.addEventListener('input', function () {
        refreshState();
        clearTimeout(timer);
        timer = setTimeout(function () { saveAnswer(article); }, 600);
      });
    }
  });

  /* ---- The countdown ------------------------------------------------------ */

  function pad(value) { return value < 10 ? '0' + value : String(value); }

  function renderClock() {
    if (!clockEl) { return; }
    var minutes = Math.floor(remaining / 60);
    var seconds = remaining % 60;
    clockEl.textContent = pad(minutes) + ':' + pad(seconds);

    paper.classList.toggle('is-urgent', remaining <= 300 && remaining > 60);
    paper.classList.toggle('is-critical', remaining <= 60);
  }

  function tick() {
    if (closed) { return; }
    remaining -= 1;

    if (remaining <= 0) {
      remaining = 0;
      renderClock();
      closed = true;
      /* Submitting here is a convenience so the candidate sees their
         result immediately. The server would have auto-submitted this
         attempt on the next request regardless. */
      if (submitForm) { submitForm.submit(); }
      return;
    }
    renderClock();
  }

  renderClock();
  setInterval(tick, 1000);

  /* Correct for a suspended tab: setInterval does not fire while a phone
     is locked, so the clock would otherwise be minutes slow on return. */
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && questions[current]) {
      saveAnswer(questions[current]);
    }
  });

  /* ---- Leaving ------------------------------------------------------------ */

  window.addEventListener('beforeunload', function (event) {
    if (closed) { return; }
    // The clock keeps running whether or not they are on the page.
    event.preventDefault();
    event.returnValue = '';
  });

  if (submitForm) {
    submitForm.addEventListener('submit', function () {
      // Stops the "are you sure" dialog firing on a deliberate submit.
      closed = true;
    });
  }

  refreshState();
  show(0);
}());
