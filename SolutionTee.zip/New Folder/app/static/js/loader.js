/* First-visit loader: dismissal.
   =========================================================================
   The overlay clears itself in CSS at 2.6s whatever happens here, so this
   file can only ever make the wait shorter - never longer, and never the
   reason a page stays covered. If it fails to parse or never runs, the
   visitor loses nothing but a few hundred milliseconds.

   Whether the overlay is shown at all was decided before paint by the
   inline script in the head, which sets data-loader on <html>.
   ====================================================================== */
(function () {
  'use strict';

  var root = document.documentElement;
  if (!root.hasAttribute('data-loader')) { return; }

  var loader = document.getElementById('loader');
  if (!loader) { return; }

  /* The intro runs to 1.7s. Cutting it off part-drawn looks like a bug,
     so an early `load` waits for the artwork to finish rather than
     snatching it away. */
  var INTRO_MS = 1700;
  var started = Date.now();
  var dismissed = false;

  function dismiss() {
    if (dismissed) { return; }
    dismissed = true;

    var remaining = Math.max(0, INTRO_MS - (Date.now() - started));
    window.setTimeout(function () {
      loader.classList.add('is-done');

      /* Take it out of the document once it has faded, so nothing is
         left painting over the page. Driven by the transitionend-free
         route - a timer - because an interrupted animation fires no
         event and would leak the element. */
      window.setTimeout(function () {
        if (loader.parentNode) { loader.parentNode.removeChild(loader); }
        root.removeAttribute('data-loader');
      }, 300);
    }, remaining);
  }

  if (document.readyState === 'complete') {
    dismiss();
  } else {
    window.addEventListener('load', dismiss);
  }

  /* A page that never fires `load` - a stalled image, a hung font - must
     not hold the overlay open to the CSS backstop. */
  window.setTimeout(dismiss, 2200);
}());
