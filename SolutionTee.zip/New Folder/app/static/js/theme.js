/* Theme toggle.
   =========================================================================
   Three states, matching the tokens: an explicit "light", an explicit
   "dark", and no stored choice at all, which lets the operating system
   decide. The toggle flips relative to what is currently showing, so the
   first click always visibly changes something.

   The stored value is read in a tiny inline script in <head>, before
   first paint, so a dark-mode visitor never sees a white flash.
   ====================================================================== */
(function () {
  'use strict';

  var KEY = 'st-theme';
  var root = document.documentElement;
  var toggle = document.querySelector('[data-theme-toggle]');
  if (!toggle) { return; }

  function systemPrefersDark() {
    return window.matchMedia &&
           window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  function currentTheme() {
    var explicit = root.getAttribute('data-theme');
    if (explicit === 'dark' || explicit === 'light') { return explicit; }
    return systemPrefersDark() ? 'dark' : 'light';
  }

  function describe(theme) {
    var next = theme === 'dark' ? 'light' : 'dark';
    toggle.setAttribute('aria-label', 'Switch to ' + next + ' theme');
  }

  describe(currentTheme());

  toggle.addEventListener('click', function () {
    var next = currentTheme() === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    describe(next);
    try {
      localStorage.setItem(KEY, next);
    } catch (e) {
      /* Private browsing refuses the write. The theme still applies for
         this page view; it simply will not be remembered. */
    }
  });
}());
