/* A conversation that keeps up with itself.
   =========================================================================
   Polling, not websockets. Railway would need a compatible worker and
   sticky sessions for the alternative, and a few seconds on a message
   between a tutor and a student does not justify that.

   The page works completely without this file: the thread is rendered by
   the server and the form is an ordinary POST. All this adds is that new
   messages appear without a reload.

   Three things it is careful about:

   - It asks only for what arrived AFTER the last message it has, so a
     quiet thread costs one small query and returns an empty list.
   - It backs off when the tab is hidden. A dozen open tabs polling every
     five seconds is a self-inflicted load test.
   - It stops after enough consecutive failures rather than hammering a
     server that is already unhappy.
   ====================================================================== */
(function () {
  'use strict';

  var thread = document.getElementById('thread');
  if (!thread) { return; }

  var url = thread.getAttribute('data-thread-url');
  if (!url) { return; }

  var since = thread.getAttribute('data-since') || '';
  var ACTIVE_MS = 5000;
  var HIDDEN_MS = 30000;
  var MAX_FAILURES = 5;

  var failures = 0;
  var timer = null;

  function atBottom() {
    /* Whether the reader is following the conversation. Scrolling up to
       read something earlier must not be interrupted by an auto-scroll
       the moment somebody types. */
    return (window.innerHeight + window.scrollY) >=
           (document.body.scrollHeight - 120);
  }

  function render(message) {
    var item = document.createElement('li');
    item.className = 'msg';
    if (message.system) {
      item.className += ' msg--system';
    } else if (message.mine) {
      item.className += ' msg--mine';
    }

    if (!message.system) {
      var author = document.createElement('span');
      author.className = 'msg__author';
      author.textContent = message.author;
      item.appendChild(author);
    }

    /* textContent, never innerHTML. The body is escaped on the way into
       the database as well; this is the second of the two places it
       would matter, and the cheaper one to get right. */
    var body = document.createElement('span');
    body.className = 'msg__body';
    body.textContent = message.body;
    item.appendChild(body);

    var at = document.createElement('span');
    at.className = 'msg__at';
    at.textContent = message.shown;
    item.appendChild(at);

    thread.appendChild(item);
  }

  function poll() {
    var wasAtBottom = atBottom();

    fetch(url + '?after=' + encodeURIComponent(since), {
      headers: { 'Accept': 'application/json' },
      credentials: 'same-origin'
    })
      .then(function (response) {
        if (!response.ok) { throw new Error(String(response.status)); }
        return response.json();
      })
      .then(function (data) {
        failures = 0;
        var messages = (data && data.messages) || [];
        if (!messages.length) { return; }

        messages.forEach(function (message) {
          render(message);
          since = message.at;
        });
        thread.setAttribute('data-since', since);

        if (wasAtBottom) {
          window.scrollTo({ top: document.body.scrollHeight,
                            behavior: 'smooth' });
        }
      })
      .catch(function () {
        failures += 1;
        if (failures >= MAX_FAILURES) {
          stop();
        }
      })
      .finally(schedule);
  }

  function schedule() {
    if (failures >= MAX_FAILURES) { return; }
    window.clearTimeout(timer);
    timer = window.setTimeout(poll, document.hidden ? HIDDEN_MS : ACTIVE_MS);
  }

  function stop() {
    window.clearTimeout(timer);
  }

  /* Coming back to the tab should feel immediate rather than waiting out
     whatever remained of a thirty-second interval. */
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { return; }
    failures = 0;
    window.clearTimeout(timer);
    timer = window.setTimeout(poll, 300);
  });

  schedule();

  /* Enter sends; Shift+Enter starts a new line. The form still submits
     normally, so this is a shortcut rather than the mechanism. */
  var input = document.getElementById('body');
  var form = input && input.form;
  if (input && form) {
    input.addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' || event.shiftKey) { return; }
      if (!input.value.trim()) { return; }
      event.preventDefault();
      form.requestSubmit();
    });
  }
}());
