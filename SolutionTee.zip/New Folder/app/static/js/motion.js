/* Smooth scroll and scroll-driven animation.
   =========================================================================
   Lenis drives the scroll; GSAP + ScrollTrigger drive anything that reacts
   to it. Both are vendored under /static/vendor rather than pulled from a
   CDN: the Content-Security-Policy allows `script-src 'self'`, and widening
   it for a third party is a real cost for a convenience.

   The two libraries have to be told about each other or they fight. Lenis
   takes ownership of the scroll position, so ScrollTrigger must be driven
   from Lenis's scroll event and must read the position through Lenis rather
   than from window.scrollY, which no longer moves the way it expects.

   EVERYTHING HERE IS AN ENHANCEMENT. Every element it touches is readable
   with the script absent: the hidden states live behind .js, and reveal.js
   keeps its IntersectionObserver fallback. If a library fails to load,
   native scrolling carries on untouched.

   Where smooth scroll is deliberately OFF, and why:

     .bare   the CBT paper. Taking ownership of the scroll during a timed
             examination is indefensible - a candidate who cannot reach
             question 40 loses marks to a decoration.
     .admin  a dense working tool. Lenis owns the wheel and a nested
             scroller never gets it back, so a long sidebar becomes
             unreachable.
     .auth   short forms with nothing to scroll, where Lenis has been seen
             pinning the position at zero and hiding the links underneath.
     mobile  momentum scrolling is already good and hijacking it on a
             mid-range Android is worse than leaving it alone.
   ====================================================================== */
(function () {
  'use strict';

  var hasGsap = typeof window.gsap !== 'undefined';
  var hasLenis = typeof window.Lenis !== 'undefined';
  var reduced = window.matchMedia &&
                window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var isExam = !!document.querySelector('.bare');
  var isAdmin = !!document.querySelector('.admin');
  var isAuth = !!document.querySelector('.auth');

  var wantsSmooth =
    !reduced && !isExam && !isAdmin && !isAuth &&
    window.matchMedia('(min-width: 1025px)').matches;

  /* ---- Lenis ----------------------------------------------------------- */
  var lenis = null;
  if (hasLenis && wantsSmooth) {
    lenis = new window.Lenis({
      /* ~1s to settle: long enough to read as eased, short enough that a
         flick still gets you down a long page. */
      duration: 1.05,
      easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); },
      smoothWheel: true,
      /* Touch is left alone even on a large screen: a trackpad and a
         touchscreen want different things and only one of them is being
         improved here. */
      smoothTouch: false
    });
    document.documentElement.classList.add('lenis');
  }

  /* ---- GSAP ------------------------------------------------------------ */
  if (hasGsap && window.ScrollTrigger) {
    window.gsap.registerPlugin(window.ScrollTrigger);

    if (lenis) {
      lenis.on('scroll', window.ScrollTrigger.update);
      window.gsap.ticker.add(function (time) { lenis.raf(time * 1000); });
      window.gsap.ticker.lagSmoothing(0);
    }
  } else if (lenis) {
    /* Lenis without GSAP still needs a frame loop of its own. */
    (function step(time) {
      lenis.raf(time);
      window.requestAnimationFrame(step);
    })(0);
  }

  /* Past this point everything needs GSAP. Without it the CSS reveals and
     reveal.js already cover the page, so there is nothing to fall back to
     and nothing to clean up. */
  if (!hasGsap || !window.ScrollTrigger || reduced) { return; }

  var gsap = window.gsap;

  /* ---- Sections rising into place -------------------------------------
     Batched rather than one ScrollTrigger per element: a long page can
     carry fifty of these and fifty triggers is a measurable cost. */
  var risers = document.querySelectorAll('[data-gsap="rise"]');
  if (risers.length) {
    gsap.set(risers, { opacity: 0, y: 28 });
    window.ScrollTrigger.batch(risers, {
      start: 'top 88%',
      once: true,
      onEnter: function (elements) {
        gsap.to(elements, {
          opacity: 1, y: 0, duration: 0.7, ease: 'power3.out',
          stagger: 0.08, overwrite: true
        });
      }
    });
  }

  /* ---- Headlines, split into lines -------------------------------------
     Each line masks its own inner span so the text slides up from behind a
     clean edge rather than fading in place.

     The split is done on the live layout, so it has to be rebuilt when the
     line count changes. It is skipped entirely if the element carries
     anything but text: re-writing innerHTML would destroy nested markup and
     any event listener on it. */
  function splitIntoLines(el) {
    var text = el.textContent.replace(/\s+/g, ' ').trim();
    if (!text) { return null; }

    var words = text.split(' ');
    el.textContent = '';

    var probes = words.map(function (word, index) {
      var span = document.createElement('span');
      span.textContent = word + (index < words.length - 1 ? ' ' : '');
      span.style.display = 'inline-block';
      el.appendChild(span);
      return span;
    });

    /* Group the words by the vertical position they actually landed at -
       the browser has already done the line breaking, so this reads the
       result rather than trying to predict it. */
    var lines = [];
    var currentTop = null;
    probes.forEach(function (span) {
      var top = span.offsetTop;
      if (currentTop === null || Math.abs(top - currentTop) > 2) {
        lines.push([]);
        currentTop = top;
      }
      lines[lines.length - 1].push(span.textContent);
    });

    el.textContent = '';
    var inners = lines.map(function (words) {
      var line = document.createElement('span');
      line.className = 'gsap-line';
      var inner = document.createElement('span');
      inner.className = 'gsap-line__inner';
      inner.textContent = words.join('');
      line.appendChild(inner);
      el.appendChild(line);
      return inner;
    });
    return inners;
  }

  document.querySelectorAll('[data-gsap="headline"]').forEach(function (el) {
    if (el.children.length) { return; }  /* nested markup: leave it alone */
    var inners = splitIntoLines(el);
    if (!inners || !inners.length) { return; }

    gsap.set(inners, { yPercent: 115 });
    gsap.to(inners, {
      yPercent: 0, duration: 0.9, ease: 'power4.out', stagger: 0.09,
      scrollTrigger: { trigger: el, start: 'top 88%', once: true }
    });
  });

  /* ---- Body copy arriving ---------------------------------------------- */
  document.querySelectorAll('[data-gsap="fade"]').forEach(function (el) {
    gsap.fromTo(el,
      { opacity: 0, y: 16 },
      {
        opacity: 1, y: 0, duration: 0.8, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 90%', once: true }
      });
  });

  /* ---- Parallax --------------------------------------------------------
     Scrubbed against scroll position rather than played on entry, so the
     movement tracks the wheel exactly. Deliberately small: a hero image
     that slides more than a few percent stops reading as depth and starts
     reading as a bug. */
  document.querySelectorAll('[data-gsap="parallax"]').forEach(function (el) {
    gsap.fromTo(el,
      { yPercent: -4 },
      {
        yPercent: 4, ease: 'none',
        scrollTrigger: {
          trigger: el.parentElement || el,
          start: 'top bottom', end: 'bottom top', scrub: true
        }
      });
  });

  /* ---- A rule drawing itself across the page --------------------------- */
  document.querySelectorAll('[data-gsap="rule"]').forEach(function (el) {
    gsap.fromTo(el,
      { scaleX: 0, transformOrigin: 'left center' },
      {
        scaleX: 1, duration: 0.9, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 92%', once: true }
      });
  });

  /* ScrollTrigger measures on load. Late-arriving images and webfonts move
     everything underneath them, so the positions are recomputed once the
     page has actually finished settling. */
  window.addEventListener('load', function () {
    window.ScrollTrigger.refresh();
  });

  /* ---- Watchdog --------------------------------------------------------
     These animations hide content before revealing it, which makes them
     the most dangerous thing on the page: if a tween never runs the reader
     gets a blank section and nothing errors. Known causes - a restore from
     the back/forward cache, a tab that loaded in the background and never
     got a frame, a ScrollTrigger that measured a layout which then moved.

     This runs on a plain interval. Not on scroll, and not on
     requestAnimationFrame, because BOTH are things whose failure it exists
     to cover:

       - rAF is the loop GSAP and Lenis animate from. If it is not running,
         a rescue scheduled on it never runs either.
       - the native `scroll` event does not fire at all once Lenis owns
         scrolling, and Lenis's own scroll event is emitted from its rAF
         loop - so a scroll-bound rescue is blind on exactly the pages
         where smooth scroll is enabled.

     An interval depends on nothing but the clock.

     It reveals everything only on EVIDENCE of breakage: an element the
     reader can already see that is still hidden. A healthy page therefore
     keeps its animations, and a broken one shows its content. */

  function show(el) {
    el.style.opacity = '1';
    el.style.transform = 'none';
    el.querySelectorAll('.gsap-line__inner').forEach(function (inner) {
      inner.style.transform = 'none';
    });
  }

  function isHidden(el) {
    return parseFloat(window.getComputedStyle(el).opacity) < 0.95;
  }

  var watchdogStarted = Date.now();
  var watchdog = window.setInterval(function () {
    var hooks = document.querySelectorAll('[data-gsap]');
    var anyHidden = false;
    var broken = false;

    hooks.forEach(function (el) {
      if (!isHidden(el)) { return; }
      anyHidden = true;

      var box = el.getBoundingClientRect();
      /* Comfortably inside the viewport, not merely touching its edge: an
         element halfway through its own entrance animation is legitimately
         still faint and must not be mistaken for a failure. */
      if (box.top < window.innerHeight * 0.85 && box.bottom > 0) {
        broken = true;
      }
    });

    if (broken) {
      hooks.forEach(show);
      window.clearInterval(watchdog);
      return;
    }

    /* Everything revealed, or the reader has been here long enough that
       the question is settled either way. */
    if (!anyHidden || Date.now() - watchdogStarted > 60000) {
      window.clearInterval(watchdog);
    }
  }, 500);

  /* A bfcache restore replays no tween and fires no scroll event. */
  window.addEventListener('pageshow', function (event) {
    if (!event.persisted) { return; }
    document.querySelectorAll('[data-gsap]').forEach(function (el) {
      var box = el.getBoundingClientRect();
      if (isHidden(el) && box.top < window.innerHeight && box.bottom > 0) {
        show(el);
      }
    });
  });
}());
