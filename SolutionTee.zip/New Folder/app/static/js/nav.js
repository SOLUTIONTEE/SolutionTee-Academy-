/* Navigation: desktop mega menus, the mobile panel, and disclosures.
   =========================================================================
   Progressive enhancement. Every panel is already in the document and
   every destination is a real link, so a failure here degrades to a page
   that still navigates - it does not degrade to a dead header.

   Visibility is toggled with the `hidden` property rather than a class,
   so a closed panel leaves the accessibility tree instead of merely
   disappearing.
   ====================================================================== */
(function () {
  'use strict';

  var FOCUSABLE = 'a[href], button:not([disabled]), input, select, textarea,' +
                  ' [tabindex]:not([tabindex="-1"])';

  /* ---- Desktop mega menus ---------------------------------------------
     One open at a time. Opens on click rather than hover: a hover menu is
     unusable on a touch screen and hostile to anyone with a tremor. */

  var navItems = Array.prototype.slice.call(
    document.querySelectorAll('[data-nav-item]')
  );

  function closeAllMenus(exceptTrigger) {
    navItems.forEach(function (item) {
      var trigger = item.querySelector('[data-nav-trigger]');
      var panel = item.querySelector('[data-nav-panel]');
      if (!trigger || !panel || trigger === exceptTrigger) { return; }
      trigger.setAttribute('aria-expanded', 'false');
      panel.hidden = true;
    });
  }

  navItems.forEach(function (item) {
    var trigger = item.querySelector('[data-nav-trigger]');
    var panel = item.querySelector('[data-nav-panel]');
    if (!trigger || !panel) { return; }

    trigger.addEventListener('click', function () {
      var isOpen = trigger.getAttribute('aria-expanded') === 'true';
      closeAllMenus(trigger);
      trigger.setAttribute('aria-expanded', String(!isOpen));
      panel.hidden = isOpen;
    });

    /* Leaving the group entirely by keyboard closes it, so tabbing
       forward does not leave an orphaned panel open behind you. */
    item.addEventListener('focusout', function (event) {
      if (!item.contains(event.relatedTarget)) {
        trigger.setAttribute('aria-expanded', 'false');
        panel.hidden = true;
      }
    });
  });

  document.addEventListener('click', function (event) {
    var insideNav = event.target.closest && event.target.closest('[data-nav-item]');
    if (!insideNav) { closeAllMenus(null); }
  });

  /* ---- Mobile panel ----------------------------------------------------
     A modal sheet: focus is trapped inside it, the page behind does not
     scroll, and Escape closes it. */

  var panel = document.querySelector('[data-menu-panel]');
  var openBtn = document.querySelector('[data-menu-open]');
  var closeBtn = document.querySelector('[data-menu-close]');
  var lastFocused = null;

  function openMenu() {
    if (!panel || !openBtn) { return; }
    lastFocused = document.activeElement;
    panel.hidden = false;
    openBtn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    var first = panel.querySelector(FOCUSABLE);
    if (first) { first.focus(); }
  }

  function closeMenu() {
    if (!panel || !openBtn) { return; }
    panel.hidden = true;
    openBtn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    if (lastFocused) { lastFocused.focus(); }
  }

  if (openBtn) { openBtn.addEventListener('click', openMenu); }
  if (closeBtn) { closeBtn.addEventListener('click', closeMenu); }

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      if (panel && !panel.hidden) { closeMenu(); return; }
      closeAllMenus(null);
    }

    if (event.key !== 'Tab' || !panel || panel.hidden) { return; }

    var items = Array.prototype.slice
      .call(panel.querySelectorAll(FOCUSABLE))
      .filter(function (el) { return el.offsetParent !== null; });
    if (!items.length) { return; }

    var first = items[0];
    var last = items[items.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  /* A resize past the desktop breakpoint leaves the sheet stranded over a
     layout that no longer needs it. */
  window.addEventListener('resize', function () {
    if (window.innerWidth >= 1080 && panel && !panel.hidden) { closeMenu(); }
  });

  /* ---- Disclosures ------------------------------------------------------
     Used by the mobile menu groups and reusable anywhere else. */

  document.querySelectorAll('[data-disclosure-trigger]').forEach(function (trigger) {
    var target = document.getElementById(
      trigger.getAttribute('aria-controls') || ''
    );
    if (!target) { return; }

    trigger.addEventListener('click', function () {
      var isOpen = trigger.getAttribute('aria-expanded') === 'true';
      trigger.setAttribute('aria-expanded', String(!isOpen));
      target.hidden = isOpen;
    });
  });

  /* ---- Header height ----------------------------------------------------
     Published as a custom property so scroll-padding and sticky offsets
     track the real header rather than a guessed constant. */

  var header = document.querySelector('.header');

  function publishHeaderHeight() {
    if (!header) { return; }
    document.documentElement.style.setProperty(
      '--header-h', header.offsetHeight + 'px'
    );
  }

  publishHeaderHeight();
  window.addEventListener('resize', publishHeaderHeight);

  /* ---- Scrolled state ---------------------------------------------------
     Marks the header once content has actually moved underneath it, so
     the layering cue is earned rather than permanent. Read inside a
     rAF because a scroll handler that measures layout on every event is
     how a page starts to feel heavy. */

  var scrollQueued = false;

  function applyScrolledState() {
    scrollQueued = false;
    if (!header) { return; }
    if (window.scrollY > 4) {
      header.setAttribute('data-scrolled', '');
    } else {
      header.removeAttribute('data-scrolled');
    }
  }

  function onScroll() {
    if (scrollQueued) { return; }
    scrollQueued = true;
    window.requestAnimationFrame(applyScrolledState);
  }

  applyScrolledState();
  window.addEventListener('scroll', onScroll, { passive: true });
}());
