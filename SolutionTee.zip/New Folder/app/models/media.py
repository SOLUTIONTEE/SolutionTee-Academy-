"""Media library.

PostgreSQL stores metadata and object keys. The bytes live in Cloudflare
R2 (or on disk in development). No image binary is ever written into the
database.

One asset, referenced many times. A photograph used on the homepage, on a
programme page and in a gallery is a single `Media` row with three
`MediaUsage` rows pointing at it, not three uploads. That is what makes
"where is this used?" answerable, and it is what stops a deletion from
silently blanking a published page.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON, Boolean, ForeignKey, Index, Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, PublicIdMixin, SlugMixin, TimestampMixin

#: JSONB in production; plain JSON so the isolated test suite can run on
#: SQLite. Nothing in the production path depends on the fallback.
JSON_TYPE = JSON().with_variant(JSONB, "postgresql")


class MediaFolder(Base, TimestampMixin, SlugMixin):
    """Admin-managed grouping.

    Deliberately a table rather than a hard-coded list: which folders
    exist is an editorial decision, and it changes without a deploy.
    """

    __tablename__ = "media_folders"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="", nullable=False)
    #: One level of nesting is enough for a media library; deeper trees
    #: cost more in navigation than they return in organisation.
    parent_id: Mapped[int | None] = mapped_column(
        ForeignKey("media_folders.id", ondelete="SET NULL"), nullable=True
    )
    position: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    children: Mapped[list["MediaFolder"]] = relationship(
        back_populates="parent", remote_side=lambda: [MediaFolder.parent_id],
    )
    parent: Mapped["MediaFolder | None"] = relationship(
        back_populates="children", remote_side=lambda: [MediaFolder.id],
    )

    def __repr__(self) -> str:
        return f"<MediaFolder {self.slug}>"


class Media(Base, PublicIdMixin, TimestampMixin):
    __tablename__ = "media"

    id: Mapped[int] = mapped_column(primary_key=True)

    # -- Storage -----------------------------------------------------------
    #: The key of the original object in R2. Generated, never derived from
    #: the uploaded filename: a filename is attacker-controlled input.
    object_key: Mapped[str] = mapped_column(String(255), unique=True,
                                            nullable=False)
    #: {"thumb": {"key": ..., "width": ..., "height": ...}, ...}
    #: Held as JSON rather than as columns so a new size can be added
    #: without a migration, and a missing variant is simply absent.
    variants: Mapped[dict] = mapped_column(JSON_TYPE, default=dict,
                                           nullable=False)

    # -- File facts --------------------------------------------------------
    original_filename: Mapped[str] = mapped_column(String(255), nullable=False)
    mime_type: Mapped[str] = mapped_column(String(80), nullable=False)
    extension: Mapped[str] = mapped_column(String(10), nullable=False)
    file_size: Mapped[int] = mapped_column(Integer, nullable=False)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    #: SHA-256 of the uploaded bytes. Lets a re-upload of the same
    #: photograph be recognised instead of silently duplicating storage.
    checksum: Mapped[str] = mapped_column(String(64), index=True,
                                          nullable=False)

    # -- Editorial ---------------------------------------------------------
    #: Never defaulted from the filename. "IMG_4821.jpg" is not alt text,
    #: and pretending it is makes a page look accessible while telling a
    #: screen-reader user nothing.
    alt_text: Mapped[str] = mapped_column(String(255), default="",
                                          nullable=False)
    title: Mapped[str] = mapped_column(String(160), default="",
                                       nullable=False)
    caption: Mapped[str] = mapped_column(Text, default="", nullable=False)
    #: True when the image carries no meaning and should be hidden from
    #: assistive technology with alt="".
    is_decorative: Mapped[bool] = mapped_column(Boolean, default=False,
                                                nullable=False)

    # -- Organisation ------------------------------------------------------
    folder_id: Mapped[int | None] = mapped_column(
        ForeignKey("media_folders.id", ondelete="SET NULL"), nullable=True,
        index=True,
    )
    uploaded_by_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    #: Archived assets leave the picker but keep serving, so archiving a
    #: still-referenced image never blanks a live page.
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False,
                                              nullable=False, index=True)

    folder: Mapped[MediaFolder | None] = relationship()
    usages: Mapped[list["MediaUsage"]] = relationship(
        back_populates="media", cascade="all, delete-orphan",
        passive_deletes=True,
    )

    __table_args__ = (
        # The media grid is "newest first, optionally within a folder",
        # which is exactly this index.
        Index("ix_media_archived_created", "is_archived", "created_at"),
        Index("ix_media_folder_created", "folder_id", "created_at"),
    )

    @property
    def is_in_use(self) -> bool:
        return bool(self.usages)

    @property
    def accessible_alt(self) -> str:
        """What actually belongs in the alt attribute."""
        return "" if self.is_decorative else self.alt_text

    def __repr__(self) -> str:
        return f"<Media {self.public_id} {self.original_filename}>"


class MediaUsage(Base):
    """One place a media asset is referenced.

    Kept as a loose (content_type, content_id) pair rather than a real
    foreign key per content table: the alternative is a nullable FK column
    for every content type that ever uses an image, which does not scale
    and makes "list everything using this asset" a union of a dozen
    queries.
    """

    __tablename__ = "media_usages"

    id: Mapped[int] = mapped_column(primary_key=True)
    media_id: Mapped[int] = mapped_column(
        ForeignKey("media.id", ondelete="CASCADE"), nullable=False, index=True
    )
    #: e.g. "programme", "article", "gallery", "site_block"
    content_type: Mapped[str] = mapped_column(String(40), nullable=False)
    #: The referencing record, as text so it suits any key type.
    content_id: Mapped[str] = mapped_column(String(64), nullable=False)
    #: Which slot on that record, e.g. "hero" or "thumbnail".
    field: Mapped[str] = mapped_column(String(40), default="", nullable=False)
    #: Human-readable, for the "used in" panel, so rendering it needs no
    #: lookup into whichever table content_type names.
    label: Mapped[str] = mapped_column(String(160), default="",
                                       nullable=False)
    created_at: Mapped[datetime] = mapped_column(nullable=False)

    media: Mapped[Media] = relationship(back_populates="usages")

    __table_args__ = (
        # One row per (asset, place). Re-saving a page must update the
        # usage rather than append a duplicate.
        UniqueConstraint("media_id", "content_type", "content_id", "field",
                         name="uq_media_usage_location"),
        Index("ix_media_usage_content", "content_type", "content_id"),
    )

    def __repr__(self) -> str:
        return f"<MediaUsage {self.content_type}:{self.content_id}.{self.field}>"
