"""Controlled vocabularies.

Plain string constants rather than Python enums: they compare cleanly in
Jinja, store readably in PostgreSQL, and survive migration without a
database-level enum type that is awkward to alter later.
"""
from __future__ import annotations


class _Values:
    """Lets a class expose its own constants as a tuple for validation."""

    @classmethod
    def values(cls) -> tuple[str, ...]:
        return tuple(
            v for k, v in vars(cls).items()
            if not k.startswith("_") and isinstance(v, str)
        )


class RoleName(_Values):
    SUPER_ADMIN = "super_admin"
    ADMIN = "admin"
    EMPLOYEE = "employee"
    INSTRUCTOR = "instructor"
    STUDENT = "student"
    PARENT = "parent"

    #: Roles a visitor may never obtain by registering on the public site.
    STAFF_ONLY = (SUPER_ADMIN, ADMIN, EMPLOYEE, INSTRUCTOR)
    SELF_SERVICE = (STUDENT, PARENT)


class AccountStatus(_Values):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DELETED = "deleted"


class OtpPurpose(_Values):
    REGISTER = "register"                  # to the account holder's address
    GUARDIAN = "guardian"                  # to a guardian, always a distinct code
    PASSWORD_RESET = "password_reset"
    EMAIL_CHANGE = "email_change"


class EmployeeKind(_Values):
    INSTRUCTOR = "instructor"
    EDITOR = "editor"
    SUPPORT = "support"
    ANALYST = "analyst"
    OTHER = "other"


class AuditAction(_Values):
    LOGIN_SUCCESS = "auth.login"
    LOGIN_FAILURE = "auth.login_failed"
    LOGOUT = "auth.logout"
    PASSWORD_RESET = "account.password_reset"
    ACCOUNT_VERIFIED = "account.verified"
    GUARDIAN_VERIFIED = "account.guardian_verified"
    ACCOUNT_SUSPEND = "account.suspend"
    ACCOUNT_RESTORE = "account.restore"
    STAFF_CREATE = "staff.create"
    ROLE_ASSIGN = "role.assign"
    ROLE_REVOKE = "role.revoke"
    MEDIA_UPLOAD = "media.upload"
    MEDIA_DELETE = "media.delete"
