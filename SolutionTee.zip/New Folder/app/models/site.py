"""Site images.

The public templates have a fixed set of image slots - the homepage
hero, the CBT screenshot, a photograph for each learning mode. Each slot
is a named key that points at one `Media` row.

Deliberately a keyed table rather than a page builder. The slots are
structural: they exist because a template has a hole of a known shape and
aspect ratio in a known place. Letting an administrator invent arbitrary
slots would not help them and would let the templates and the data drift
apart.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin
from app.models.media import Media


class SiteImage(Base, TimestampMixin):
    __tablename__ = "site_images"

    id: Mapped[int] = mapped_column(primary_key=True)
    #: One of app.content.site_slots.SLOTS. Unique: a slot holds one image.
    slot: Mapped[str] = mapped_column(String(64), unique=True, index=True,
                                      nullable=False)
    media_id: Mapped[int | None] = mapped_column(
        # SET NULL rather than CASCADE: if an image is force-deleted, the
        # slot must survive and fall back to its placeholder. Deleting the
        # row would lose the slot's history and its assignment record.
        ForeignKey("media.id", ondelete="SET NULL"), nullable=True,
    )
    updated_by_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    assigned_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    media: Mapped[Media | None] = relationship(lazy="joined")

    def __repr__(self) -> str:
        return f"<SiteImage {self.slot}>"
