"""OTP tokens, login attempts and the audit trail.

Codes are stored hashed, never in plain text, and never logged.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    Boolean, DateTime, ForeignKey, Index, Integer, String, Text,
)
from sqlalchemy import JSON
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin


class OtpToken(Base):
    """A single-use verification code.

    The code itself is never stored. Verification hashes the submitted
    value and compares digests, so a database read cannot reveal a live
    code. Consumed and expired rows are kept briefly for audit.
    """

    __tablename__ = "otp_tokens"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    purpose: Mapped[str] = mapped_column(String(24), nullable=False)
    #: Destination address. A guardian code goes somewhere other than the
    #: account's own email, so it is recorded per token.
    sent_to: Mapped[str] = mapped_column(String(255), nullable=False)
    code_hash: Mapped[str] = mapped_column(String(128), nullable=False)

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                 nullable=False)
    consumed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                 nullable=False)

    __table_args__ = (
        Index("ix_otp_user_purpose_created", "user_id", "purpose",
              "created_at"),
    )


class LoginAttempt(Base):
    """Every attempt, successful or not, for rate limiting and audit."""

    __tablename__ = "login_attempts"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(255), nullable=True)
    successful: Mapped[bool] = mapped_column(Boolean, default=False,
                                             nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                 nullable=False, index=True)


class AuditLog(Base):
    """Who did what to whom.

    Written for privileged and security-relevant actions. Never holds a
    password, code or token.
    """

    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    actor_user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    action: Mapped[str] = mapped_column(String(48), nullable=False, index=True)
    #: Free-form target reference, e.g. "user:41" or "media:9f3c".
    target: Mapped[str | None] = mapped_column(String(120), nullable=True)
    summary: Mapped[str] = mapped_column(Text, default="", nullable=False)
    # JSONB in PostgreSQL, which is what production runs. The plain JSON
    # variant exists so the isolated test suite can use SQLite; nothing in
    # the production path depends on it.
    context: Mapped[dict | None] = mapped_column(
        JSON().with_variant(JSONB, "postgresql"), nullable=True
    )
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                 nullable=False, index=True)

    __table_args__ = (
        Index("ix_audit_action_created", "action", "created_at"),
    )
