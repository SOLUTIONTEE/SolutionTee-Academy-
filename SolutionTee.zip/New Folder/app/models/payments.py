"""Offerings, enrolments, payments and the ledger.

Money is stored as an integer number of kobo, never as a float. 0.1 + 0.2
is not 0.3 in binary floating point, and a rounding error in a fee is a
real naira somebody has to account for. Paystack also works in kobo, so
this avoids a conversion at the boundary.

Financial history is append-only in spirit: a negotiated price or a
waiver is recorded as an adjustment row, not by rewriting the amount that
was originally agreed.
"""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    JSON, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index,
    Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, PublicIdMixin, SlugMixin, TimestampMixin

JSON_TYPE = JSON().with_variant(JSONB, "postgresql")


class Offering(Base, PublicIdMixin, SlugMixin, TimestampMixin):
    """Something a student can actually pay for.

    A programme is a subject area; an offering is one purchasable
    instance of it - JAMB, online, this session, at this price.
    """

    __tablename__ = "offerings"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(160), nullable=False)
    #: Matches app.content.programmes, e.g. "jamb" or "waec".
    programme_slug: Mapped[str] = mapped_column(String(40), nullable=False,
                                                index=True)
    #: "online", "physical" or "hybrid".
    mode: Mapped[str] = mapped_column(String(20), nullable=False)
    summary: Mapped[str] = mapped_column(Text, default="", nullable=False)

    #: The full price, in kobo. 50000 naira is 5_000_000.
    price_kobo: Mapped[int] = mapped_column(Integer, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="NGN",
                                          nullable=False)

    starts_on: Mapped[date | None] = mapped_column(Date, nullable=True)
    ends_on: Mapped[date | None] = mapped_column(Date, nullable=True)
    registration_closes_on: Mapped[date | None] = mapped_column(Date,
                                                                nullable=True)
    #: None means no cap.
    capacity: Mapped[int | None] = mapped_column(Integer, nullable=True)

    is_published: Mapped[bool] = mapped_column(Boolean, default=False,
                                               nullable=False, index=True)

    plans: Mapped[list["PaymentPlan"]] = relationship(
        back_populates="offering", cascade="all, delete-orphan",
    )

    __table_args__ = (
        # A negative or zero price is never intentional.
        CheckConstraint("price_kobo > 0", name="ck_offering_price_positive"),
    )

    @property
    def price_naira(self) -> str:
        return f"{self.price_kobo / 100:,.2f}"

    def __repr__(self) -> str:
        return f"<Offering {self.slug}>"


class PaymentPlan(Base, TimestampMixin):
    """How an offering may be paid for.

    Instalments are stored as a list of percentages with day offsets,
    rather than a hard-coded "half now, half later". A centre that wants
    three payments, or 30/30/40, configures it here instead of needing a
    code change.
    """

    __tablename__ = "payment_plans"

    id: Mapped[int] = mapped_column(primary_key=True)
    offering_id: Mapped[int] = mapped_column(
        ForeignKey("offerings.id", ondelete="CASCADE"), nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    #: [{"percent": 50, "due_day_offset": 0}, {"percent": 50, "offset": 30}]
    #: Percentages must total 100; the service enforces it on save.
    instalments: Mapped[list] = mapped_column(JSON_TYPE, default=list,
                                              nullable=False)
    #: Days after a due date before access is restricted.
    grace_days: Mapped[int] = mapped_column(Integer, default=7,
                                            nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False,
                                             nullable=False)

    offering: Mapped[Offering] = relationship(back_populates="plans")

    def __repr__(self) -> str:
        return f"<PaymentPlan {self.name}>"


class EnrolmentStatus:
    PENDING = "pending"        # created, nothing paid yet
    ACTIVE = "active"          # paid enough to have access
    OVERDUE = "overdue"        # an instalment is past its grace period
    COMPLETED = "completed"    # fully paid and finished
    CANCELLED = "cancelled"


class Enrolment(Base, PublicIdMixin, TimestampMixin):
    """One student on one offering."""

    __tablename__ = "enrolments"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    offering_id: Mapped[int] = mapped_column(
        ForeignKey("offerings.id", ondelete="RESTRICT"), nullable=False,
        index=True,
    )
    plan_id: Mapped[int | None] = mapped_column(
        ForeignKey("payment_plans.id", ondelete="SET NULL"), nullable=True
    )

    status: Mapped[str] = mapped_column(String(16),
                                        default=EnrolmentStatus.PENDING,
                                        nullable=False, index=True)

    #: What this student actually owes, in kobo. Copied from the offering
    #: at enrolment so a later price change does not silently alter an
    #: agreement already made, and adjusted only through the ledger.
    agreed_price_kobo: Mapped[int] = mapped_column(Integer, nullable=False)

    #: Access runs to here. None means access follows payment state only.
    access_until: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    user = relationship("User")
    offering: Mapped[Offering] = relationship()
    plan: Mapped[PaymentPlan | None] = relationship()
    payments: Mapped[list["Payment"]] = relationship(
        back_populates="enrolment", cascade="all, delete-orphan",
    )
    adjustments: Mapped[list["PaymentAdjustment"]] = relationship(
        back_populates="enrolment", cascade="all, delete-orphan",
    )

    __table_args__ = (
        # One live enrolment per student per offering. Re-enrolling after
        # cancelling is handled by reactivating, not by a second row.
        UniqueConstraint("user_id", "offering_id",
                         name="uq_enrolment_user_offering"),
        CheckConstraint("agreed_price_kobo >= 0",
                        name="ck_enrolment_price_not_negative"),
    )

    def __repr__(self) -> str:
        return f"<Enrolment {self.public_id}>"


class PaymentStatus:
    PENDING = "pending"        # reference created, not yet paid
    SUCCESS = "success"
    FAILED = "failed"
    ABANDONED = "abandoned"


class Payment(Base, PublicIdMixin, TimestampMixin):
    """One attempted transaction.

    A row is created before the visitor leaves for the gateway, so a
    payment that succeeds at the bank but never returns here is still
    recoverable: the reference exists and can be verified later.
    """

    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(primary_key=True)
    enrolment_id: Mapped[int] = mapped_column(
        ForeignKey("enrolments.id", ondelete="CASCADE"), nullable=False,
        index=True,
    )
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )

    #: Our reference, generated here and sent to the gateway. Unique so a
    #: replayed webhook cannot create a second payment.
    reference: Mapped[str] = mapped_column(String(64), unique=True,
                                           index=True, nullable=False)
    gateway: Mapped[str] = mapped_column(String(20), default="paystack",
                                         nullable=False)

    #: What we asked for, in kobo. Compared against what the gateway says
    #: was actually paid before anything is granted.
    amount_kobo: Mapped[int] = mapped_column(Integer, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="NGN",
                                          nullable=False)
    status: Mapped[str] = mapped_column(String(16),
                                        default=PaymentStatus.PENDING,
                                        nullable=False, index=True)

    #: Set once, when the gateway is asked directly and confirms. This is
    #: the field that means "money actually arrived".
    verified_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    #: What the gateway reported it received, which may differ from what
    #: was asked for. Kept even when it does not match, as evidence.
    paid_amount_kobo: Mapped[int | None] = mapped_column(Integer,
                                                         nullable=True)
    gateway_reference: Mapped[str | None] = mapped_column(String(80),
                                                          nullable=True)
    #: The provider's own response, for reconciliation and disputes.
    gateway_payload: Mapped[dict | None] = mapped_column(JSON_TYPE,
                                                         nullable=True)
    failure_reason: Mapped[str] = mapped_column(String(255), default="",
                                                nullable=False)

    enrolment: Mapped[Enrolment] = relationship(back_populates="payments")

    __table_args__ = (
        CheckConstraint("amount_kobo > 0", name="ck_payment_amount_positive"),
        Index("ix_payment_status_created", "status", "created_at"),
    )

    @property
    def is_settled(self) -> bool:
        return self.status == PaymentStatus.SUCCESS and self.verified_at is not None

    def __repr__(self) -> str:
        return f"<Payment {self.reference} {self.status}>"


class AdjustmentKind:
    DISCOUNT = "discount"        # negotiated reduction
    WAIVER = "waiver"            # written off
    SURCHARGE = "surcharge"      # added
    CORRECTION = "correction"    # fixing a recording error


class PaymentAdjustment(Base, TimestampMixin):
    """A change to what a student owes, recorded rather than applied.

    Reducing `agreed_price_kobo` in place would erase the fact that a
    discount was ever given, and by whom. An adjustment row keeps the
    original agreement and the reason for the change side by side.
    """

    __tablename__ = "payment_adjustments"

    id: Mapped[int] = mapped_column(primary_key=True)
    enrolment_id: Mapped[int] = mapped_column(
        ForeignKey("enrolments.id", ondelete="CASCADE"), nullable=False,
        index=True,
    )
    kind: Mapped[str] = mapped_column(String(20), nullable=False)
    #: Signed, in kobo. Negative reduces what is owed.
    amount_kobo: Mapped[int] = mapped_column(Integer, nullable=False)
    #: Required. An unexplained financial change is not auditable.
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    #: Who authorised it. Nullable only so deleting a staff account does
    #: not delete the financial record.
    actor_user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    enrolment: Mapped[Enrolment] = relationship(back_populates="adjustments")

    __table_args__ = (
        CheckConstraint("length(reason) > 0", name="ck_adjustment_has_reason"),
    )

    def __repr__(self) -> str:
        return f"<PaymentAdjustment {self.kind} {self.amount_kobo}>"


class WebhookEvent(Base):
    """Every webhook the gateway has delivered.

    The unique gateway event id is what makes processing idempotent: a
    provider retries until it gets a 200, so the same event arrives
    repeatedly and must not be applied twice.
    """

    __tablename__ = "webhook_events"

    id: Mapped[int] = mapped_column(primary_key=True)
    gateway: Mapped[str] = mapped_column(String(20), default="paystack",
                                         nullable=False)
    #: The provider's identifier for this delivery.
    event_id: Mapped[str] = mapped_column(String(120), nullable=False)
    event_type: Mapped[str] = mapped_column(String(60), nullable=False)
    reference: Mapped[str | None] = mapped_column(String(64), nullable=True,
                                                  index=True)
    payload: Mapped[dict | None] = mapped_column(JSON_TYPE, nullable=True)
    processed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                   nullable=False)

    __table_args__ = (
        UniqueConstraint("gateway", "event_id", name="uq_webhook_event"),
    )
