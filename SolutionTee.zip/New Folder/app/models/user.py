"""Accounts and the profile rows attached to them.

One users table holds identity and credentials. Role-specific detail lives
in a profile table, so a student gaining a parent account later does not
require a second login.
"""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    Boolean, Column, Date, DateTime, ForeignKey, Index, String, Table, Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, PublicIdMixin, TimestampMixin
from app.models.enums import AccountStatus
from app.models.rbac import Permission, Role, user_permissions, user_roles

#: A parent may oversee several students, and a student may be linked to
#: both parents. Association rows carry the verification state.
parent_children = Table(
    "parent_children", Base.metadata,
    Column("parent_user_id", ForeignKey("users.id", ondelete="CASCADE"),
           primary_key=True),
    Column("student_user_id", ForeignKey("users.id", ondelete="CASCADE"),
           primary_key=True),
    Column("verified_at", DateTime(timezone=True), nullable=True),
)


class User(Base, PublicIdMixin, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)

    # -- Identity ----------------------------------------------------------
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True,
                                       nullable=False)
    full_name: Mapped[str] = mapped_column(String(120), nullable=False)
    phone: Mapped[str | None] = mapped_column(String(32), nullable=True)
    date_of_birth: Mapped[date | None] = mapped_column(Date, nullable=True)

    # -- Credentials -------------------------------------------------------
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    password_changed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # -- State -------------------------------------------------------------
    status: Mapped[str] = mapped_column(
        String(16), default=AccountStatus.ACTIVE, nullable=False, index=True
    )
    email_verified_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    #: Set when a minor's guardian has confirmed consent. A minor account
    #: stays gated until this is populated.
    guardian_verified_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    guardian_email: Mapped[str | None] = mapped_column(String(255),
                                                       nullable=True)
    guardian_name: Mapped[str | None] = mapped_column(String(120),
                                                      nullable=True)
    last_login_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # -- Authorisation -----------------------------------------------------
    roles: Mapped[list[Role]] = relationship(
        secondary=user_roles, lazy="selectin",
    )
    #: Direct grants sit alongside role grants rather than replacing them.
    extra_permissions: Mapped[list[Permission]] = relationship(
        secondary=user_permissions, lazy="selectin",
    )

    # -- Profiles ----------------------------------------------------------
    student_profile: Mapped["StudentProfile | None"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan",
    )
    parent_profile: Mapped["ParentProfile | None"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan",
    )
    employee_profile: Mapped["EmployeeProfile | None"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan",
    )

    children: Mapped[list["User"]] = relationship(
        secondary=parent_children,
        primaryjoin=lambda: User.id == parent_children.c.parent_user_id,
        secondaryjoin=lambda: User.id == parent_children.c.student_user_id,
        backref="guardians",
    )

    # -- Flask-Login -------------------------------------------------------
    @property
    def is_active(self) -> bool:
        """Flask-Login calls this to decide whether a session may be held."""
        return self.status == AccountStatus.ACTIVE

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def is_anonymous(self) -> bool:
        return False

    def get_id(self) -> str:
        return str(self.id)

    # -- Convenience -------------------------------------------------------
    @property
    def is_verified(self) -> bool:
        return self.email_verified_at is not None

    @property
    def first_name(self) -> str:
        return (self.full_name or "").split(" ")[0]

    def __repr__(self) -> str:
        return f"<User {self.email}>"


Index("ix_users_status_created", User.status, User.created_at.desc())


class StudentProfile(Base, TimestampMixin):
    __tablename__ = "student_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    #: Free text until the developer supplies a controlled school list.
    school_name: Mapped[str | None] = mapped_column(String(160), nullable=True)
    current_class: Mapped[str | None] = mapped_column(String(40), nullable=True)
    target_exam: Mapped[str | None] = mapped_column(String(40), nullable=True)
    state_of_residence: Mapped[str | None] = mapped_column(String(60),
                                                           nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="", nullable=False)

    user: Mapped[User] = relationship(back_populates="student_profile")


class ParentProfile(Base, TimestampMixin):
    __tablename__ = "parent_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    relationship_to_student: Mapped[str | None] = mapped_column(String(40),
                                                                nullable=True)
    contact_preference: Mapped[str] = mapped_column(String(20), default="email",
                                                    nullable=False)

    user: Mapped[User] = relationship(back_populates="parent_profile")


class EmployeeProfile(Base, TimestampMixin):
    __tablename__ = "employee_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    kind: Mapped[str] = mapped_column(String(20), nullable=False)
    job_title: Mapped[str | None] = mapped_column(String(80), nullable=True)
    bio: Mapped[str] = mapped_column(Text, default="", nullable=False)
    is_public: Mapped[bool] = mapped_column(Boolean, default=False,
                                            nullable=False)

    user: Mapped[User] = relationship(back_populates="employee_profile")
