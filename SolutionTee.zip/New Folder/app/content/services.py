"""Registration and support services.

What SolutionTee does FOR a candidate, as opposed to what it teaches
them. Held in code because the list of services is structural — each one
has a page — while what each costs is a fact that belongs in the database
once it has been supplied.

Nothing here quotes a price. None have been given, and a wrong fee on a
registration service is the kind of error somebody only discovers at the
cybercafe with their money already spent.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Service:
    slug: str
    name: str
    #: What a candidate would call this, in their words.
    summary: str
    #: Exactly what SolutionTee does. Concrete verbs only.
    we_do: tuple[str, ...]
    #: Exactly what we do not, so nobody assumes otherwise.
    we_do_not: tuple[str, ...]
    #: What the candidate has to bring or have ready.
    you_need: tuple[str, ...] = field(default_factory=tuple)


SERVICES: tuple[Service, ...] = (
    Service(
        slug="jamb",
        name="JAMB registration",
        summary="Getting your UTME or Direct Entry registration filed correctly.",
        we_do=(
            "Check your subject combination against the brochure for the "
            "course you actually want.",
            "Walk you through the profile code, biometrics and the "
            "registration itself.",
            "Check every entry before submission, because a name or date "
            "typed wrongly is painful to correct afterwards.",
            "Make sure you leave with your profile code, registration "
            "number and printed slip.",
        ),
        we_do_not=(
            "Register on your behalf without you present — biometrics are "
            "yours and cannot be delegated.",
            "Influence your score, your admission or your catchment.",
        ),
        you_need=(
            "Your National Identification Number",
            "An email address you can still open",
            "A phone number that receives SMS",
        ),
    ),
    Service(
        slug="post-utme",
        name="Post-UTME applications",
        summary="Applying for an institution's own screening, before it closes.",
        we_do=(
            "Confirm the institution's current requirements against its own "
            "portal.",
            "Check your O'Level and UTME details match what the form "
            "expects.",
            "Complete the application with you and keep the evidence of "
            "submission.",
        ),
        we_do_not=(
            "Submit without your own portal login.",
            "Promise a screening pass or a place.",
        ),
        you_need=(
            "Your JAMB registration number and result",
            "Your O'Level result",
            "The institution you are applying to",
        ),
    ),
    Service(
        slug="school-forms",
        name="School forms",
        summary="Application forms and the documents that go with them.",
        we_do=(
            "Find the correct form for the programme you want.",
            "Check the supporting documents before you upload them.",
            "Keep a copy of everything submitted, with dates.",
        ),
        we_do_not=(
            "Guarantee a form is still open — windows close without notice.",
        ),
        you_need=(
            "Your results and certificates",
            "A passport photograph",
        ),
    ),
    Service(
        slug="services",
        name="Other services",
        summary="Result checking, corrections, uploads and reprints.",
        we_do=(
            "Check results and print slips.",
            "Help with O'Level upload to JAMB.",
            "Guide you through correction of data where the board allows it.",
        ),
        we_do_not=(
            "Alter a result, or anything held by an examination board.",
        ),
    ),
)

SERVICES_BY_SLUG = {service.slug: service for service in SERVICES}
