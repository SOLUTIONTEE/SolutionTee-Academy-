"""Programme reference data.

Only publicly verifiable facts about the examinations themselves live
here - how many subjects a candidate sits, what the paper contains, who
the examination is for. Nothing about SolutionTee's own fees, dates,
timetables, class sizes or results is invented. Those arrive from the
database once the developer supplies them, and until then the templates
say plainly that they are not published yet.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Programme:
    slug: str
    name: str
    #: Full examination name, spelled out once on the page.
    full_name: str
    #: One sentence. What this examination is and who sits it.
    definition: str
    #: The question this programme answers for a student, in their words.
    student_question: str
    board: str
    modes: tuple[str, ...]
    #: Verifiable structure of the examination.
    structure: tuple[tuple[str, str], ...] = field(default_factory=tuple)
    subjects_note: str = ""


PROGRAMMES: tuple[Programme, ...] = (
    Programme(
        slug="jamb",
        name="JAMB / UTME",
        full_name="Unified Tertiary Matriculation Examination",
        definition=(
            "The examination every candidate sits to be admitted to a "
            "Nigerian university, polytechnic or college of education."
        ),
        student_question="I need a score that gets me the course I want.",
        board="Joint Admissions and Matriculation Board",
        modes=("Online", "Physical", "Hybrid"),
        structure=(
            ("Subjects", "Four. Use of English is compulsory; you choose "
                         "three more to match your course."),
            ("Format", "Computer-based. Multiple choice throughout."),
            ("Marking", "400 marks in total, 100 per subject."),
            ("Where it counts", "Your score sets which courses you may "
                                "apply for, alongside your O-Level result."),
        ),
        subjects_note=(
            "Subject combinations are set by the course you are applying "
            "for, not by preference. We check yours against the JAMB "
            "brochure before you register."
        ),
    ),
    Programme(
        slug="waec",
        name="WAEC",
        full_name="West African Senior School Certificate Examination",
        definition=(
            "The senior secondary school-leaving certificate, sat in the "
            "final year or externally as a private candidate."
        ),
        student_question="I need five credits including English and Maths.",
        board="West African Examinations Council",
        modes=("Online", "Physical", "Hybrid"),
        structure=(
            ("Papers", "Most subjects have an objective paper and a theory "
                       "paper. Sciences add a practical."),
            ("Grading", "A1 to F9. A credit is C6 or better."),
            ("What admission needs", "Five credits, normally including "
                                     "English Language and Mathematics."),
            ("Sittings", "School candidates sit in May/June. Private "
                         "candidates sit the GCE series."),
        ),
        subjects_note=(
            "Theory papers are where marks are lost. Teaching covers how "
            "an examiner allocates them, not only the content."
        ),
    ),
    Programme(
        slug="neco",
        name="NECO",
        full_name="National Examinations Council examination",
        definition=(
            "Nigeria's national senior secondary certificate, accepted for "
            "admission alongside WAEC."
        ),
        student_question="I am sitting NECO and want the grades to count.",
        board="National Examinations Council",
        modes=("Online", "Physical", "Hybrid"),
        structure=(
            ("Papers", "Objective and theory, with practicals in the "
                       "sciences."),
            ("Grading", "A1 to F9, the same credit threshold as WAEC."),
            ("Combining results", "Institutions differ on whether they "
                                  "accept two sittings. Check before you "
                                  "apply."),
        ),
    ),
    Programme(
        slug="gce",
        name="GCE",
        full_name="General Certificate of Education, private candidature",
        definition=(
            "The external sitting, for candidates who are no longer in "
            "school or who need to improve specific grades."
        ),
        student_question=(
            "I need to resit a subject without going back to school."
        ),
        board="WAEC and NECO both run private candidate series",
        modes=("Online", "Physical"),
        structure=(
            ("Who sits it", "Private candidates. You register yourself "
                            "rather than through a school."),
            ("Common use", "Replacing one or two grades that fell below a "
                           "credit."),
            ("Teaching", "Usually a small number of subjects, taught "
                         "intensively."),
        ),
    ),
    Programme(
        slug="post-utme",
        name="Post-UTME",
        full_name="Post-UTME screening",
        definition=(
            "The institution's own screening, sat after JAMB, before a "
            "place is offered."
        ),
        student_question=(
            "I have my JAMB score. What does the school ask for next?"
        ),
        board="Set by each institution, not by JAMB",
        modes=("Online", "Hybrid"),
        structure=(
            ("Format", "Set by the institution. Some screen on documents "
                       "alone, others set a written or computer-based test."),
            ("Scope", "Usually drawn from your four UTME subjects."),
            ("Aggregate", "Most institutions weight UTME, O-Level and "
                          "screening together. The weighting differs."),
            ("Timing", "Opens after UTME results and closes quickly."),
        ),
        subjects_note=(
            "Because each institution sets its own rules, preparation is "
            "specific to where you applied. We work from the school's own "
            "published requirements."
        ),
    ),
    Programme(
        slug="secondary-school",
        name="Secondary School",
        full_name="Secondary school academic support",
        definition=(
            "Term-time teaching for students in JSS and SSS who need "
            "ground held before an examination year arrives."
        ),
        student_question="I am falling behind in class and need to catch up.",
        board="Follows the Nigerian secondary curriculum",
        modes=("Online", "Physical", "Hybrid"),
        structure=(
            ("Who it is for", "JSS 1 to SSS 3."),
            ("Focus", "The subjects a student is actually struggling in, "
                      "not a fixed package."),
            ("Rhythm", "Alongside school, through the term."),
        ),
    ),
)

PROGRAMMES_BY_SLUG = {p.slug: p for p in PROGRAMMES}


@dataclass(frozen=True)
class LearningMode:
    slug: str
    name: str
    #: The trade-off stated honestly, including what this mode costs you.
    summary: str
    suits: str
    requires: str
    details: tuple[str, ...] = field(default_factory=tuple)


LEARNING_MODES: tuple[LearningMode, ...] = (
    LearningMode(
        slug="physical",
        name="Physical",
        summary=(
            "You come to the centre and are taught in a room with a tutor "
            "and other students."
        ),
        suits="Students who do not study well alone, and who can travel.",
        requires="Getting there, on the timetable, most days.",
        details=(
            "A tutor sees when you have stopped following, and stops.",
            "You ask a question the moment it occurs to you.",
            "Other students set a pace you measure yourself against.",
        ),
    ),
    LearningMode(
        slug="online",
        name="Online",
        summary=(
            "You join the same class over the internet, live, and keep the "
            "recording afterwards."
        ),
        suits="Students who cannot travel, or who are outside Lagos.",
        requires="A device, and enough data to hold a video call.",
        details=(
            "Sessions are live, not pre-recorded: you can still ask.",
            "Recordings stay available, so a missed class is recoverable.",
            "Materials download, so revision does not need a connection.",
        ),
    ),
    LearningMode(
        slug="hybrid",
        name="Hybrid",
        summary=(
            "You are taught in the centre and keep the platform for "
            "practice, materials and catch-up between sessions."
        ),
        suits="Students who want the classroom but revise at home.",
        requires="Attending in person, plus using the platform properly.",
        details=(
            "Classroom teaching, with every session also recorded.",
            "CBT practice continues between classes.",
            "A missed session is caught up before the next one.",
        ),
    ),
)

LEARNING_MODES_BY_SLUG = {m.slug: m for m in LEARNING_MODES}
