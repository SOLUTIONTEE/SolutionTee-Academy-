"""Site navigation.

Held in one place so the header, the footer, the mobile menu and the
sitemap all describe the same structure. Nothing here is a fact about
fees, dates or results.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class NavItem:
    label: str
    endpoint_or_path: str
    #: A short line shown in the desktop mega menu. Empty means no summary.
    summary: str = ""

    @property
    def path(self) -> str:
        return self.endpoint_or_path


@dataclass(frozen=True)
class NavGroup:
    label: str
    #: Groups render as a mega-menu column; the intro heads that column.
    intro: str = ""
    items: tuple[NavItem, ...] = field(default_factory=tuple)
    path: str | None = None


PRIMARY_NAV: tuple[NavGroup, ...] = (
    NavGroup(
        label="Programmes",
        intro="Preparation built around one examination.",
        items=(
            NavItem("JAMB / UTME", "/programmes/jamb",
                    "Four subjects, CBT practice and mock examinations."),
            NavItem("WAEC", "/programmes/waec",
                    "Objective, theory and practical preparation."),
            NavItem("NECO", "/programmes/neco",
                    "Subject teaching and structured revision."),
            NavItem("GCE", "/programmes/gce",
                    "For private candidates sitting externally."),
            NavItem("Post-UTME", "/programmes/post-utme",
                    "Screening preparation, by institution."),
            NavItem("Secondary School", "/programmes/secondary-school",
                    "Term-time academic support."),
        ),
    ),
    NavGroup(
        label="Learning",
        intro="Three ways to attend. The teaching is the same.",
        items=(
            NavItem("Online classes", "/learning/online",
                    "Live sessions and recordings, from anywhere."),
            NavItem("Physical classes", "/learning/physical",
                    "Tutor-led, in the centre, to a timetable."),
            NavItem("Hybrid", "/learning/hybrid",
                    "Classroom teaching with platform access."),
            NavItem("Online academy", "/academy",
                    "Self-paced courses you work through alone."),
        ),
    ),
    NavGroup(
        label="Practice",
        intro="Sit questions under real conditions.",
        items=(
            NavItem("CBT practice", "/cbt",
                    "Timed papers in the JAMB interface."),
            NavItem("Mock examinations", "/cbt/mock",
                    "Full papers, scheduled and invigilated."),
            NavItem("Subject practice", "/cbt/subjects",
                    "Work one topic at a time."),
            NavItem("Study materials", "/resources",
                    "Notes, past questions and worked solutions."),
        ),
    ),
    NavGroup(
        label="Admission",
        intro="From your examination to a place on a course.",
        items=(
            NavItem("Universities", "/admission/universities",
                    "Federal, state and private."),
            NavItem("Polytechnics", "/admission/polytechnics",
                    "ND and HND routes."),
            NavItem("Colleges of Education", "/admission/colleges",
                    "NCE programmes."),
            NavItem("Schools of Nursing", "/admission/nursing",
                    "Nursing and allied health."),
            NavItem("Direct Entry", "/admission/direct-entry",
                    "IJMB, JUPEB, ND and NCE holders."),
            NavItem("Admission guidance", "/admission/guidance",
                    "Choosing a course you can actually get."),
        ),
    ),
    NavGroup(
        label="Registration",
        intro="We help you file it correctly, the first time.",
        items=(
            NavItem("JAMB registration", "/registration/jamb",
                    "Profile code, biometrics and subject selection."),
            NavItem("Post-UTME applications", "/registration/post-utme",
                    "Per institution, before each deadline."),
            NavItem("School forms", "/registration/school-forms",
                    "Application forms and supporting documents."),
            NavItem("Other services", "/registration/services",
                    "Result checking, corrections and uploads."),
        ),
    ),
    NavGroup(label="Updates", path="/updates",
             intro="Examination news, deadlines and guides."),
    NavGroup(label="About", path="/about"),
    NavGroup(label="Contact", path="/contact"),
)

#: The header only has room for a few groups before it stops being usable.
#: The rest move into the mobile menu and the footer.
HEADER_GROUPS: tuple[str, ...] = (
    "Programmes", "Learning", "Practice", "Admission", "Registration",
)

FOOTER_NAV: tuple[NavGroup, ...] = (
    NavGroup(
        label="Prepare",
        items=(
            NavItem("JAMB / UTME", "/programmes/jamb"),
            NavItem("WAEC", "/programmes/waec"),
            NavItem("NECO", "/programmes/neco"),
            NavItem("GCE", "/programmes/gce"),
            NavItem("Post-UTME", "/programmes/post-utme"),
        ),
    ),
    NavGroup(
        label="Learn",
        items=(
            NavItem("Online classes", "/learning/online"),
            NavItem("Physical classes", "/learning/physical"),
            NavItem("Hybrid", "/learning/hybrid"),
            NavItem("Online academy", "/academy"),
        ),
    ),
    NavGroup(
        label="Practise",
        items=(
            NavItem("CBT practice", "/cbt"),
            NavItem("Mock examinations", "/cbt/mock"),
            NavItem("Study materials", "/resources"),
        ),
    ),
    NavGroup(
        label="Apply",
        items=(
            NavItem("Universities", "/admission/universities"),
            NavItem("Polytechnics", "/admission/polytechnics"),
            NavItem("Direct Entry", "/admission/direct-entry"),
            NavItem("JAMB registration", "/registration/jamb"),
        ),
    ),
    NavGroup(
        label="SolutionTee",
        items=(
            NavItem("About", "/about"),
            NavItem("Education updates", "/updates"),
            NavItem("For parents", "/parents"),
            NavItem("Contact", "/contact"),
        ),
    ),
)
