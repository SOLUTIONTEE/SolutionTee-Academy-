"""The image slots the public templates expose.

Each entry describes a hole in a template: where it is, what shape it is,
and what photograph actually belongs there. The guidance is written for
whoever is choosing the image, so the admin page can tell them what the
slot is for rather than showing a bare key.

Adding a slot here and referencing it from a template is the whole of
adding a new managed image.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ImageSlot:
    key: str
    name: str
    #: Where it appears, in the words of someone looking at the site.
    location: str
    #: What photograph belongs here. Concrete, not "an engaging image".
    guidance: str
    #: The CSS aspect-ratio class the template uses, so the admin preview
    #: matches what the visitor will see.
    ratio: str
    #: Rendered at roughly this width on a large screen, so an
    #: administrator can tell whether their file is big enough.
    display_width: int


SLOTS: tuple[ImageSlot, ...] = (
    ImageSlot(
        key="homepage.hero",
        name="Homepage hero",
        location="Beside “Learn. Prepare. Progress.” at the top of the homepage",
        guidance=(
            "A SolutionTee class in session. Students working, tutor "
            "present. Portrait orientation, because it sits in a tall "
            "column beside the headline."
        ),
        ratio="media--portrait",
        display_width=480,
    ),
    ImageSlot(
        key="homepage.cbt",
        name="CBT section",
        location="The dark “Sit the paper before you sit the paper” section",
        guidance=(
            "Students at computers during CBT practice, or a screenshot of "
            "the CBT interface once it is built. Landscape."
        ),
        ratio="media--16x9",
        display_width=620,
    ),
    ImageSlot(
        key="learning.physical",
        name="Physical learning",
        location="The Physical learning page",
        guidance="A classroom at the centre, mid-lesson. Landscape.",
        ratio="media--4x3",
        display_width=520,
    ),
    ImageSlot(
        key="learning.online",
        name="Online learning",
        location="The Online learning page",
        guidance=(
            "A student joining a live session from home, or a tutor "
            "teaching to camera. Landscape."
        ),
        ratio="media--4x3",
        display_width=520,
    ),
    ImageSlot(
        key="learning.hybrid",
        name="Hybrid learning",
        location="The Hybrid learning page",
        guidance=(
            "A classroom where students are also using the platform. "
            "Landscape."
        ),
        ratio="media--4x3",
        display_width=520,
    ),
)

SLOTS_BY_KEY = {slot.key: slot for slot in SLOTS}
