"""Extension singletons.

Kept in their own module so models, services and the factory can import
them without importing the application package and creating a cycle.
"""
from __future__ import annotations

from flask_caching import Cache
from flask_compress import Compress
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect

from app.models.base import Base

# model_class=Base keeps the SQLAlchemy 2.0 typed DeclarativeBase while
# still giving Flask-SQLAlchemy the session and engine management.
db = SQLAlchemy(model_class=Base)
migrate = Migrate()
csrf = CSRFProtect()
cache = Cache()
compress = Compress()

limiter = Limiter(key_func=get_remote_address, default_limits=[])

login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Sign in to continue."
login_manager.login_message_category = "info"
login_manager.session_protection = "strong"


@login_manager.user_loader
def load_user(user_id: str):
    from app.models.user import User

    return db.session.get(User, int(user_id)) if user_id.isdigit() else None
