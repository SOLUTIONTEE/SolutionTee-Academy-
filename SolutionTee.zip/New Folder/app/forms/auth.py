"""Authentication forms.

WTForms gives CSRF and server-side validation in one place. Client-side
attributes are conveniences; the validation that counts happens here.
"""
from __future__ import annotations

from datetime import date

from flask import current_app
from flask_wtf import FlaskForm
from wtforms import (
    BooleanField, DateField, PasswordField, RadioField, StringField,
)
from wtforms.validators import (
    DataRequired, Email, EqualTo, Length, Optional, ValidationError,
)

from app.models.enums import RoleName
from app.services.security.passwords import (
    MIN_LENGTH, PasswordError, validate as validate_password,
)


def _email_field(label: str = "Email", **kwargs):
    return StringField(
        label,
        validators=[
            DataRequired(message="Enter your email address."),
            # check_deliverability=False is deliberate. By default this
            # validator resolves the domain's MX records, putting a DNS
            # lookup in front of every submission: slow when the network
            # is, and a hard failure when it is unreachable. Whether an
            # address can actually receive mail is proven by sending to
            # it, which the verification flow does.
            Email(message="That does not look like an email address.",
                  check_deliverability=False),
            Length(max=255),
        ],
        filters=[lambda value: (value or "").strip().lower()],
        **kwargs,
    )


class LoginForm(FlaskForm):
    email = _email_field()
    password = PasswordField(
        "Password",
        validators=[DataRequired(message="Enter your password.")],
    )
    remember = BooleanField("Keep me signed in")


class RegisterForm(FlaskForm):
    """Public registration.

    The role choices are students and parents only. Staff accounts are
    made by an administrator; the service layer refuses anything else
    even if this field is tampered with.
    """

    account_type = RadioField(
        "I am",
        choices=[(RoleName.STUDENT, "A student"),
                 (RoleName.PARENT, "A parent or guardian")],
        default=RoleName.STUDENT,
        validators=[DataRequired(message="Choose one.")],
    )
    full_name = StringField(
        "Full name",
        validators=[DataRequired(message="Enter your full name."),
                    Length(min=2, max=120)],
        filters=[lambda value: (value or "").strip()],
    )
    email = _email_field()
    phone = StringField("Phone (optional)", validators=[Optional(),
                                                        Length(max=32)])
    date_of_birth = DateField(
        "Date of birth",
        validators=[Optional()],
        description="Students under 18 need a parent or guardian to confirm.",
    )
    guardian_name = StringField("Parent or guardian name",
                                validators=[Optional(), Length(max=120)])
    guardian_email = StringField(
        "Parent or guardian email",
        validators=[Optional(),
                    Email(message="That does not look like an email address.",
                          check_deliverability=False),
                    Length(max=255)],
        filters=[lambda value: (value or "").strip().lower()],
    )
    password = PasswordField(
        "Password",
        validators=[DataRequired(message="Choose a password."),
                    Length(min=MIN_LENGTH,
                           message=f"Use at least {MIN_LENGTH} characters.")],
    )
    confirm = PasswordField(
        "Confirm password",
        validators=[DataRequired(message="Type your password again."),
                    EqualTo("password", message="Those do not match.")],
    )

    def validate_date_of_birth(self, field):
        if field.data is None:
            return
        if field.data > date.today():
            raise ValidationError("That date is in the future.")
        if field.data.year < 1900:
            raise ValidationError("Check that date.")

    def validate_password(self, field):
        """Apply the shared password policy.

        Here rather than only in the service so the person gets the
        reason next to the field they typed it into.
        """
        try:
            validate_password(field.data, email=self.email.data or "",
                              full_name=self.full_name.data or "")
        except PasswordError as exc:
            raise ValidationError(str(exc)) from exc

    def validate(self, extra_validators=None) -> bool:
        """Run the field rules, then the guardian rule.

        The guardian check lives here rather than in a
        validate_guardian_email hook because that field carries
        Optional(), which raises StopValidation on an empty value and
        halts the rest of its chain - including the inline validator.
        An empty guardian address is exactly the case that matters, so
        the check has to run outside that chain.
        """
        ok = super().validate(extra_validators=extra_validators)
        if not self._guardian_is_acceptable():
            ok = False
        return ok

    def _guardian_is_acceptable(self) -> bool:
        """A minor must give a guardian address, and not their own.

        Letting a student use their own address as their guardian's would
        make the consent step meaningless.
        """
        if self.account_type.data != RoleName.STUDENT:
            return True

        threshold = current_app.config["MINOR_AGE_THRESHOLD"]
        born = self.date_of_birth.data
        if born is not None:
            today = date.today()
            years = (today.year - born.year
                     - ((today.month, today.day) < (born.month, born.day)))
            if years >= threshold:
                return True
        # An unknown date of birth counts as a minor, matching the
        # service: otherwise leaving the field blank would skip consent.

        given = (self.guardian_email.data or "").strip().lower()
        if not given:
            self.guardian_email.errors = list(self.guardian_email.errors) + [
                f"Students under {threshold} need a parent or guardian "
                f"email address."
            ]
            return False
        if given == (self.email.data or "").strip().lower():
            self.guardian_email.errors = list(self.guardian_email.errors) + [
                "This must be a parent or guardian address, not your own."
            ]
            return False
        return True


class OtpForm(FlaskForm):
    code = StringField(
        "Code",
        validators=[DataRequired(message="Enter the code we emailed."),
                    Length(min=4, max=10)],
        filters=[lambda value: (value or "").strip().replace(" ", "")],
    )


class ForgotPasswordForm(FlaskForm):
    email = _email_field()


class ResetPasswordForm(FlaskForm):
    password = PasswordField(
        "New password",
        validators=[DataRequired(message="Choose a password."),
                    Length(min=MIN_LENGTH,
                           message=f"Use at least {MIN_LENGTH} characters.")],
    )
    confirm = PasswordField(
        "Confirm new password",
        validators=[DataRequired(message="Type your password again."),
                    EqualTo("password", message="Those do not match.")],
    )

    def validate_password(self, field):
        try:
            validate_password(field.data)
        except PasswordError as exc:
            raise ValidationError(str(exc)) from exc
