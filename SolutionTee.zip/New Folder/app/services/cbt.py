"""The examination engine.

Every rule that could be cheated is enforced here, on the server:

- **Time.** `expires_at` is computed once at start and stored. Every
  write re-reads it. A candidate who changes their system clock, edits
  the countdown in devtools, or leaves the tab open overnight gains
  nothing.
- **The paper.** Questions and their order are frozen at start, so
  reloading cannot reroll a randomised draw and editing the bank cannot
  change a paper somebody is sitting.
- **The answers.** `is_correct` is joined only when marking. Nothing
  that reaches an open attempt's page contains it.
- **Attempt limits.** Counted from rows, not from anything the client
  sends.
"""
from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.base import as_utc, utcnow
from app.models.cbt import (
    Answer, Attempt, AttemptQuestion, AttemptStatus, Choice, Exam, Question,
    QuestionKind, ResultVisibility,
)
from app.services import payments

logger = logging.getLogger(__name__)


class CbtError(RuntimeError):
    """Something the candidate should be told about."""


@dataclass(frozen=True)
class Eligibility:
    allowed: bool
    reason: str = ""
    message: str = ""
    attempts_used: int = 0
    attempts_left: int | None = None


# ---------------------------------------------------------------------------
# Eligibility
# ---------------------------------------------------------------------------

def attempts_used(user, exam: Exam) -> int:
    """Sittings that count against the limit.

    An abandoned attempt still counts: otherwise a candidate could start
    a mock, read the paper, walk away, and start again with the
    questions already known.
    """
    return db.session.scalar(
        select(func.count())
        .select_from(Attempt)
        .where(Attempt.user_id == user.id, Attempt.exam_id == exam.id)
    ) or 0


def can_start(user, exam: Exam) -> Eligibility:
    """Whether this candidate may begin a new attempt."""
    if not exam.is_published:
        return Eligibility(False, "unpublished",
                           "This paper is not available.")

    if user is None or not getattr(user, "is_authenticated", False):
        return Eligibility(False, "anonymous",
                           "Sign in to sit this paper.")

    now = utcnow()
    if exam.opens_at and as_utc(exam.opens_at) > now:
        return Eligibility(
            False, "not_open",
            f"This paper opens on "
            f"{as_utc(exam.opens_at).strftime('%d %B at %H:%M')} UTC.",
        )
    if exam.closes_at and as_utc(exam.closes_at) < now:
        return Eligibility(False, "closed", "This paper has closed.")

    if exam.offering_id is not None:
        enrolment = db.session.scalar(
            select(payments.Enrolment).where(
                payments.Enrolment.user_id == user.id,
                payments.Enrolment.offering_id == exam.offering_id,
            )
        )
        if enrolment is None:
            return Eligibility(False, "not_enrolled",
                               "Enrol on this programme to sit the paper.")
        if not payments.has_access(enrolment):
            return Eligibility(False, "unpaid",
                               "Your first payment opens this paper.")

    used = attempts_used(user, exam)
    if exam.max_attempts is not None:
        left = exam.max_attempts - used
        if left <= 0:
            return Eligibility(
                False, "no_attempts_left",
                f"You have used all {exam.max_attempts} attempts at this "
                f"paper.",
                attempts_used=used, attempts_left=0,
            )
        return Eligibility(True, attempts_used=used, attempts_left=left)

    return Eligibility(True, attempts_used=used, attempts_left=None)


def open_attempt_for(user, exam: Exam) -> Attempt | None:
    """An attempt already in progress, if there is one.

    Returning to a paper resumes it rather than starting a second, which
    is both what a candidate expects and what stops a refresh consuming
    an attempt.
    """
    return db.session.scalar(
        select(Attempt)
        .where(Attempt.user_id == user.id, Attempt.exam_id == exam.id,
               Attempt.status == AttemptStatus.IN_PROGRESS)
        .order_by(Attempt.started_at.desc())
    )


# ---------------------------------------------------------------------------
# Starting
# ---------------------------------------------------------------------------

def _draw_questions(exam: Exam) -> list[Question]:
    """Select the questions for one paper.

    Only active questions are ever drawn. A bank row starts inactive so
    nothing reaches a candidate before somebody has reviewed it and
    recorded where it came from.
    """
    statement = select(Question).where(Question.is_active.is_(True))
    if exam.subject_id is not None:
        statement = statement.where(Question.subject_id == exam.subject_id)
    # question_pool, not exam_type: the first says which syllabus the
    # questions come from, the second says how the paper is sat.
    if exam.question_pool:
        statement = statement.where(Question.exam_type == exam.question_pool)

    available = list(db.session.scalars(
        statement.options(selectinload(Question.choices))
    ))

    if not available:
        raise CbtError(
            "This paper has no questions yet. Nothing has been published "
            "to the bank for it."
        )

    if exam.randomise_questions:
        random.shuffle(available)
    else:
        available.sort(key=lambda q: q.id)

    # Fewer available than asked for means a shorter paper, not an error:
    # a practice set being half-written should still be usable.
    return available[: exam.question_count]


def start_attempt(user, exam: Exam) -> Attempt:
    """Begin a sitting, freezing the paper and the clock."""
    eligibility = can_start(user, exam)
    if not eligibility.allowed:
        raise CbtError(eligibility.message)

    existing = open_attempt_for(user, exam)
    if existing is not None:
        # Already sitting it. Resume rather than consume another attempt.
        return existing

    questions = _draw_questions(exam)
    now = utcnow()

    attempt = Attempt(
        user_id=user.id,
        exam_id=exam.id,
        started_at=now,
        # The authoritative clock. Everything else is decoration.
        expires_at=now + timedelta(minutes=exam.duration_minutes),
        status=AttemptStatus.IN_PROGRESS,
    )
    db.session.add(attempt)
    db.session.flush()

    for position, question in enumerate(questions):
        order = [choice.id for choice in question.choices]
        if exam.randomise_choices and order:
            random.shuffle(order)
        db.session.add(AttemptQuestion(
            attempt_id=attempt.id, question_id=question.id,
            position=position, choice_order=order or None,
        ))

    db.session.commit()
    logger.info("Attempt %s started by user %s on exam %s",
                attempt.public_id, user.public_id, exam.slug)
    return attempt


# ---------------------------------------------------------------------------
# Time
# ---------------------------------------------------------------------------

def seconds_remaining(attempt: Attempt) -> int:
    """Time left, from the stored deadline. Never negative."""
    delta = as_utc(attempt.expires_at) - utcnow()
    return max(0, int(delta.total_seconds()))


def has_expired(attempt: Attempt) -> bool:
    return seconds_remaining(attempt) <= 0


def enforce_deadline(attempt: Attempt) -> Attempt:
    """Auto-submit an attempt whose time has run out.

    Called at the start of every read and every write. A candidate who
    closes the tab at the deadline and returns an hour later gets the
    paper marked as it stood, not extra time.
    """
    if attempt.status == AttemptStatus.IN_PROGRESS and has_expired(attempt):
        logger.info("Attempt %s expired; auto-submitting", attempt.public_id)
        submit(attempt, expired=True)
    return attempt


# ---------------------------------------------------------------------------
# Answering
# ---------------------------------------------------------------------------

def _question_in_attempt(attempt: Attempt, question_id: int) -> bool:
    """A candidate may only answer questions on their own paper."""
    return any(link.question_id == question_id for link in attempt.questions)


def save_answer(attempt: Attempt, *, question_id: int,
                choice_ids: list[int] | None = None, value: str = "",
                flagged: bool | None = None) -> Answer:
    """Record an answer. Idempotent per question.

    Refuses once the deadline has passed, which is the check that makes
    the client-side countdown a courtesy rather than a control.
    """
    enforce_deadline(attempt)
    if attempt.status != AttemptStatus.IN_PROGRESS:
        raise CbtError("This attempt is closed. Your answers were saved.")

    if not _question_in_attempt(attempt, question_id):
        # Answering a question that is not on your paper is either a bug
        # or an attempt to probe the bank.
        logger.warning("Attempt %s tried to answer question %s not on its "
                       "paper", attempt.public_id, question_id)
        raise CbtError("That question is not on this paper.")

    # Only choices that belong to this question count, whatever was
    # posted: otherwise a crafted request could attach another
    # question's choice ids.
    cleaned: list[int] = []
    if choice_ids:
        valid = set(db.session.scalars(
            select(Choice.id).where(Choice.question_id == question_id)
        ))
        cleaned = [cid for cid in choice_ids if cid in valid]

    answer = db.session.scalar(
        select(Answer).where(Answer.attempt_id == attempt.id,
                             Answer.question_id == question_id)
    )
    if answer is None:
        answer = Answer(attempt_id=attempt.id, question_id=question_id,
                        answered_at=utcnow())
        db.session.add(answer)

    answer.selected_choice_ids = cleaned or None
    answer.value = (value or "").strip()[:255]
    if flagged is not None:
        answer.is_flagged = bool(flagged)
    answer.answered_at = utcnow()

    db.session.commit()
    return answer


def answers_map(attempt: Attempt) -> dict[int, Answer]:
    return {answer.question_id: answer for answer in attempt.answers}


# ---------------------------------------------------------------------------
# Marking
# ---------------------------------------------------------------------------

def _is_answer_correct(question: Question, answer: Answer | None) -> bool:
    if answer is None or not answer.is_answered:
        return False

    if question.kind in (QuestionKind.SINGLE, QuestionKind.MULTIPLE):
        correct = {c.id for c in question.choices if c.is_correct}
        chosen = set(answer.selected_choice_ids or [])
        # Exact match: a multiple-answer question is not partly right.
        return bool(correct) and chosen == correct

    if question.kind == QuestionKind.NUMERIC:
        try:
            given = float(answer.value)
            expected = float(question.correct_value)
        except (TypeError, ValueError):
            return False
        tolerance = question.numeric_tolerance or 0.0
        return abs(given - expected) <= tolerance

    if question.kind == QuestionKind.TEXT:
        # Case and surrounding space are not what is being examined.
        return (answer.value.strip().casefold()
                == question.correct_value.strip().casefold())

    return False


def submit(attempt: Attempt, *, expired: bool = False) -> Attempt:
    """Mark and close an attempt. Idempotent.

    Marking happens once. Re-submitting a closed attempt returns it
    unchanged rather than re-marking, so a double-clicked button or a
    retried request cannot alter a recorded score.
    """
    if attempt.status != AttemptStatus.IN_PROGRESS:
        return attempt

    answers = answers_map(attempt)
    score = 0
    breakdown: dict[str, dict[str, int]] = {}

    for link in attempt.questions:
        question = link.question
        answer = answers.get(question.id)
        correct = _is_answer_correct(question, answer)

        if answer is not None:
            # Written now, not while the attempt was open: a row carrying
            # is_correct mid-attempt would be readable evidence.
            answer.is_correct = correct
        if correct:
            score += 1

        topic = question.topic or "Unclassified"
        bucket = breakdown.setdefault(topic, {"correct": 0, "total": 0})
        bucket["total"] += 1
        if correct:
            bucket["correct"] += 1

    attempt.score = score
    attempt.total = len(attempt.questions)
    attempt.topic_breakdown = breakdown
    attempt.submitted_at = utcnow()
    attempt.status = (AttemptStatus.EXPIRED if expired
                      else AttemptStatus.SUBMITTED)

    db.session.commit()
    logger.info("Attempt %s marked: %s/%s", attempt.public_id, score,
                attempt.total)
    return attempt


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ResultView:
    """What a candidate is permitted to see about their own attempt."""

    show_score: bool
    show_answers: bool
    show_explanations: bool
    message: str = ""


def result_view(attempt: Attempt) -> ResultView:
    """Apply the exam's result visibility rule.

    Practice shows everything immediately, because that is how somebody
    learns. A mock sat under conditions may show only a score, or
    nothing until staff release it - otherwise the first candidate to
    finish can tell everyone else the answers.
    """
    exam = attempt.exam
    rule = exam.result_visibility

    if attempt.status == AttemptStatus.IN_PROGRESS:
        return ResultView(False, False, False,
                          "This attempt is still open.")

    if rule == ResultVisibility.IMMEDIATE:
        return ResultView(True, True, True)

    if rule == ResultVisibility.SCORE_ONLY:
        return ResultView(True, False, False,
                          "Answers are not shown for this paper.")

    if rule == ResultVisibility.AFTER_CLOSE:
        closed = exam.closes_at and as_utc(exam.closes_at) <= utcnow()
        if closed:
            return ResultView(True, True, True)
        return ResultView(
            False, False, False,
            "Results are released after the paper closes for everyone.",
        )

    return ResultView(False, False, False,
                      "Results for this paper are not shown here.")


@dataclass
class TopicResult:
    topic: str
    correct: int
    total: int

    @property
    def percent(self) -> int:
        return round(self.correct / self.total * 100) if self.total else 0


def topic_results(attempt: Attempt) -> list[TopicResult]:
    """Weakest topics first: that is what to revise."""
    rows = [TopicResult(topic=topic, correct=data["correct"],
                        total=data["total"])
            for topic, data in (attempt.topic_breakdown or {}).items()]
    rows.sort(key=lambda r: (r.percent, -r.total))
    return rows


def attempt_history(user, exam: Exam | None = None) -> list[Attempt]:
    statement = (
        select(Attempt)
        .options(selectinload(Attempt.exam))
        .where(Attempt.user_id == user.id)
        .order_by(Attempt.started_at.desc())
    )
    if exam is not None:
        statement = statement.where(Attempt.exam_id == exam.id)
    return list(db.session.scalars(statement))


# ---------------------------------------------------------------------------
# Rendering a paper
# ---------------------------------------------------------------------------

@dataclass
class PresentedChoice:
    id: int
    body_html: str


@dataclass
class PresentedQuestion:
    """A question as the candidate sees it.

    Deliberately a separate shape from the model. Serialising `Question`
    directly is how `is_correct` ends up in a template context, and from
    there in the page source.
    """

    position: int
    question_id: int
    public_id: str
    kind: str
    stem_html: str
    choices: list[PresentedChoice] = field(default_factory=list)
    media_id: int | None = None
    selected_choice_ids: list[int] = field(default_factory=list)
    value: str = ""
    is_flagged: bool = False

    @property
    def is_answered(self) -> bool:
        return bool(self.selected_choice_ids) or bool(self.value.strip())


def present_paper(attempt: Attempt) -> list[PresentedQuestion]:
    """Build the paper for display, without any correct answers in it."""
    answers = answers_map(attempt)
    presented: list[PresentedQuestion] = []

    for link in sorted(attempt.questions, key=lambda l: l.position):
        question = link.question
        answer = answers.get(question.id)

        by_id = {choice.id: choice for choice in question.choices}
        order = link.choice_order or [c.id for c in question.choices]
        choices = [
            PresentedChoice(id=cid, body_html=by_id[cid].body_html)
            for cid in order if cid in by_id
        ]

        presented.append(PresentedQuestion(
            position=link.position,
            question_id=question.id,
            public_id=question.public_id,
            kind=question.kind,
            stem_html=question.stem_html,
            choices=choices,
            media_id=question.media_id,
            selected_choice_ids=list(answer.selected_choice_ids or [])
                                 if answer else [],
            value=answer.value if answer else "",
            is_flagged=answer.is_flagged if answer else False,
        ))

    return presented
