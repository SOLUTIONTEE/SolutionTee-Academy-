"""Audit trail.

Records privileged and security-relevant actions. Never records a
password, a one-time code, a token or an API key - if a caller passes
one in `context`, that is a bug in the caller, so the keys are filtered
here as a backstop.
"""
from __future__ import annotations

import logging

from flask import has_request_context, request

from app.extensions import db
from app.models.base import utcnow
from app.models.security import AuditLog

logger = logging.getLogger(__name__)

#: Substrings that must never reach the audit table.
_FORBIDDEN = ("password", "secret", "token", "otp", "code", "key")


def _scrub(context: dict | None) -> dict | None:
    if not context:
        return None
    return {
        key: ("[redacted]" if any(f in key.lower() for f in _FORBIDDEN)
              else value)
        for key, value in context.items()
    }


def record(action: str, *, actor=None, target: str | None = None,
           summary: str = "", context: dict | None = None) -> AuditLog:
    """Write one audit entry.

    Committed with the caller's transaction where one is open, so an
    action that is rolled back does not leave an entry claiming it
    happened.
    """
    entry = AuditLog(
        actor_user_id=getattr(actor, "id", None),
        action=action,
        target=target,
        summary=summary[:1000],
        context=_scrub(context),
        ip_address=(request.remote_addr if has_request_context() else None),
        created_at=utcnow(),
    )
    db.session.add(entry)
    db.session.commit()
    return entry
