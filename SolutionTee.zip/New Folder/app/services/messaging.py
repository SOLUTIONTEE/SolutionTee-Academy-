"""Conversations between the people in the academy.

ACCESS IS PARTICIPATION. There is no permission that grants a person
every conversation, and no staff override. A tutor can read a thread
because they are in it, not because they are staff - otherwise the first
support conversation a student has about a tutor is readable by that
tutor, which nobody would choose on purpose.

That rule lives here, in one predicate, so a new route cannot forget it.

Unread is a comparison of two timestamps: the participant's last_read_at
against the conversation's last_message_at. Counting unread messages
instead means a query over rows nobody has looked at, on every page, for
every room.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import bleach
from sqlalchemy import func, or_, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.base import utcnow
from app.models.messaging import (
    Conversation, ConversationKind, ConversationParticipant, Message,
)
from app.models.user import User

logger = logging.getLogger(__name__)

#: A message is text. Not "text with a few safe tags" - a chat message
#: with markup in it is a chat message somebody can put a link-shaped
#: thing in that is not a link. It is escaped on the way in and rendered
#: as plain text.
ALLOWED_TAGS: list[str] = []

MAX_BODY = 4000


class MessagingError(Exception):
    """Refused: not yours, closed, or empty."""


@dataclass
class Room:
    """A conversation as the inbox needs it."""

    conversation: Conversation
    unread: bool
    last_message: Message | None
    others: list[User]

    @property
    def title(self) -> str:
        if self.conversation.subject:
            return self.conversation.subject
        if self.others:
            return ", ".join(u.full_name for u in self.others)
        return "Conversation"


# ---------------------------------------------------------------------------
# Access
# ---------------------------------------------------------------------------

def participant_of(conversation: Conversation, user) -> (
        ConversationParticipant | None):
    return db.session.scalar(
        select(ConversationParticipant).where(
            ConversationParticipant.conversation_id == conversation.id,
            ConversationParticipant.user_id == user.id,
        )
    )


def can_read(conversation: Conversation, user) -> bool:
    return participant_of(conversation, user) is not None


def assert_can_read(conversation: Conversation, user) -> ConversationParticipant:
    """Return the membership, or refuse.

    Returns the participant row rather than a bool so the caller has what
    it needs for the next step - marking read - and cannot accidentally
    proceed without having checked.
    """
    membership = participant_of(conversation, user)
    if membership is None:
        raise MessagingError("That conversation is not yours.")
    return membership


# ---------------------------------------------------------------------------
# The inbox
# ---------------------------------------------------------------------------

def inbox(user, *, limit: int = 50) -> list[Room]:
    memberships = list(
        db.session.scalars(
            select(ConversationParticipant)
            .options(
                selectinload(ConversationParticipant.conversation)
                .selectinload(Conversation.participants)
                .selectinload(ConversationParticipant.user)
            )
            .where(ConversationParticipant.user_id == user.id)
            .limit(limit)
        )
    )

    rooms: list[Room] = []
    for membership in memberships:
        conversation = membership.conversation
        rooms.append(Room(
            conversation=conversation,
            unread=_is_unread(membership, conversation),
            last_message=_last_message(conversation),
            others=[p.user for p in conversation.participants
                    if p.user_id != user.id and p.user is not None],
        ))

    # Newest activity first; a room nobody has spoken in falls to the end
    # rather than to the top on a null.
    rooms.sort(
        key=lambda r: (r.conversation.last_message_at is not None,
                       r.conversation.last_message_at or r.conversation.created_at),
        reverse=True,
    )
    return rooms


def _is_unread(membership: ConversationParticipant,
               conversation: Conversation) -> bool:
    if conversation.last_message_at is None:
        return False
    if membership.last_read_at is None:
        return True
    return conversation.last_message_at > membership.last_read_at


def _last_message(conversation: Conversation) -> Message | None:
    return db.session.scalar(
        select(Message)
        .where(Message.conversation_id == conversation.id,
               Message.is_removed.is_(False))
        .order_by(Message.created_at.desc())
        .limit(1)
    )


def unread_count(user) -> int:
    """How many rooms have something new. Rooms, not messages.

    "3 unread conversations" is what a person acts on; "47 unread
    messages" is a number nobody can do anything with.
    """
    rows = db.session.execute(
        select(ConversationParticipant.last_read_at,
               Conversation.last_message_at)
        .join(Conversation,
              Conversation.id == ConversationParticipant.conversation_id)
        .where(ConversationParticipant.user_id == user.id,
               ConversationParticipant.is_muted.is_(False),
               Conversation.last_message_at.is_not(None))
    ).all()

    return sum(
        1 for last_read, last_message in rows
        if last_read is None or last_message > last_read
    )


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def messages_in(conversation: Conversation, *, after=None,
                limit: int = 200) -> list[Message]:
    statement = (
        select(Message)
        .options(selectinload(Message.sender))
        .where(Message.conversation_id == conversation.id)
        .order_by(Message.created_at)
    )
    if after is not None:
        statement = statement.where(Message.created_at > after)
    return list(db.session.scalars(statement.limit(limit)))


def mark_read(membership: ConversationParticipant) -> None:
    membership.last_read_at = utcnow()
    db.session.commit()


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------

def send(conversation: Conversation, *, sender, body: str) -> Message:
    """Post one message.

    The membership check happens here as well as in the route. A service
    that trusts its caller to have checked is a service that leaks the
    first time somebody adds a second caller.
    """
    assert_can_read(conversation, sender)

    if conversation.is_closed:
        raise MessagingError("That conversation is closed.")

    clean = bleach.clean(body or "", tags=ALLOWED_TAGS, strip=True).strip()
    if not clean:
        raise MessagingError("A message needs something in it.")
    clean = clean[:MAX_BODY]

    message = Message(conversation_id=conversation.id, sender_id=sender.id,
                      body=clean)
    db.session.add(message)

    conversation.last_message_at = utcnow()
    # The sender has, by definition, read their own message. Without this
    # the room they just posted in shows as unread to them.
    membership = participant_of(conversation, sender)
    if membership is not None:
        membership.last_read_at = conversation.last_message_at

    db.session.commit()
    return message


def system_note(conversation: Conversation, body: str) -> Message:
    """A message the application wrote. Never attributed to a person."""
    message = Message(conversation_id=conversation.id, sender_id=None,
                      body=body[:MAX_BODY], is_system=True)
    db.session.add(message)
    conversation.last_message_at = utcnow()
    db.session.commit()
    return message


# ---------------------------------------------------------------------------
# Starting one
# ---------------------------------------------------------------------------

def start(*, creator, participants, kind: str = ConversationKind.DIRECT,
          subject: str = "", course=None) -> Conversation:
    """Open a room, including the creator.

    Callers pass the other people; forgetting to include yourself is the
    obvious mistake and would create a room its own author cannot read.
    """
    conversation = Conversation(
        kind=kind, subject=subject.strip()[:200],
        created_by_id=creator.id,
        course_id=course.id if course is not None else None,
    )
    db.session.add(conversation)
    db.session.flush()

    everyone = {creator.id: creator}
    for person in participants:
        everyone[person.id] = person

    for person in everyone.values():
        db.session.add(ConversationParticipant(
            conversation_id=conversation.id, user_id=person.id,
        ))

    db.session.commit()
    return conversation


def direct_between(user_a, user_b) -> Conversation | None:
    """The existing one-to-one room for these two, if there is one.

    Checked before starting a new one: two people should have one thread,
    not a new one per click. Matched on participant set rather than on a
    pair of columns, because the same query then answers it for a room
    that later gained a third person - it simply stops matching.
    """
    counted = (
        select(ConversationParticipant.conversation_id)
        .join(Conversation,
              Conversation.id == ConversationParticipant.conversation_id)
        .where(Conversation.kind == ConversationKind.DIRECT,
               ConversationParticipant.user_id.in_([user_a.id, user_b.id]))
        .group_by(ConversationParticipant.conversation_id)
        .having(func.count(ConversationParticipant.id) == 2)
    )
    for conversation_id in db.session.scalars(counted):
        total = db.session.scalar(
            select(func.count(ConversationParticipant.id))
            .where(ConversationParticipant.conversation_id == conversation_id)
        )
        if total == 2:
            return db.session.get(Conversation, conversation_id)
    return None
