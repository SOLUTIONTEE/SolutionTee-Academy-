"""Password hashing and policy.

Argon2id, which is the current recommendation for password storage: it is
memory-hard, so a GPU gains far less against it than against bcrypt or
PBKDF2.

Parameters are tuned for a small Railway container. Raising memory_cost
is the strongest single lever if the host is later given more headroom -
but it is paid on every login, so it is bounded by the smallest instance
this runs on.
"""
from __future__ import annotations

import logging

from argon2 import PasswordHasher
from argon2.exceptions import (
    InvalidHashError, VerificationError, VerifyMismatchError,
)

logger = logging.getLogger(__name__)

_hasher = PasswordHasher(
    time_cost=2,
    memory_cost=64 * 1024,   # 64 MiB
    parallelism=2,
    hash_len=32,
    salt_len=16,
)

#: Long enough to matter, short enough that people still use a passphrase.
MIN_LENGTH = 10
MAX_LENGTH = 200

#: Rejected outright regardless of length. A deliberately short list: a
#: giant blocklist frustrates people into worse passwords, and rate
#: limiting does more real work than guessing at what is "weak".
_OBVIOUS = {
    "password", "password1", "passw0rd", "12345678", "123456789",
    "1234567890", "qwertyuiop", "letmein123", "iloveyou1", "solutiontee",
    "administrator", "adminadmin",
}


class PasswordError(ValueError):
    """The password is unacceptable. The message is shown to the user."""


def validate(password: str, *, email: str = "", full_name: str = "") -> None:
    """Check a candidate password, raising with a usable reason.

    Deliberately not a character-class rule ("one uppercase, one symbol"):
    those push people toward Passw0rd! and away from long passphrases.
    Length plus a check against their own identifiers does more.
    """
    if not password:
        raise PasswordError("Enter a password.")
    if len(password) < MIN_LENGTH:
        raise PasswordError(
            f"Use at least {MIN_LENGTH} characters. A short phrase you can "
            f"remember works well."
        )
    if len(password) > MAX_LENGTH:
        raise PasswordError(f"Keep it under {MAX_LENGTH} characters.")

    lowered = password.lower()
    if lowered in _OBVIOUS:
        raise PasswordError("That password is too easy to guess.")

    local_part = (email or "").split("@")[0].lower()
    if local_part and len(local_part) > 3 and local_part in lowered:
        raise PasswordError("Your password should not contain your email.")

    for part in (full_name or "").lower().split():
        if len(part) > 3 and part in lowered:
            raise PasswordError("Your password should not contain your name.")


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    """Check a password against its stored hash.

    Returns False rather than raising for every failure mode, including a
    malformed or empty stored hash, so a corrupt row cannot turn into a
    500 on the login page.
    """
    if not stored_hash or not password:
        return False
    try:
        return _hasher.verify(stored_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def needs_rehash(stored_hash: str) -> bool:
    """True when the hash was made with weaker parameters than current.

    Checked on a successful login, which is the only moment the plaintext
    is available to re-hash with.
    """
    if not stored_hash:
        return False
    try:
        return _hasher.check_needs_rehash(stored_hash)
    except InvalidHashError:
        return True
