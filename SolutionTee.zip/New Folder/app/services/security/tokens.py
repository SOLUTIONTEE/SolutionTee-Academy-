"""Signed, expiring links.

Used for password reset, where a six-digit code would be the wrong tool:
a link can be long and unguessable, and it arrives in the same inbox the
account is bound to.

The token carries the user's public id and a fingerprint of their current
password hash. Changing the password changes the fingerprint, which
invalidates every outstanding reset link - so a link that leaked cannot
be used after the account has already been recovered.
"""
from __future__ import annotations

import hashlib
import logging

from flask import current_app
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

logger = logging.getLogger(__name__)

RESET_SALT = "password-reset"
RESET_MAX_AGE_SECONDS = 3600


def _serializer() -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(
        current_app.config["SECRET_KEY"],
        salt=current_app.config["SECURITY_PASSWORD_SALT"],
    )


def _fingerprint(user) -> str:
    """A short digest of the current password hash.

    Not the hash itself: the token travels through email and appears in
    server logs and browser history, so it must not carry anything that
    helps an attacker offline.
    """
    return hashlib.sha256(
        (user.password_hash or "").encode()
    ).hexdigest()[:16]


def make_reset_token(user) -> str:
    return _serializer().dumps(
        {"uid": user.public_id, "fp": _fingerprint(user)},
        salt=RESET_SALT,
    )


def read_reset_token(token: str, *, max_age: int = RESET_MAX_AGE_SECONDS):
    """Return the user a reset token refers to, or None.

    Every failure returns None. Distinguishing "expired" from "forged"
    for the caller would let someone probe which tokens ever existed.
    """
    from app.services.accounts import find_by_public_id

    try:
        payload = _serializer().loads(token, salt=RESET_SALT, max_age=max_age)
    except SignatureExpired:
        logger.info("Password reset token expired")
        return None
    except BadSignature:
        logger.warning("Password reset token failed signature check")
        return None
    except Exception:  # noqa: BLE001 - malformed input must not 500
        logger.exception("Password reset token could not be read")
        return None

    if not isinstance(payload, dict):
        return None

    user = find_by_public_id(payload.get("uid", ""))
    if user is None:
        return None

    # The password has already been changed since this link was made.
    if payload.get("fp") != _fingerprint(user):
        logger.info("Password reset token no longer matches the account")
        return None

    return user
