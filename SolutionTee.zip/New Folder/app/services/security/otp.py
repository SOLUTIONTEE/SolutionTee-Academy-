"""One-time codes.

The code itself is never stored. Only a hash of it is, so reading the
database cannot reveal a live code, and it is never written to a log.

Every code is bound to a user, a purpose and a destination address. A
verification code cannot be replayed as a guardian consent code, and a
code sent to one address cannot be redeemed against another.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import secrets
from dataclasses import dataclass
from datetime import timedelta

from flask import current_app
from sqlalchemy import select

from app.extensions import db
from app.models.base import as_utc, utcnow
from app.models.security import OtpToken

logger = logging.getLogger(__name__)

CODE_LENGTH = 6


@dataclass(frozen=True)
class IssueResult:
    ok: bool
    #: The plaintext code, returned once so it can be emailed. Never
    #: stored, never logged, never rendered into a page.
    code: str = ""
    message: str = ""
    retry_after_seconds: int = 0


@dataclass(frozen=True)
class VerifyResult:
    ok: bool
    message: str = ""
    #: True when the code was wrong but attempts remain.
    can_retry: bool = False


def _hash(code: str) -> str:
    """Hash a code for storage.

    SHA-256 with the application salt rather than Argon2: a six-digit
    code has only a million possibilities, so no hash function makes it
    slow to brute force offline. What actually protects it is the short
    expiry and the attempt limit. The hash is here so a database read
    does not hand over live codes.
    """
    salt = current_app.config["SECURITY_PASSWORD_SALT"]
    return hashlib.sha256(f"{salt}:{code}".encode()).hexdigest()


def generate_code() -> str:
    """A cryptographically random numeric code.

    secrets, not random: the latter is seeded predictably and its output
    can be reconstructed from a few observed values.
    """
    upper = 10 ** CODE_LENGTH
    return str(secrets.randbelow(upper)).zfill(CODE_LENGTH)


def _active(user_id: int, purpose: str) -> OtpToken | None:
    return db.session.scalar(
        select(OtpToken)
        .where(OtpToken.user_id == user_id, OtpToken.purpose == purpose,
               OtpToken.consumed_at.is_(None))
        .order_by(OtpToken.created_at.desc())
    )


def issue(user, purpose: str, *, sent_to: str | None = None) -> IssueResult:
    """Create a code, replacing any outstanding one for this purpose.

    Replacing rather than adding matters: two live codes for one purpose
    doubles an attacker's chances and confuses the person holding an
    older email.
    """
    destination = (sent_to or user.email).strip().lower()
    now = utcnow()
    cooldown = current_app.config["OTP_RESEND_COOLDOWN_SECONDS"]

    previous = _active(user.id, purpose)
    if previous is not None:
        elapsed = (now - as_utc(previous.created_at)).total_seconds()
        if elapsed < cooldown:
            remaining = int(cooldown - elapsed) or 1
            return IssueResult(
                ok=False,
                message=(f"A code was just sent. Wait {remaining} seconds "
                         f"before asking for another."),
                retry_after_seconds=remaining,
            )
        # Supersede it, so only the newest code can ever be redeemed.
        previous.consumed_at = now

    code = generate_code()
    db.session.add(OtpToken(
        user_id=user.id,
        purpose=purpose,
        sent_to=destination,
        code_hash=_hash(code),
        expires_at=now + timedelta(
            minutes=current_app.config["OTP_TTL_MINUTES"]
        ),
        attempts=0,
        created_at=now,
    ))
    db.session.commit()

    # Deliberately logs that a code was issued, never the code itself.
    logger.info("Issued %s code for user %s", purpose, user.public_id)
    return IssueResult(ok=True, code=code)


def verify(user, purpose: str, submitted: str) -> VerifyResult:
    """Check a submitted code and consume it on success."""
    submitted = (submitted or "").strip().replace(" ", "")
    token = _active(user.id, purpose)
    now = utcnow()

    generic = "That code is not right. Check it and try again."

    if token is None:
        return VerifyResult(False, "Ask for a new code.")

    if as_utc(token.expires_at) <= now:
        token.consumed_at = now
        db.session.commit()
        return VerifyResult(False, "That code has expired. Ask for a new one.")

    max_attempts = current_app.config["OTP_MAX_ATTEMPTS"]
    if token.attempts >= max_attempts:
        return VerifyResult(
            False,
            "Too many incorrect attempts. Ask for a new code.",
        )

    # Constant time: a plain == leaks how much of the code was right
    # through how long the comparison took.
    if not hmac.compare_digest(token.code_hash, _hash(submitted)):
        token.attempts += 1
        db.session.commit()
        remaining = max_attempts - token.attempts
        if remaining <= 0:
            return VerifyResult(
                False, "Too many incorrect attempts. Ask for a new code."
            )
        return VerifyResult(False, generic, can_retry=True)

    token.consumed_at = now
    db.session.commit()
    return VerifyResult(True)


def invalidate(user, purpose: str) -> int:
    """Consume every outstanding code for a purpose.

    Called after the thing the code protected has happened by another
    route, so an emailed code cannot be used afterwards.
    """
    tokens = db.session.scalars(
        select(OtpToken).where(
            OtpToken.user_id == user.id,
            OtpToken.purpose == purpose,
            OtpToken.consumed_at.is_(None),
        )
    ).all()
    now = utcnow()
    for token in tokens:
        token.consumed_at = now
    db.session.commit()
    return len(tokens)
