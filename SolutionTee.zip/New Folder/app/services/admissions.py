"""Admission listings.

Two derivations do most of the work here, and both exist because a
stored answer would go quietly wrong:

**Status** ("Open", "Closing soon", "Closed") is computed from the dates
on every read. Stored, it would be correct on the day somebody typed it
and wrong every day after.

**Freshness** is computed from `last_verified_at`. A listing nobody has
checked for months is not necessarily wrong, but the candidate deserves
to know that before they act on it. The page says how old the
information is rather than presenting everything with equal confidence.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, timedelta

from sqlalchemy import or_, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.admissions import (
    AdmissionEnquiry, Application, ApplicationType, Institution,
    InstitutionKind,
)
from app.models.base import as_utc, utcnow

logger = logging.getLogger(__name__)

#: A window inside this many days of closing is "closing soon". Chosen
#: because it is long enough to still act on and short enough to mean
#: something.
CLOSING_SOON_DAYS = 14

#: How long before a verified fact is treated as ageing, then stale.
#: Admission dates move without notice, so these are deliberately short.
AGEING_AFTER_DAYS = 14
STALE_AFTER_DAYS = 45


class Status:
    OPENING_SOON = "opening_soon"
    OPEN = "open"
    CLOSING_SOON = "closing_soon"
    CLOSED = "closed"
    UNDATED = "undated"

    LABELS = {
        OPENING_SOON: "Opening soon",
        OPEN: "Open",
        CLOSING_SOON: "Closing soon",
        CLOSED: "Closed",
        UNDATED: "Dates not announced",
    }


def status_of(application: Application, *, today: date | None = None) -> str:
    """Derive a window's status from its dates.

    Undated is a first-class answer, not a fallback. "The institution has
    not announced dates" is true, useful, and completely different from
    "this is open".
    """
    today = today or utcnow().date()
    opens, closes = application.opens_on, application.closes_on

    if opens is None and closes is None:
        return Status.UNDATED

    if closes is not None and closes < today:
        return Status.CLOSED

    if opens is not None and opens > today:
        return Status.OPENING_SOON

    if closes is not None and (closes - today).days <= CLOSING_SOON_DAYS:
        return Status.CLOSING_SOON

    # Open, or closes far enough away not to be urgent.
    return Status.OPEN


def days_until_close(application: Application, *,
                     today: date | None = None) -> int | None:
    if application.closes_on is None:
        return None
    return (application.closes_on - (today or utcnow().date())).days


@dataclass(frozen=True)
class Freshness:
    """How much confidence a listing has earned."""

    days_ago: int
    level: str          # "fresh", "ageing", "stale"
    message: str

    @property
    def is_stale(self) -> bool:
        return self.level == "stale"


def freshness_of(application: Application) -> Freshness:
    days = (utcnow() - as_utc(application.last_verified_at)).days

    if days <= AGEING_AFTER_DAYS:
        if days == 0:
            when = "today"
        elif days == 1:
            when = "yesterday"
        else:
            when = f"{days} days ago"
        return Freshness(
            days, "fresh",
            f"Checked against the official source {when}.",
        )
    if days <= STALE_AFTER_DAYS:
        return Freshness(
            days, "ageing",
            f"Last checked {days} days ago. Confirm on the official portal "
            f"before you pay anything.",
        )
    return Freshness(
        days, "stale",
        f"Last checked {days} days ago, so it may be out of date. Treat the "
        f"official portal as the authority, not this page.",
    )


@dataclass
class Listing:
    """An application with everything the page needs already derived.

    Assembled here rather than in the template so status and freshness
    cannot be computed two different ways on two different pages.
    """

    application: Application
    status: str
    freshness: Freshness
    days_left: int | None

    @property
    def status_label(self) -> str:
        return Status.LABELS[self.status]

    @property
    def is_actionable(self) -> bool:
        return self.status in (Status.OPEN, Status.CLOSING_SOON)


def to_listing(application: Application, *,
               today: date | None = None) -> Listing:
    return Listing(
        application=application,
        status=status_of(application, today=today),
        freshness=freshness_of(application),
        days_left=days_until_close(application, today=today),
    )


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def group_kinds(group: str) -> tuple[str, ...]:
    return InstitutionKind.GROUPS.get(group, ())


def browse(*, group: str = "", application_type: str = "", query: str = "",
           state: str = "", include_closed: bool = False) -> list[Listing]:
    """Published applications, newest-closing first.

    Ordering puts what is closing soonest at the top, because that is
    what a candidate needs to see first. Closed windows sort last and are
    hidden unless asked for - they are kept because "did I miss it?" is a
    real question, but they must not crowd out what is still open.
    """
    statement = (
        select(Application)
        .join(Institution)
        .options(selectinload(Application.institution))
        .where(Application.is_published.is_(True),
               Institution.is_published.is_(True))
    )

    kinds = group_kinds(group)
    if kinds:
        statement = statement.where(Institution.kind.in_(kinds))
    if application_type:
        statement = statement.where(
            Application.application_type == application_type
        )
    if state:
        statement = statement.where(Institution.state == state)

    term = (query or "").strip()
    if term:
        pattern = f"%{term}%"
        statement = statement.where(or_(
            Institution.name.ilike(pattern),
            Institution.short_name.ilike(pattern),
            Application.programme_name.ilike(pattern),
        ))

    listings = [to_listing(row) for row in db.session.scalars(statement)]

    if not include_closed:
        listings = [item for item in listings if item.status != Status.CLOSED]

    def sort_key(item: Listing):
        # Closing soonest first; undated and closed sink to the bottom.
        rank = {Status.CLOSING_SOON: 0, Status.OPEN: 1,
                Status.OPENING_SOON: 2, Status.UNDATED: 3,
                Status.CLOSED: 4}[item.status]
        return (rank,
                item.days_left if item.days_left is not None else 9999,
                item.application.institution.name)

    listings.sort(key=sort_key)
    return listings


def get_application(public_id: str) -> Application | None:
    return db.session.scalar(
        select(Application)
        .options(selectinload(Application.institution))
        .where(Application.public_id == public_id)
    )


def counts_by_group() -> dict[str, int]:
    """How many open windows sit under each heading.

    One pass over the published rows rather than a query per group: there
    are only four groups but the pattern matters, and status has to be
    derived in Python anyway.
    """
    rows = db.session.scalars(
        select(Application)
        .join(Institution)
        .options(selectinload(Application.institution))
        .where(Application.is_published.is_(True),
               Institution.is_published.is_(True))
    ).all()

    counts = {group: 0 for group in InstitutionKind.GROUPS}
    for row in rows:
        if status_of(row) == Status.CLOSED:
            continue
        for group, kinds in InstitutionKind.GROUPS.items():
            if row.institution.kind in kinds:
                counts[group] += 1
    return counts


def states_with_listings() -> list[str]:
    rows = db.session.scalars(
        select(Institution.state)
        .where(Institution.is_published.is_(True),
               Institution.state != "")
        .distinct()
        .order_by(Institution.state)
    ).all()
    return list(rows)


# ---------------------------------------------------------------------------
# Enquiries
# ---------------------------------------------------------------------------

def record_enquiry(*, application: Application | None, full_name: str,
                   email: str, phone: str = "", message: str = "",
                   user=None) -> AdmissionEnquiry:
    """Log a request for help with an application.

    An enquiry, not a submission. SolutionTee cannot file on a
    candidate's behalf without their own portal credentials, and nothing
    in the product should suggest otherwise.
    """
    enquiry = AdmissionEnquiry(
        application_id=application.id if application else None,
        user_id=getattr(user, "id", None) if user else None,
        full_name=full_name.strip()[:120],
        email=email.strip().lower()[:255],
        phone=phone.strip()[:32],
        message=message.strip(),
    )
    db.session.add(enquiry)
    db.session.commit()
    logger.info("Admission enquiry %s recorded", enquiry.public_id)
    return enquiry
