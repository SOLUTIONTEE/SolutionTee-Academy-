"""Discussion spaces.

MEMBERSHIP IS DERIVED. A course space is readable by the people on that
course - its students, its instructor, and administrators - and that is
computed from the enrolment, not stored in a membership table. A student
who enrols gains the space and one whose enrolment lapses loses it, with
nothing having to remember to add or remove a row.

The cost is a query per access check; the benefit is that there is no
second source of truth to drift out of step with who is actually on the
course. For a page that checks once and then renders, that is the right
trade.

Moderation is withdrawal, not deletion. A removed post keeps its row and
its replies keep their context; what changes is that the body is no
longer shown.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import bleach
from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.base import slugify, utcnow
from app.models.community import (
    CommunityComment, CommunityPost, CommunitySpace,
)
from app.models.courses import Course
from app.models.payments import Enrolment, EnrolmentStatus
from app.services import rbac

logger = logging.getLogger(__name__)

#: Posts are plain text, for the same reason messages are: a post that
#: renders markup is a post somebody can put a link-shaped thing in that
#: is not a link.
ALLOWED_TAGS: list[str] = []

MAX_BODY = 8000
MAX_TITLE = 200

#: Holding this means you can moderate any space and read all of them.
MODERATOR_PERMISSION = "teaching.publish"


class CommunityError(Exception):
    """Refused: not yours to read, archived, or empty."""


@dataclass
class FeedItem:
    post: CommunityPost
    comment_count: int


# ---------------------------------------------------------------------------
# Access
# ---------------------------------------------------------------------------

def is_moderator(user) -> bool:
    return rbac.has_permission(user, MODERATOR_PERMISSION)


def can_read(space: CommunitySpace, user) -> bool:
    """Who the space is for.

    A general space is open to anyone signed in. A course space belongs
    to the people on that course.
    """
    if user is None or not getattr(user, "is_authenticated", True):
        return False
    if space.is_general:
        return True
    if is_moderator(user):
        return True
    if space.course_id is None:
        # Neither general nor attached to anything: nobody's space. Left
        # readable only to moderators so it cannot become invisible work.
        return False

    course = db.session.get(Course, space.course_id)
    if course is None:
        return False
    if course.instructor_id == user.id:
        return True
    if course.offering_id is None:
        return False

    return db.session.scalar(
        select(func.count(Enrolment.id)).where(
            Enrolment.user_id == user.id,
            Enrolment.offering_id == course.offering_id,
            Enrolment.status.in_([EnrolmentStatus.ACTIVE,
                                  EnrolmentStatus.COMPLETED]),
        )
    ) > 0


def assert_can_read(space: CommunitySpace, user) -> None:
    if not can_read(space, user):
        raise CommunityError("That space is not open to you.")


def can_post(space: CommunitySpace, user) -> bool:
    return can_read(space, user) and not space.is_archived


def can_moderate(space: CommunitySpace, user) -> bool:
    """Remove somebody else's post, or pin one.

    The course's own instructor, plus anybody holding the moderator
    permission. Being able to read a space is not being able to police
    it.
    """
    if is_moderator(user):
        return True
    if space.course_id is None:
        return False
    course = db.session.get(Course, space.course_id)
    return course is not None and course.instructor_id == user.id


def spaces_for(user) -> list[CommunitySpace]:
    """Every space this person can actually open.

    Filtered in Python over a small set rather than expressed as one
    query: the readable-set rule differs per space (general, by
    instructor, by enrolment) and encoding all three as a single SQL
    predicate makes it impossible to change one of them safely.
    """
    candidates = db.session.scalars(
        select(CommunitySpace)
        .where(CommunitySpace.is_archived.is_(False))
        .order_by(CommunitySpace.is_general.desc(), CommunitySpace.name)
    )
    return [space for space in candidates if can_read(space, user)]


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def feed(space: CommunitySpace, *, limit: int = 50) -> list[FeedItem]:
    """Pinned first, then newest.

    Comment counts come from ONE grouped query rather than a count per
    post: a feed of fifty posts would otherwise be fifty-one queries, and
    that only shows once there is real traffic.
    """
    posts = list(
        db.session.scalars(
            select(CommunityPost)
            .options(selectinload(CommunityPost.author))
            .where(CommunityPost.space_id == space.id,
                   CommunityPost.is_removed.is_(False))
            .order_by(CommunityPost.is_pinned.desc(),
                      CommunityPost.created_at.desc())
            .limit(limit)
        )
    )
    if not posts:
        return []

    counts = dict(
        db.session.execute(
            select(CommunityComment.post_id, func.count(CommunityComment.id))
            .where(CommunityComment.post_id.in_([p.id for p in posts]),
                   CommunityComment.is_removed.is_(False))
            .group_by(CommunityComment.post_id)
        ).all()
    )
    return [FeedItem(post=p, comment_count=counts.get(p.id, 0))
            for p in posts]


def comments_on(post: CommunityPost) -> list[CommunityComment]:
    return list(
        db.session.scalars(
            select(CommunityComment)
            .options(selectinload(CommunityComment.author))
            .where(CommunityComment.post_id == post.id,
                   CommunityComment.is_removed.is_(False))
            .order_by(CommunityComment.created_at)
        )
    )


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------

def _clean(value: str, limit: int) -> str:
    return bleach.clean(value or "", tags=ALLOWED_TAGS,
                        strip=True).strip()[:limit]


def post(space: CommunitySpace, *, author, title: str,
         body: str) -> CommunityPost:
    if not can_post(space, author):
        raise CommunityError(
            "That space is archived." if space.is_archived
            else "That space is not open to you."
        )

    clean_body = _clean(body, MAX_BODY)
    if not clean_body:
        raise CommunityError("A post needs something in it.")

    item = CommunityPost(space_id=space.id, author_id=author.id,
                         title=_clean(title, MAX_TITLE), body=clean_body)
    db.session.add(item)
    db.session.commit()
    return item


def comment(item: CommunityPost, *, author, body: str) -> CommunityComment:
    space = db.session.get(CommunitySpace, item.space_id)
    if not can_post(space, author):
        raise CommunityError("That space is not open to you.")
    if item.is_removed:
        raise CommunityError("That post has been withdrawn.")

    clean_body = _clean(body, MAX_BODY)
    if not clean_body:
        raise CommunityError("A reply needs something in it.")

    reply = CommunityComment(post_id=item.id, author_id=author.id,
                             body=clean_body)
    db.session.add(reply)
    db.session.commit()
    return reply


# ---------------------------------------------------------------------------
# Moderation
# ---------------------------------------------------------------------------

def remove_post(item: CommunityPost, *, actor) -> None:
    """Withdraw a post.

    An author may withdraw their own; a moderator may withdraw anybody's.
    Nothing is deleted - the replies underneath keep their context, and
    who removed it is recorded.
    """
    space = db.session.get(CommunitySpace, item.space_id)
    if not (item.author_id == actor.id or can_moderate(space, actor)):
        raise CommunityError("That post is not yours to remove.")

    item.is_removed = True
    item.removed_by_id = actor.id
    item.removed_at = utcnow()
    db.session.commit()


def remove_comment(reply: CommunityComment, *, actor) -> None:
    item = db.session.get(CommunityPost, reply.post_id)
    space = db.session.get(CommunitySpace, item.space_id)
    if not (reply.author_id == actor.id or can_moderate(space, actor)):
        raise CommunityError("That reply is not yours to remove.")

    reply.is_removed = True
    reply.removed_by_id = actor.id
    reply.removed_at = utcnow()
    db.session.commit()


def set_pinned(item: CommunityPost, *, actor, pinned: bool) -> None:
    space = db.session.get(CommunitySpace, item.space_id)
    if not can_moderate(space, actor):
        raise CommunityError("Pinning is for the tutor of this space.")
    item.is_pinned = pinned
    db.session.commit()


# ---------------------------------------------------------------------------
# Creating a space
# ---------------------------------------------------------------------------

def unique_slug(name: str) -> str:
    base = slugify(name) or "space"
    candidate = base
    suffix = 2
    while db.session.scalar(
            select(CommunitySpace).where(CommunitySpace.slug == candidate)):
        candidate = f"{base}-{suffix}"
        suffix += 1
    return candidate


def create_space(*, name: str, description: str = "", course=None,
                 is_general: bool = False) -> CommunitySpace:
    clean_name = _clean(name, 140) or "Space"
    space = CommunitySpace(
        name=clean_name, slug=unique_slug(clean_name),
        description=_clean(description, 2000),
        course_id=course.id if course is not None else None,
        is_general=is_general,
    )
    db.session.add(space)
    db.session.commit()
    return space
