"""Cloudflare Turnstile verification.

Server-side only. A token that is merely present in the form proves
nothing: it has to be exchanged with Cloudflare, which is what this does.
"""
from __future__ import annotations

import logging

import requests
from flask import current_app

logger = logging.getLogger(__name__)

VERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify"


def enabled() -> bool:
    return bool(
        current_app.config.get("TURNSTILE_ENABLED")
        and current_app.config.get("TURNSTILE_SECRET_KEY")
    )


def verify(token: str | None, *, remote_ip: str | None = None) -> bool:
    """Exchange a widget token with Cloudflare.

    Returns True when Turnstile is not configured, so development and the
    test suite are not blocked by a service that is not set up. Whether
    it is configured in production is a deployment check, not something
    this function can decide.
    """
    if not enabled():
        return True

    if not token:
        return False

    payload = {
        "secret": current_app.config["TURNSTILE_SECRET_KEY"],
        "response": token,
    }
    if remote_ip:
        payload["remoteip"] = remote_ip

    try:
        response = requests.post(
            VERIFY_URL, data=payload,
            timeout=current_app.config.get("TURNSTILE_TIMEOUT", 6),
        )
        response.raise_for_status()
        outcome = response.json()
    except requests.RequestException:
        # Cloudflare being unreachable must not become an open door.
        logger.exception("Turnstile verification request failed")
        return False
    except ValueError:
        logger.exception("Turnstile returned a non-JSON response")
        return False

    if not outcome.get("success"):
        # Error codes are diagnostic, never secrets.
        logger.info("Turnstile rejected a token: %s",
                    outcome.get("error-codes"))
        return False
    return True
