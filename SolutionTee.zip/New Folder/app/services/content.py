"""Rich text sanitisation.

Lesson bodies and article content are written by staff, but "written by
staff" is not a security boundary: a compromised or careless staff
account must not be able to plant script that runs for every student.

Sanitising happens on the way IN, once, so the stored value is already
safe. Sanitising on the way out instead would mean every template that
forgets `| safe` is fine and every one that remembers is a hole.
"""
from __future__ import annotations

import logging

import bleach

logger = logging.getLogger(__name__)

#: What a lesson or article may contain. Deliberately narrow: everything
#: here is something an editor genuinely needs for prose.
ALLOWED_TAGS = {
    "p", "br", "hr",
    "h2", "h3", "h4",
    "strong", "em", "u", "s", "sub", "sup",
    "ul", "ol", "li",
    "blockquote", "q", "cite",
    "a", "img", "figure", "figcaption",
    "table", "thead", "tbody", "tr", "th", "td", "caption",
    "code", "pre", "kbd",
    "span", "div",
}

ALLOWED_ATTRIBUTES = {
    "*": ["class", "id", "lang", "dir"],
    "a": ["href", "title", "rel", "target"],
    "img": ["src", "alt", "width", "height", "loading", "decoding"],
    "th": ["scope", "colspan", "rowspan"],
    "td": ["colspan", "rowspan"],
    "ol": ["start", "type"],
}

#: http and https only. Notably absent: javascript:, which is the
#: classic way an anchor becomes script execution, and data:, which can
#: carry a whole HTML document.
ALLOWED_PROTOCOLS = {"http", "https", "mailto"}

# No `style` attribute is allowed anywhere, so there is no inline CSS to
# sanitise and bleach's CSSSanitizer would do nothing but pull in a
# dependency. Presentation comes from the design system, not from what
# an editor pasted out of Word.


def sanitise_html(raw: str) -> str:
    """Clean untrusted HTML for storage.

    Anything not on the allowlist is stripped rather than escaped, so an
    editor pasting from Word gets clean prose instead of a page full of
    visible tags.
    """
    if not raw:
        return ""

    cleaned = bleach.clean(
        raw,
        tags=ALLOWED_TAGS,
        attributes=ALLOWED_ATTRIBUTES,
        protocols=ALLOWED_PROTOCOLS,
        strip=True,
        strip_comments=True,
    )

    # Any link that opens a new tab must not hand the opened page a
    # usable window.opener, which it could use to navigate this one.
    cleaned = _harden_targets(cleaned)
    return cleaned


def _harden_targets(html: str) -> str:
    import re

    def fix(match: re.Match) -> str:
        tag = match.group(0)
        if 'target="_blank"' not in tag and "target='_blank'" not in tag:
            return tag
        if "rel=" in tag:
            return tag
        return tag[:-1] + ' rel="noopener noreferrer">'

    return re.sub(r"<a\b[^>]*>", fix, html)
