"""What a student owes, and what they have paid.

Every figure is derived from rows rather than stored as a running total.
A cached balance that drifts out of step with the payments behind it is
the classic way money goes missing, and it is very hard to notice.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from sqlalchemy import func, select

from app.extensions import db
from app.models.payments import (
    AdjustmentKind, Enrolment, Payment, PaymentAdjustment, PaymentStatus,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Balance:
    """A snapshot, in kobo."""

    agreed_kobo: int
    adjustments_kobo: int
    paid_kobo: int

    @property
    def owed_kobo(self) -> int:
        """Total payable after adjustments. Never below zero.

        A discount larger than the price would otherwise produce a
        negative balance, which reads as the centre owing the student.
        """
        return max(0, self.agreed_kobo + self.adjustments_kobo)

    @property
    def outstanding_kobo(self) -> int:
        return max(0, self.owed_kobo - self.paid_kobo)

    @property
    def is_settled(self) -> bool:
        return self.outstanding_kobo == 0

    @property
    def paid_fraction(self) -> float:
        if self.owed_kobo <= 0:
            return 1.0
        return min(1.0, self.paid_kobo / self.owed_kobo)

    def naira(self, kobo: int) -> str:
        return f"{kobo / 100:,.2f}"


def balance_for(enrolment: Enrolment) -> Balance:
    """Compute the balance from the rows, in two aggregate queries."""
    paid = db.session.scalar(
        select(func.coalesce(func.sum(Payment.paid_amount_kobo), 0))
        .where(Payment.enrolment_id == enrolment.id,
               Payment.status == PaymentStatus.SUCCESS,
               Payment.verified_at.is_not(None))
    ) or 0

    adjustments = db.session.scalar(
        select(func.coalesce(func.sum(PaymentAdjustment.amount_kobo), 0))
        .where(PaymentAdjustment.enrolment_id == enrolment.id)
    ) or 0

    return Balance(
        agreed_kobo=enrolment.agreed_price_kobo,
        adjustments_kobo=int(adjustments),
        paid_kobo=int(paid),
    )


def record_adjustment(enrolment: Enrolment, *, kind: str, amount_kobo: int,
                      reason: str, actor=None) -> PaymentAdjustment:
    """Change what is owed, with a reason and an author.

    A discount is a negative amount. The reason is required: an
    unexplained change to somebody's fees is not auditable, and this is
    the row an accountant will be reading a year from now.
    """
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("an adjustment must record why it was made")
    if amount_kobo == 0:
        raise ValueError("an adjustment of zero changes nothing")

    if kind in (AdjustmentKind.DISCOUNT, AdjustmentKind.WAIVER):
        # Normalise the sign so a caller cannot record a "discount" that
        # silently increases the bill.
        amount_kobo = -abs(amount_kobo)
    elif kind == AdjustmentKind.SURCHARGE:
        amount_kobo = abs(amount_kobo)

    adjustment = PaymentAdjustment(
        enrolment_id=enrolment.id,
        kind=kind,
        amount_kobo=int(amount_kobo),
        reason=reason,
        actor_user_id=getattr(actor, "id", None),
    )
    db.session.add(adjustment)
    db.session.commit()

    logger.info("Adjustment %s of %s kobo on enrolment %s by %s",
                kind, amount_kobo, enrolment.public_id,
                getattr(actor, "public_id", "system"))
    return adjustment


# ---------------------------------------------------------------------------
# Instalments
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Instalment:
    index: int
    percent: int
    amount_kobo: int
    due_day_offset: int


def validate_instalments(instalments: list[dict]) -> list[dict]:
    """Check a plan's schedule before it is saved.

    Percentages that do not total 100 would leave a balance nobody is
    ever billed for, or bill more than the price.
    """
    if not instalments:
        raise ValueError("a payment plan needs at least one instalment")

    total = 0
    for entry in instalments:
        percent = entry.get("percent")
        if not isinstance(percent, int) or percent <= 0:
            raise ValueError("each instalment needs a positive whole percent")
        total += percent

    if total != 100:
        raise ValueError(
            f"instalments must total 100 percent, these total {total}"
        )
    return instalments


def split_instalments(owed_kobo: int, instalments: list[dict]
                      ) -> list[Instalment]:
    """Divide an amount across a schedule without losing a kobo.

    Percentages rarely divide a price exactly. Rounding each share
    independently can leave the total a kobo or two short of what is
    owed, so the final instalment takes the remainder.
    """
    if owed_kobo <= 0 or not instalments:
        return []

    result: list[Instalment] = []
    running = 0
    last = len(instalments) - 1

    for index, entry in enumerate(instalments):
        percent = int(entry.get("percent", 0))
        if index == last:
            amount = owed_kobo - running
        else:
            amount = (owed_kobo * percent) // 100
            running += amount
        result.append(Instalment(
            index=index,
            percent=percent,
            amount_kobo=amount,
            due_day_offset=int(entry.get("due_day_offset", 0)),
        ))

    return result


def next_instalment_due(enrolment: Enrolment) -> Instalment | None:
    """The next amount this student should pay, or None if settled."""
    balance = balance_for(enrolment)
    if balance.is_settled:
        return None

    plan = enrolment.plan
    if plan is None or not plan.instalments:
        # No plan means the whole outstanding amount is due.
        return Instalment(index=0, percent=100,
                          amount_kobo=balance.outstanding_kobo,
                          due_day_offset=0)

    schedule = split_instalments(balance.owed_kobo, plan.instalments)
    covered = balance.paid_kobo
    for instalment in schedule:
        if covered >= instalment.amount_kobo:
            covered -= instalment.amount_kobo
            continue
        # Part-paid: only the remainder of this instalment is due.
        return Instalment(
            index=instalment.index,
            percent=instalment.percent,
            amount_kobo=instalment.amount_kobo - covered,
            due_day_offset=instalment.due_day_offset,
        )
    return None
