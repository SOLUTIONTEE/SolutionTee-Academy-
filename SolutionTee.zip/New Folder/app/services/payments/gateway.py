"""Paystack.

Two things matter here more than anything else.

First, an amount is never taken from the browser. What is charged is
computed on the server from the offering and the plan, and what the
gateway reports back is compared against it before anything is granted.

Second, a webhook is only believed if its signature checks out. Anyone
can POST to a webhook URL; the HMAC is the only thing separating a real
payment notification from a forged one.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
from dataclasses import dataclass, field

import requests
from flask import current_app

logger = logging.getLogger(__name__)

API_BASE = "https://api.paystack.co"


class GatewayError(RuntimeError):
    """The gateway could not be reached or answered unusably."""


@dataclass(frozen=True)
class Authorization:
    """Where to send the payer, and the gateway's handle for it."""

    authorization_url: str
    access_code: str
    reference: str


@dataclass(frozen=True)
class Verification:
    """What the gateway says actually happened."""

    ok: bool
    status: str = ""
    amount_kobo: int = 0
    currency: str = ""
    gateway_reference: str = ""
    paid_at: str = ""
    payload: dict = field(default_factory=dict)
    error: str = ""


class PaystackGateway:
    def __init__(self, *, secret_key: str, public_key: str = "",
                 currency: str = "NGN", timeout: int = 15) -> None:
        self._secret_key = secret_key
        self.public_key = public_key
        self.currency = currency
        self.timeout = timeout

    @property
    def configured(self) -> bool:
        return bool(self._secret_key)

    def _headers(self) -> dict:
        # The secret goes in a header and nowhere else: never a query
        # string, never a log line, never an error message.
        return {
            "Authorization": f"Bearer {self._secret_key}",
            "Content-Type": "application/json",
        }

    # -- Starting a payment -------------------------------------------------

    def initialise(self, *, email: str, amount_kobo: int, reference: str,
                   callback_url: str, metadata: dict | None = None
                   ) -> Authorization:
        if not self.configured:
            raise GatewayError("Paystack is not configured")
        if amount_kobo <= 0:
            raise GatewayError("refusing to charge a non-positive amount")

        payload = {
            "email": email,
            # Kobo, as an integer. Paystack rejects a float here, and a
            # float is the wrong type for money anyway.
            "amount": int(amount_kobo),
            "currency": self.currency,
            "reference": reference,
            "callback_url": callback_url,
        }
        if metadata:
            payload["metadata"] = metadata

        try:
            response = requests.post(
                f"{API_BASE}/transaction/initialize",
                json=payload, headers=self._headers(), timeout=self.timeout,
            )
        except requests.RequestException as exc:
            logger.exception("Paystack initialise failed for %s", reference)
            raise GatewayError("could not reach the payment gateway") from exc

        body = self._json(response, reference)
        if not body.get("status"):
            message = body.get("message", "gateway declined the request")
            logger.error("Paystack refused to initialise %s: %s",
                         reference, message)
            raise GatewayError(message)

        data = body.get("data") or {}
        url = data.get("authorization_url")
        if not url:
            raise GatewayError("gateway returned no authorization URL")

        return Authorization(
            authorization_url=url,
            access_code=data.get("access_code", ""),
            reference=data.get("reference", reference),
        )

    # -- Confirming one --------------------------------------------------

    def verify(self, reference: str) -> Verification:
        """Ask the gateway directly what happened.

        This is the only statement about a payment that is trusted. A
        browser returning to the callback URL proves nothing: anyone can
        open that URL with any reference.
        """
        if not self.configured:
            raise GatewayError("Paystack is not configured")

        try:
            response = requests.get(
                f"{API_BASE}/transaction/verify/{reference}",
                headers=self._headers(), timeout=self.timeout,
            )
        except requests.RequestException as exc:
            logger.exception("Paystack verify failed for %s", reference)
            raise GatewayError("could not reach the payment gateway") from exc

        body = self._json(response, reference)
        if not body.get("status"):
            return Verification(ok=False,
                                error=body.get("message", "verification failed"))

        data = body.get("data") or {}
        return Verification(
            ok=(data.get("status") == "success"),
            status=data.get("status", ""),
            amount_kobo=int(data.get("amount") or 0),
            currency=data.get("currency", ""),
            gateway_reference=str(data.get("id") or ""),
            paid_at=data.get("paid_at") or "",
            payload=data,
            error="" if data.get("status") == "success"
                  else data.get("gateway_response", ""),
        )

    # -- Webhooks -----------------------------------------------------------

    def signature_is_valid(self, raw_body: bytes, signature: str) -> bool:
        """Verify the x-paystack-signature header.

        HMAC-SHA512 of the exact raw request body, keyed with the secret.
        The RAW body matters: re-serialising the parsed JSON changes
        whitespace and key order, and the digest would never match.

        compare_digest, not ==, so the comparison does not leak how much
        of the signature was correct through its timing.
        """
        if not self._secret_key or not signature:
            return False
        expected = hmac.new(
            self._secret_key.encode(), raw_body, hashlib.sha512
        ).hexdigest()
        return hmac.compare_digest(expected, signature)

    # -- Internals ----------------------------------------------------------

    def _json(self, response, reference: str) -> dict:
        try:
            return response.json()
        except ValueError as exc:
            logger.error("Paystack returned non-JSON for %s: HTTP %s %s",
                         reference, response.status_code,
                         response.text[:200])
            raise GatewayError("gateway returned an unreadable response") from exc


def get_gateway() -> PaystackGateway:
    key = "_solutiontee_paystack"
    gateway = current_app.extensions.get(key)
    if gateway is None:
        gateway = PaystackGateway(
            secret_key=current_app.config.get("PAYSTACK_SECRET_KEY", ""),
            public_key=current_app.config.get("PAYSTACK_PUBLIC_KEY", ""),
            currency=current_app.config.get("PAYSTACK_CURRENCY", "NGN"),
        )
        current_app.extensions[key] = gateway
    return gateway
