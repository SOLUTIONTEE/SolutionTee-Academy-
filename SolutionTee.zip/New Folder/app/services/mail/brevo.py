"""Brevo transactional email."""
from __future__ import annotations

import logging

import requests

from app.services.mail.base import Message, SendResult

logger = logging.getLogger(__name__)

API_URL = "https://api.brevo.com/v3/smtp/email"


class BrevoTransport:
    def __init__(self, *, api_key: str, senders: dict[str, str],
                 from_name: str, timeout: int = 10) -> None:
        if not api_key:
            raise ValueError(
                "Brevo transport selected but BREVO_API_KEY is unset"
            )
        self._api_key = api_key
        self.senders = senders
        self.from_name = from_name
        self.timeout = timeout

    def send(self, message: Message) -> SendResult:
        sender_email = self.senders.get(message.sender)
        if not sender_email:
            # A misconfigured sender identity is a deployment error, not a
            # per-message one, so it is loud in the log.
            logger.error("No sender address configured for %r", message.sender)
            return SendResult(ok=False, error="sender not configured")

        payload = {
            "sender": {"email": sender_email, "name": self.from_name},
            "to": [{"email": message.to}],
            "subject": message.subject,
            "htmlContent": message.html,
        }
        if message.text:
            payload["textContent"] = message.text
        if message.reply_to:
            payload["replyTo"] = {"email": message.reply_to}
        if message.tags:
            payload["tags"] = list(message.tags)

        try:
            response = requests.post(
                API_URL,
                json=payload,
                headers={
                    # The key goes in a header and nowhere else. It is
                    # never logged, and never echoed into an error.
                    "api-key": self._api_key,
                    "accept": "application/json",
                    "content-type": "application/json",
                },
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            logger.exception("Brevo request failed for a %s message",
                             message.sender)
            return SendResult(ok=False, error=type(exc).__name__)

        if response.status_code >= 400:
            # The body may echo the payload, so log the status and a
            # short excerpt rather than the whole response.
            logger.error("Brevo rejected a message: HTTP %s %s",
                         response.status_code, response.text[:200])
            return SendResult(ok=False, error=f"HTTP {response.status_code}")

        try:
            message_id = response.json().get("messageId", "")
        except ValueError:
            message_id = ""
        return SendResult(ok=True, message_id=message_id)
