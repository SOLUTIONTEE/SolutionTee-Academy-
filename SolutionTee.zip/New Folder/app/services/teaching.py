"""What a tutor sees when they sign in, and what they are allowed to touch.

A tutor's workspace answers the questions a teacher actually has, in the
order they have them: who is falling behind, who has just sat a paper, and
what have I not finished writing. Everything on it is a real count of real
rows — there are no decorative statistics here for the same reason there
are none on the student dashboard.

AUTHORISATION IS BY OWNERSHIP, NOT BY PERMISSION ALONE. `teaching.view`
decides who gets a workspace at all; it does not decide whose students
they can see. A tutor sees the students enrolled on the courses they
teach, and nobody else's. That scoping lives here rather than in the
routes, so a new route cannot forget it.

Assembled in a handful of queries rather than by walking relationships in
a template, which is how a page quietly becomes thirty queries.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.cbt import Attempt, AttemptStatus
from app.models.base import slugify
from app.models.courses import Course, Lesson, Module
from app.models.payments import Enrolment, EnrolmentStatus
from app.models.user import User
from app.services import rbac

logger = logging.getLogger(__name__)


class TeachingError(Exception):
    """Refused: not yours to edit, or not in a state that allows it."""


@dataclass
class Attention:
    """One student worth looking at, and why."""

    student: User
    reason: str
    detail: str
    url: str = ""


@dataclass
class Workspace:
    courses: list = field(default_factory=list)
    student_count: int = 0
    draft_count: int = 0
    recent_attempts: list = field(default_factory=list)
    needs_attention: list[Attention] = field(default_factory=list)

    @property
    def has_anything(self) -> bool:
        return bool(self.courses)


# ---------------------------------------------------------------------------
# Scope
# ---------------------------------------------------------------------------

#: Privilege is carried by a permission, not by a role name. Roles are
#: configuration and can be renamed or recombined; "may publish a course"
#: is the thing this actually depends on.
PRIVILEGED_PERMISSION = "teaching.publish"


def is_privileged(user) -> bool:
    """Admins see the whole academy; a tutor sees only their own courses.

    Kept as one predicate so "who is allowed past the ownership check" is
    answered in a single place rather than re-derived at each call site.
    """
    return rbac.has_permission(user, PRIVILEGED_PERMISSION)


def courses_taught_by(user) -> list[Course]:
    statement = (
        select(Course)
        .options(selectinload(Course.modules).selectinload(Module.lessons))
        .order_by(Course.position, Course.title)
    )
    if not is_privileged(user):
        statement = statement.where(Course.instructor_id == user.id)
    return list(db.session.scalars(statement))


def _course_ids(user) -> list[int]:
    if is_privileged(user):
        return list(db.session.scalars(select(Course.id)))
    return list(
        db.session.scalars(
            select(Course.id).where(Course.instructor_id == user.id)
        )
    )


def students_of(user, *, limit: int | None = None) -> list[User]:
    """Everyone enrolled on a course this person teaches.

    An empty course list must not become "no filter at all" - an `IN ()`
    with nothing in it is the difference between a tutor seeing nobody and
    a tutor seeing every student in the academy.
    """
    course_ids = _course_ids(user)
    if not course_ids:
        return []

    statement = (
        select(User)
        .join(Enrolment, Enrolment.user_id == User.id)
        .join(Course, Course.offering_id == Enrolment.offering_id)
        .where(
            Course.id.in_(course_ids),
            Enrolment.status == EnrolmentStatus.ACTIVE,
        )
        .distinct()
        .order_by(User.full_name)
    )
    if limit is not None:
        statement = statement.limit(limit)
    return list(db.session.scalars(statement))


def teaches(user, student) -> bool:
    """Whether this person is one of your students.

    The check a tutor needs before messaging somebody. Derived from the
    same query the student list uses, so the two cannot disagree: if they
    are not on the list, you cannot open a conversation with them from
    here.
    """
    if is_privileged(user):
        return True
    return any(s.id == student.id for s in students_of(user))


def can_edit(course: Course, user) -> bool:
    return is_privileged(user) or course.instructor_id == user.id


def assert_can_edit(course: Course, user) -> None:
    """Raise rather than return a bool where the caller is about to write.

    A route that forgets to check a boolean fails open; one that forgets
    to call this fails closed at the next line, because nothing it needs
    has been returned to it.
    """
    if not can_edit(course, user):
        raise TeachingError("That course belongs to another tutor.")


# ---------------------------------------------------------------------------
# The workspace
# ---------------------------------------------------------------------------

def build(user) -> Workspace:
    courses = courses_taught_by(user)
    course_ids = [c.id for c in courses]

    workspace = Workspace(
        courses=courses,
        draft_count=sum(1 for c in courses if not c.is_published),
    )
    if not course_ids:
        return workspace

    students = students_of(user)
    workspace.student_count = len(students)
    student_ids = [s.id for s in students]

    if student_ids:
        workspace.recent_attempts = list(
            db.session.scalars(
                select(Attempt)
                .options(selectinload(Attempt.user),
                         selectinload(Attempt.exam))
                .where(
                    Attempt.user_id.in_(student_ids),
                    Attempt.status == AttemptStatus.SUBMITTED,
                )
                .order_by(Attempt.submitted_at.desc())
                .limit(12)
            )
        )
        workspace.needs_attention = _needs_attention(
            workspace.recent_attempts
        )

    return workspace


def score_percent(attempt: Attempt) -> int | None:
    """A percentage, or None while the attempt has no marked total.

    The model stores score and total rather than a percentage, because a
    stored percentage goes stale the moment a question is removed from a
    paper and re-marking changes the denominator.
    """
    if attempt.score is None or not attempt.total:
        return None
    return round(attempt.score / attempt.total * 100)


def _needs_attention(attempts, *, threshold: int = 40, limit: int = 6):
    """Students whose most recent paper went badly.

    Only the most recent attempt per student counts. Listing somebody
    three times for three bad papers buries the other people who also need
    looking at, and the tutor already knows they are struggling.
    """
    out: list[Attention] = []
    seen: set[int] = set()

    for attempt in attempts:
        if attempt.user_id in seen:
            continue
        seen.add(attempt.user_id)

        percent = score_percent(attempt)
        if percent is None or percent >= threshold:
            continue

        out.append(Attention(
            student=attempt.user,
            reason=f"Scored {percent}% on {attempt.exam.title}",
            detail="Most recent paper",
        ))
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------------------
# Course building
# ---------------------------------------------------------------------------

def next_position(rows) -> int:
    """Append to the end of an ordered list.

    max()+1 rather than len(): after a deletion those disagree, and len()
    silently gives the new row the position of an existing one.
    """
    return max((r.position for r in rows), default=-1) + 1


def add_module(course: Course, *, title: str) -> Module:
    module = Module(course_id=course.id, title=title.strip()[:160],
                    position=next_position(course.modules))
    db.session.add(module)
    db.session.commit()
    return module


def unique_slug(model, title: str, *, exclude_id: int | None = None) -> str:
    """A slug nothing else of this kind is using.

    Lesson slugs are unique across the WHOLE table, not per course, so two
    courses cannot both hold a lesson called "Introduction". Appending a
    number is the honest resolution; silently overwriting somebody else's
    row is not, and letting the insert fail raises a 500 on a form that
    looks like it should have worked.
    """
    base = slugify(title) or "lesson"
    candidate = base
    suffix = 2
    while True:
        clash = db.session.scalar(
            select(model).where(model.slug == candidate)
        )
        if clash is None or clash.id == exclude_id:
            return candidate
        candidate = f"{base}-{suffix}"
        suffix += 1


def add_lesson(module: Module, *, title: str, kind: str) -> Lesson:
    clean = title.strip()[:160]
    lesson = Lesson(module_id=module.id, title=clean, kind=kind,
                    slug=unique_slug(Lesson, clean),
                    position=next_position(module.lessons))
    db.session.add(lesson)
    db.session.commit()
    return lesson


def reorder(rows, ordered_ids: list[int]) -> None:
    """Apply an explicit order, ignoring anything not in the set.

    An id from another course arriving in the list is treated as noise
    rather than an error: the request still has to be honoured for the
    rows that are genuinely being moved.
    """
    by_id = {r.id: r for r in rows}
    position = 0
    for row_id in ordered_ids:
        row = by_id.get(row_id)
        if row is None:
            continue
        row.position = position
        position += 1
    db.session.commit()


def enrolment_count(course: Course) -> int:
    if course.offering_id is None:
        return 0
    return db.session.scalar(
        select(func.count(Enrolment.id)).where(
            Enrolment.offering_id == course.offering_id,
            Enrolment.status == EnrolmentStatus.ACTIVE,
        )
    ) or 0
