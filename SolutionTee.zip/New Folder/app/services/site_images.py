"""Assigning media to the public site's image slots.

Assignment is what connects the media library to the public site, and it
is also what makes `MediaUsage` meaningful: once a photograph is in a
slot, the library knows it is in use and refuses to delete it out from
under a live page.
"""
from __future__ import annotations

import logging

from sqlalchemy import select
from sqlalchemy.orm import joinedload

from app.content.site_slots import SLOTS_BY_KEY
from app.extensions import db
from app.models.base import utcnow
from app.models.media import Media
from app.models.site import SiteImage
from app.services.media import library as media_library

logger = logging.getLogger(__name__)

#: The content_type recorded against MediaUsage for these assignments.
USAGE_TYPE = "site_image"


class UnknownSlotError(KeyError):
    """The slot key does not correspond to any template hole."""


def _require_slot(slot: str):
    definition = SLOTS_BY_KEY.get(slot)
    if definition is None:
        raise UnknownSlotError(slot)
    return definition


def all_assignments() -> dict[str, Media | None]:
    """Every slot, whether assigned or not.

    One query with the media eagerly joined. The public templates call
    this once per request, so it must not become a query per slot.
    """
    rows = db.session.scalars(
        select(SiteImage).options(joinedload(SiteImage.media))
    ).all()
    assigned = {row.slot: row.media for row in rows
                if row.media is not None and not row.media.is_archived}
    return {slot: assigned.get(slot) for slot in SLOTS_BY_KEY}


def get(slot: str) -> Media | None:
    _require_slot(slot)
    row = db.session.scalar(
        select(SiteImage).options(joinedload(SiteImage.media))
        .where(SiteImage.slot == slot)
    )
    if row is None or row.media is None or row.media.is_archived:
        return None
    return row.media


def assign(slot: str, media: Media, *, actor=None) -> SiteImage:
    """Put an image in a slot, moving the usage record with it.

    The previous occupant's usage row is cleared first. Without that, an
    image swapped out months ago would still look "in use" and could
    never be deleted.
    """
    definition = _require_slot(slot)

    row = db.session.scalar(select(SiteImage).where(SiteImage.slot == slot))
    if row is None:
        row = SiteImage(slot=slot)
        db.session.add(row)

    media_library.clear_usage(content_type=USAGE_TYPE, content_id=slot)

    row.media_id = media.id
    row.updated_by_id = getattr(actor, "id", None)
    row.assigned_at = utcnow()
    db.session.commit()

    media_library.record_usage(
        media, content_type=USAGE_TYPE, content_id=slot,
        field_name="image", label=definition.name,
    )
    return row


def clear(slot: str, *, actor=None) -> None:
    """Empty a slot. The template falls back to its placeholder."""
    _require_slot(slot)

    row = db.session.scalar(select(SiteImage).where(SiteImage.slot == slot))
    if row is not None:
        row.media_id = None
        row.updated_by_id = getattr(actor, "id", None)
        row.assigned_at = None
        db.session.commit()

    media_library.clear_usage(content_type=USAGE_TYPE, content_id=slot)
