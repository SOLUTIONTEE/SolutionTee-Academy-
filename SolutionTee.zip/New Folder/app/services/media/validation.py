"""Upload validation.

Nothing the browser says is trusted: not the filename, not the
extension, not the Content-Type. The file is identified by decoding it,
and the stored object key is generated rather than derived from anything
the uploader controls.
"""
from __future__ import annotations

import hashlib
import io
import re
from dataclasses import dataclass

from PIL import Image, UnidentifiedImageError

#: Formats Pillow can decode and that browsers can render. SVG is
#: deliberately absent: it is a document format that can carry script,
#: and accepting it safely needs sanitisation rather than an allowlist
#: entry. It gets its own path if the developer asks for one.
ALLOWED_FORMATS: dict[str, tuple[str, str]] = {
    # Pillow format -> (canonical extension, mime type)
    "JPEG": ("jpg", "image/jpeg"),
    "PNG": ("png", "image/png"),
    "WEBP": ("webp", "image/webp"),
    "AVIF": ("avif", "image/avif"),
    "GIF": ("gif", "image/gif"),
}

MAX_PIXELS = 50_000_000
"""Refuse absurd dimensions.

A 'decompression bomb' is a small file that expands to gigabytes in
memory. Pillow warns above ~89M pixels; this project refuses earlier,
because no legitimate photograph of a classroom is 50 megapixels.
"""

MAX_DIMENSION = 12_000

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")
#: Stricter, for storage key segments. A dot is legal in a filename but
#: has no business in a generated path segment, and permitting it is what
#: lets "../.." survive as "....".
_UNSAFE_SEGMENT = re.compile(r"[^A-Za-z0-9_-]+")


class ValidationError(ValueError):
    """The upload was rejected. The message is shown to the uploader."""


@dataclass(frozen=True)
class InspectedImage:
    """What the file actually is, as opposed to what it claimed to be."""

    pillow_format: str
    extension: str
    mime_type: str
    width: int
    height: int
    file_size: int
    checksum: str


def safe_display_filename(filename: str, fallback: str = "upload") -> str:
    """A filename safe to store and echo back into HTML.

    This is for display and for the download name only. It is never used
    to build a storage key or a path - those are generated.
    """
    name = (filename or "").strip().replace("\\", "/").split("/")[-1]
    name = _UNSAFE.sub("-", name).strip("-.")
    # Windows reserves these regardless of extension.
    stem = name.split(".")[0].upper()
    if stem in {"CON", "PRN", "AUX", "NUL"} or re.fullmatch(r"COM\d|LPT\d", stem):
        name = f"file-{name}"
    return (name or fallback)[:180]


def inspect_image(data: bytes, *, max_bytes: int) -> InspectedImage:
    """Decode the upload and report what it really is.

    Raises ValidationError with a message meant for the person who
    uploaded the file.
    """
    size = len(data)
    if size == 0:
        raise ValidationError("That file is empty.")
    if size > max_bytes:
        limit_mb = max_bytes / (1024 * 1024)
        raise ValidationError(
            f"That file is {size / (1024 * 1024):.1f}MB. The limit is "
            f"{limit_mb:.0f}MB."
        )

    try:
        # verify() checks integrity but leaves the image unusable, so the
        # file is opened twice: once to verify, once to read properties.
        probe = Image.open(io.BytesIO(data))
        probe.verify()
        image = Image.open(io.BytesIO(data))
        # verify() checks structure but never decodes pixels, so a
        # truncated file passes it. load() does the decode and raises,
        # which is what actually catches a half-uploaded image.
        image.load()
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise ValidationError(
            "That file is not an image, or it is damaged."
        ) from exc

    fmt = (image.format or "").upper()
    if fmt not in ALLOWED_FORMATS:
        allowed = ", ".join(sorted({e.upper() for e, _ in ALLOWED_FORMATS.values()}))
        raise ValidationError(
            f"{fmt or 'That format'} is not supported. Use {allowed}."
        )

    width, height = image.size
    if width <= 0 or height <= 0:
        raise ValidationError("That image has no dimensions.")
    if width > MAX_DIMENSION or height > MAX_DIMENSION:
        raise ValidationError(
            f"That image is {width}x{height}. The limit is "
            f"{MAX_DIMENSION}px on a side."
        )
    if width * height > MAX_PIXELS:
        raise ValidationError("That image has too many pixels to process.")

    extension, mime_type = ALLOWED_FORMATS[fmt]
    return InspectedImage(
        pillow_format=fmt,
        extension=extension,
        mime_type=mime_type,
        width=width,
        height=height,
        file_size=size,
        checksum=hashlib.sha256(data).hexdigest(),
    )


def build_object_key(public_id: str, variant: str, extension: str,
                     *, created) -> str:
    """Generate the storage key for one variant.

    Entirely derived from values this application controls. The date
    prefix keeps any single bucket prefix from growing without bound,
    which matters for listing performance once there are thousands of
    assets.
    """
    safe_variant = _UNSAFE_SEGMENT.sub("", variant) or "original"
    safe_ext = re.sub(r"[^A-Za-z0-9]+", "", extension).lower() or "bin"
    safe_id = _UNSAFE_SEGMENT.sub("", public_id)
    if not safe_id:
        raise ValidationError("cannot build a storage key without an id")
    return (
        f"media/{created:%Y/%m}/{safe_id}/{safe_variant}.{safe_ext}"
    )
