"""Media library operations.

All the decisions live here. Routes validate their input and call these
functions; they never touch storage or build a query themselves.
"""
from __future__ import annotations

import io
import logging
from dataclasses import dataclass, field

from sqlalchemy import func, or_, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.base import generate_public_id, utcnow
from app.models.media import Media, MediaFolder, MediaUsage
from app.services.media.processing import (
    normalise_original, render_variants,
)
from app.services.media.validation import (
    ValidationError, build_object_key, inspect_image, safe_display_filename,
)
from app.services.storage import get_storage
from app.services.storage.base import StorageError

logger = logging.getLogger(__name__)

DEFAULT_PAGE_SIZE = 48


class MediaInUseError(RuntimeError):
    """Deletion refused: the asset is still referenced by live content."""

    def __init__(self, media: Media) -> None:
        self.media = media
        self.usages = list(media.usages)
        super().__init__(
            f"{media.original_filename} is used in {len(self.usages)} place(s)"
        )


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------

@dataclass
class UploadResult:
    """One file's outcome within a batch.

    A batch reports per-file results rather than failing as a unit: one
    corrupt image among forty must not discard the other thirty-nine.
    """

    filename: str
    ok: bool
    media: Media | None = None
    error: str = ""
    duplicate_of: str = ""


def upload_image(data: bytes, filename: str, *, uploaded_by_id: int | None,
                 folder_id: int | None = None, max_bytes: int,
                 alt_text: str = "") -> Media:
    """Validate, process, store and record one image.

    Storage is written before the database row is committed. If the
    commit then fails, the objects are removed again - an orphaned row
    pointing at nothing is worse than an orphaned object, because the
    row is what the site renders from.
    """
    inspected = inspect_image(data, max_bytes=max_bytes)

    existing = db.session.scalar(
        select(Media).where(Media.checksum == inspected.checksum,
                            Media.is_archived.is_(False))
    )
    if existing is not None:
        # The same bytes are already stored. Re-uploading a photograph
        # that is already in the library returns the existing asset
        # rather than paying for a second copy of it.
        return existing

    created = utcnow()
    public_id = generate_public_id()
    storage = get_storage()
    written: list[str] = []

    try:
        original_bytes = normalise_original(data, inspected.pillow_format)
        original_key = build_object_key(public_id, "original",
                                        inspected.extension, created=created)
        storage.save(original_key, io.BytesIO(original_bytes),
                     inspected.mime_type)
        written.append(original_key)

        variants: dict[str, dict] = {}
        for rendered in render_variants(data, inspected.width):
            key = build_object_key(public_id, rendered.name,
                                   rendered.extension, created=created)
            storage.save(key, io.BytesIO(rendered.data), rendered.mime_type)
            written.append(key)
            variants[rendered.name] = {
                "key": key,
                "width": rendered.width,
                "height": rendered.height,
                "mime_type": rendered.mime_type,
                "file_size": len(rendered.data),
            }

        media = Media(
            public_id=public_id,
            object_key=original_key,
            variants=variants,
            original_filename=safe_display_filename(filename),
            mime_type=inspected.mime_type,
            extension=inspected.extension,
            file_size=len(original_bytes),
            width=inspected.width,
            height=inspected.height,
            checksum=inspected.checksum,
            alt_text=alt_text.strip()[:255],
            folder_id=folder_id,
            uploaded_by_id=uploaded_by_id,
        )
        db.session.add(media)
        db.session.commit()
        return media

    except Exception:
        db.session.rollback()
        for key in written:
            try:
                storage.delete(key)
            except StorageError:
                # Already logged. Losing the cleanup must not replace the
                # original error with a less useful one.
                logger.warning("Could not clean up orphaned object %s", key)
        raise


def upload_batch(files, *, uploaded_by_id: int | None, max_bytes: int,
                 folder_id: int | None = None) -> list[UploadResult]:
    """Process many files, reporting each independently."""
    results: list[UploadResult] = []

    for storage_file in files:
        name = storage_file.filename or "upload"
        try:
            data = storage_file.read()
            before = db.session.scalar(
                select(func.count()).select_from(Media)
            )
            media = upload_image(
                data, name, uploaded_by_id=uploaded_by_id,
                folder_id=folder_id, max_bytes=max_bytes,
            )
            after = db.session.scalar(select(func.count()).select_from(Media))
            results.append(UploadResult(
                filename=name, ok=True, media=media,
                duplicate_of=(media.public_id if after == before else ""),
            ))
        except ValidationError as exc:
            results.append(UploadResult(filename=name, ok=False,
                                        error=str(exc)))
        except StorageError:
            results.append(UploadResult(
                filename=name, ok=False,
                error="Storage is unavailable. Try again shortly.",
            ))
        except Exception:  # noqa: BLE001 - one bad file cannot stop a batch
            logger.exception("Unexpected failure uploading %s", name)
            results.append(UploadResult(
                filename=name, ok=False,
                error="Something went wrong with this file.",
            ))

    return results


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

@dataclass
class MediaPage:
    items: list[Media] = field(default_factory=list)
    total: int = 0
    page: int = 1
    per_page: int = DEFAULT_PAGE_SIZE

    @property
    def pages(self) -> int:
        return max(1, -(-self.total // self.per_page))

    @property
    def has_next(self) -> bool:
        return self.page < self.pages

    @property
    def has_prev(self) -> bool:
        return self.page > 1


def browse(*, query: str = "", folder_id: int | None = None,
           include_archived: bool = False, page: int = 1,
           per_page: int = DEFAULT_PAGE_SIZE) -> MediaPage:
    """Paginated media listing.

    Always paginated. A library that has grown to several thousand assets
    must never try to render itself in one response, and the grid only
    ever loads thumbnails.
    """
    page = max(1, page)
    per_page = max(1, min(per_page, 100))

    statement = select(Media).options(selectinload(Media.folder))
    if not include_archived:
        statement = statement.where(Media.is_archived.is_(False))
    if folder_id is not None:
        statement = statement.where(Media.folder_id == folder_id)

    term = (query or "").strip()
    if term:
        pattern = f"%{term}%"
        statement = statement.where(or_(
            Media.original_filename.ilike(pattern),
            Media.title.ilike(pattern),
            Media.alt_text.ilike(pattern),
            Media.caption.ilike(pattern),
        ))

    total = db.session.scalar(
        select(func.count()).select_from(statement.subquery())
    ) or 0

    items = list(db.session.scalars(
        statement.order_by(Media.created_at.desc(), Media.id.desc())
        .limit(per_page).offset((page - 1) * per_page)
    ))

    return MediaPage(items=items, total=total, page=page, per_page=per_page)


def get_by_public_id(public_id: str) -> Media | None:
    return db.session.scalar(
        select(Media)
        .options(selectinload(Media.usages), selectinload(Media.folder))
        .where(Media.public_id == public_id)
    )


def variant_url(media: Media, variant: str = "medium") -> str:
    """URL for a variant, falling back to the original.

    A caller asking for "thumb" on an image too small to have one gets
    the original rather than a broken link.
    """
    storage = get_storage()
    if variant == "original":
        return storage.url(media.object_key)
    entry = (media.variants or {}).get(variant)
    if not entry:
        return storage.url(media.object_key)
    return storage.url(entry["key"])


def variant_size(media: Media, variant: str = "medium") -> tuple[int, int]:
    """Intrinsic dimensions of the file a caller will actually receive.

    The width/height attributes exist to reserve the right box before the
    image arrives. Quoting the original's dimensions while serving a
    thumbnail happens to work only because variants are scaled
    proportionally; it would silently mis-reserve space the moment any
    variant is cropped.
    """
    entry = (media.variants or {}).get(variant)
    if entry:
        return int(entry["width"]), int(entry["height"])
    return int(media.width or 0), int(media.height or 0)


def all_object_keys(media: Media) -> list[str]:
    keys = [media.object_key]
    keys.extend(entry["key"] for entry in (media.variants or {}).values())
    return keys


# ---------------------------------------------------------------------------
# Editing
# ---------------------------------------------------------------------------

def update_metadata(media: Media, *, alt_text: str | None = None,
                    title: str | None = None, caption: str | None = None,
                    folder_id: int | None = None,
                    is_decorative: bool | None = None) -> Media:
    if alt_text is not None:
        media.alt_text = alt_text.strip()[:255]
    if title is not None:
        media.title = title.strip()[:160]
    if caption is not None:
        media.caption = caption.strip()
    if is_decorative is not None:
        media.is_decorative = bool(is_decorative)
        if media.is_decorative:
            # A decorative image renders alt="", so stored alt text would
            # be dead data that misleads the next editor.
            media.alt_text = ""
    if folder_id is not None:
        media.folder_id = folder_id or None

    db.session.commit()
    return media


# ---------------------------------------------------------------------------
# Usage tracking
# ---------------------------------------------------------------------------

def record_usage(media: Media, *, content_type: str, content_id: str,
                 field_name: str = "", label: str = "") -> MediaUsage:
    """Record that a piece of content references this asset.

    Idempotent: saving the same page twice updates the existing row
    rather than adding a duplicate.
    """
    usage = db.session.scalar(
        select(MediaUsage).where(
            MediaUsage.media_id == media.id,
            MediaUsage.content_type == content_type,
            MediaUsage.content_id == str(content_id),
            MediaUsage.field == field_name,
        )
    )
    if usage is None:
        usage = MediaUsage(
            media_id=media.id, content_type=content_type,
            content_id=str(content_id), field=field_name,
            created_at=utcnow(),
        )
        db.session.add(usage)
    usage.label = label[:160]
    db.session.commit()
    return usage


def clear_usage(*, content_type: str, content_id: str,
                field_name: str | None = None) -> int:
    """Drop usage rows for a content slot, e.g. when its image changes."""
    statement = select(MediaUsage).where(
        MediaUsage.content_type == content_type,
        MediaUsage.content_id == str(content_id),
    )
    if field_name is not None:
        statement = statement.where(MediaUsage.field == field_name)

    rows = list(db.session.scalars(statement))
    for row in rows:
        db.session.delete(row)
    db.session.commit()
    return len(rows)


# ---------------------------------------------------------------------------
# Archiving and deletion
# ---------------------------------------------------------------------------

def archive(media: Media) -> Media:
    """Remove from the picker while continuing to serve.

    This is the safe default for retiring an image. The bytes stay, so
    any page still referencing it keeps rendering.
    """
    media.is_archived = True
    db.session.commit()
    return media


def restore(media: Media) -> Media:
    media.is_archived = False
    db.session.commit()
    return media


def delete(media: Media, *, force: bool = False) -> None:
    """Permanently remove an asset and its objects.

    Refuses while the asset is referenced, unless an authorised
    administrator forces it. Deleting an in-use image does not raise an
    error on the page that uses it - it silently leaves a hole - so the
    refusal has to happen here.

    The database row goes first. If object deletion then fails, the
    result is unreferenced bytes in the bucket, which costs storage;
    the reverse order would leave rows pointing at objects that no
    longer exist, which breaks pages.
    """
    if media.usages and not force:
        raise MediaInUseError(media)

    keys = all_object_keys(media)
    db.session.delete(media)
    db.session.commit()

    storage = get_storage()
    for key in keys:
        try:
            storage.delete(key)
        except StorageError:
            logger.warning("Media row deleted but object %s remains", key)


# ---------------------------------------------------------------------------
# Folders
# ---------------------------------------------------------------------------

def list_folders() -> list[MediaFolder]:
    return list(db.session.scalars(
        select(MediaFolder).order_by(MediaFolder.position, MediaFolder.name)
    ))


def counts_by_folder() -> dict[int | None, int]:
    """One grouped query, not one count per folder."""
    rows = db.session.execute(
        select(Media.folder_id, func.count(Media.id))
        .where(Media.is_archived.is_(False))
        .group_by(Media.folder_id)
    ).all()
    return {folder_id: count for folder_id, count in rows}
