"""Image processing.

Produces the variants the site actually serves, so a 360px phone never
downloads a 4000px original. Strips metadata on the way through, which
matters more than it sounds: a photograph taken on a phone in the centre
carries GPS coordinates, and publishing those alongside pictures of
students is a privacy problem, not a technicality.
"""
from __future__ import annotations

import io
from dataclasses import dataclass

from PIL import Image, ImageOps

#: Widths the templates ask for, matched to how images are actually
#: placed: a grid thumbnail, a column-width image, and a full-bleed hero.
#: Each is emitted only when the original is genuinely wider - upscaling
#: produces a bigger file that looks worse.
VARIANT_WIDTHS: dict[str, int] = {
    "thumb": 400,
    "medium": 1000,
    "large": 1600,
}

#: WebP for variants: broadly supported, and materially smaller than JPEG
#: at the same visual quality, which is the whole point on a Nigerian
#: mobile connection.
VARIANT_FORMAT = "WEBP"
VARIANT_EXTENSION = "webp"
VARIANT_MIME = "image/webp"

#: High enough that re-compression is not visible on photographs, low
#: enough to be worth doing.
VARIANT_QUALITY = 82


@dataclass(frozen=True)
class RenderedVariant:
    name: str
    data: bytes
    width: int
    height: int
    mime_type: str
    extension: str


def normalise_original(data: bytes, pillow_format: str) -> bytes:
    """Return the original with orientation applied and metadata removed.

    EXIF orientation is applied to the pixels first. If it were merely
    stripped, every photograph taken in portrait would display on its
    side, because the rotation lived only in the tag being discarded.
    """
    with Image.open(io.BytesIO(data)) as image:
        if pillow_format == "GIF" and getattr(image, "is_animated", False):
            # Re-encoding would flatten the animation to a single frame.
            # An animated GIF is stored exactly as uploaded.
            return data

        upright = ImageOps.exif_transpose(image)
        # Rebuilding from raw bytes is what actually drops EXIF, ICC and
        # XMP: those live in `info`, which a copy() would carry over.
        clean = Image.frombytes(upright.mode, upright.size,
                                upright.tobytes())

        buffer = io.BytesIO()
        save_kwargs: dict = {}
        if pillow_format == "JPEG":
            clean = clean.convert("RGB")
            save_kwargs = {"quality": 90, "optimize": True,
                           "progressive": True}
        elif pillow_format == "PNG":
            save_kwargs = {"optimize": True}
        elif pillow_format == "WEBP":
            save_kwargs = {"quality": 90, "method": 4}

        clean.save(buffer, format=pillow_format, **save_kwargs)
        return buffer.getvalue()


def render_variants(data: bytes, original_width: int) -> list[RenderedVariant]:
    """Build every variant narrower than the original."""
    rendered: list[RenderedVariant] = []

    with Image.open(io.BytesIO(data)) as source:
        upright = ImageOps.exif_transpose(source)
        if upright.mode not in ("RGB", "RGBA"):
            upright = upright.convert(
                "RGBA" if "A" in upright.mode else "RGB"
            )

        for name, target_width in VARIANT_WIDTHS.items():
            if original_width <= target_width:
                # Never upscale: a larger file that looks worse.
                continue

            ratio = target_width / float(upright.width)
            target_height = max(1, round(upright.height * ratio))
            resized = upright.resize(
                (target_width, target_height), Image.LANCZOS
            )

            buffer = io.BytesIO()
            resized.save(buffer, format=VARIANT_FORMAT,
                         quality=VARIANT_QUALITY, method=4)
            rendered.append(RenderedVariant(
                name=name,
                data=buffer.getvalue(),
                width=target_width,
                height=target_height,
                mime_type=VARIANT_MIME,
                extension=VARIANT_EXTENSION,
            ))

    return rendered


def srcset_for(media) -> str:
    """Build a srcset from whichever variants exist.

    Returns an empty string when there are none, so a template can fall
    back to a plain src rather than emitting a malformed attribute.
    """
    from app.services.media.library import variant_url

    parts = []
    for name in VARIANT_WIDTHS:
        entry = (media.variants or {}).get(name)
        if not entry:
            continue
        parts.append(f"{variant_url(media, name)} {entry['width']}w")

    if media.width:
        parts.append(f"{variant_url(media, 'original')} {media.width}w")

    return ", ".join(parts)
