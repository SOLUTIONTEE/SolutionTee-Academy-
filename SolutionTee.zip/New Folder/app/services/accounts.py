"""Account operations.

The decisions about who may sign in, and what a failed attempt costs,
live here rather than in the route.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, timedelta

from sqlalchemy import func, select

from app.extensions import db
from app.models.base import utcnow
from app.models.enums import AccountStatus, AuditAction, RoleName
from app.models.rbac import Role
from app.models.security import LoginAttempt
from app.models.user import ParentProfile, StudentProfile, User
from app.services.audit import record as record_audit
from app.services.security.passwords import (
    hash_password, needs_rehash, verify_password,
)

logger = logging.getLogger(__name__)

#: Lock-out policy. Counted per email address, over a rolling window, so
#: a distributed attempt against one account is still caught - IP-based
#: rate limiting alone would not be.
MAX_FAILED_ATTEMPTS = 8
LOCKOUT_WINDOW = timedelta(minutes=15)


@dataclass(frozen=True)
class LoginResult:
    ok: bool
    user: User | None = None
    #: Shown to the person trying to sign in.
    message: str = ""


def _record_attempt(email: str, *, successful: bool, ip: str | None,
                    user_agent: str | None) -> None:
    db.session.add(LoginAttempt(
        email=email.lower()[:255],
        ip_address=(ip or "")[:45] or None,
        user_agent=(user_agent or "")[:255] or None,
        successful=successful,
        created_at=utcnow(),
    ))
    db.session.commit()


def recent_failures(email: str) -> int:
    since = utcnow() - LOCKOUT_WINDOW
    return db.session.scalar(
        select(func.count())
        .select_from(LoginAttempt)
        .where(
            LoginAttempt.email == email.lower(),
            LoginAttempt.successful.is_(False),
            LoginAttempt.created_at >= since,
        )
    ) or 0


def find_by_email(email: str) -> User | None:
    return db.session.scalar(
        select(User).where(User.email == (email or "").strip().lower())
    )


def authenticate(email: str, password: str, *, ip: str | None = None,
                 user_agent: str | None = None) -> LoginResult:
    """Verify credentials and report whether sign-in may proceed.

    Every rejection returns the same message. Saying "no such account"
    versus "wrong password" tells an attacker which addresses are
    registered, which is a disclosure this application does not need to
    make.
    """
    email = (email or "").strip().lower()
    generic = "That email and password do not match."

    if not email or not password:
        return LoginResult(False, message=generic)

    if recent_failures(email) >= MAX_FAILED_ATTEMPTS:
        # Deliberately distinct from the generic message: the person
        # affected is usually the legitimate owner, and leaving them
        # guessing is worse than confirming a temporary lock.
        return LoginResult(
            False,
            message=("Too many failed attempts. Wait 15 minutes, or reset "
                     "your password."),
        )

    user = find_by_email(email)

    # Verify even when the account does not exist, against a throwaway
    # hash, so a missing account does not answer measurably faster than a
    # wrong password.
    stored = user.password_hash if user else (
        "$argon2id$v=19$m=65536,t=2,p=2$"
        "c29tZXNhbHRzb21lc2FsdA$0000000000000000000000000000000000000000000"
    )
    correct = verify_password(stored, password)

    if user is None or not correct:
        _record_attempt(email, successful=False, ip=ip, user_agent=user_agent)
        record_audit(AuditAction.LOGIN_FAILURE, target=f"email:{email}",
                     summary="Failed sign-in attempt")
        return LoginResult(False, message=generic)

    if user.status == AccountStatus.SUSPENDED:
        _record_attempt(email, successful=False, ip=ip, user_agent=user_agent)
        return LoginResult(
            False,
            message=("This account is suspended. Contact us if you think "
                     "that is a mistake."),
        )

    if user.status == AccountStatus.DELETED:
        _record_attempt(email, successful=False, ip=ip, user_agent=user_agent)
        return LoginResult(False, message=generic)

    # Parameters may have been raised since this hash was written, and a
    # successful login is the only moment the plaintext exists to redo it.
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(password)

    user.last_login_at = utcnow()
    db.session.commit()

    _record_attempt(email, successful=True, ip=ip, user_agent=user_agent)
    record_audit(AuditAction.LOGIN_SUCCESS, actor=user,
                 target=f"user:{user.public_id}", summary="Signed in")
    return LoginResult(True, user=user)


def create_staff_account(*, email: str, full_name: str, password: str,
                         role_name: str, actor: User | None = None) -> User:
    """Create an account with a staff role.

    Never reachable from public registration: a visitor may only ever
    self-register as a student or a parent. This is called from the CLI
    and, later, from the admin interface.
    """
    if role_name not in RoleName.STAFF_ONLY:
        raise ValueError(f"{role_name!r} is not a staff role")

    email = (email or "").strip().lower()
    if find_by_email(email) is not None:
        raise ValueError(f"An account already exists for {email}")

    role = db.session.scalar(select(Role).where(Role.name == role_name))
    if role is None:
        raise ValueError(
            f"Role {role_name!r} is missing. Run 'flask sync-rbac' first."
        )

    user = User(
        email=email,
        full_name=full_name.strip(),
        password_hash=hash_password(password),
        status=AccountStatus.ACTIVE,
        email_verified_at=utcnow(),
        password_changed_at=utcnow(),
    )
    user.roles.append(role)
    db.session.add(user)
    db.session.commit()

    record_audit(AuditAction.STAFF_CREATE, actor=actor,
                 target=f"user:{user.public_id}",
                 summary=f"Created {role_name} account")
    return user


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def find_by_public_id(public_id: str) -> User | None:
    if not public_id:
        return None
    return db.session.scalar(
        select(User).where(User.public_id == public_id)
    )


def age_on(born: date | None, today: date | None = None) -> int | None:
    """Whole years old. None when no date of birth was given."""
    if born is None:
        return None
    today = today or utcnow().date()
    return (today.year - born.year
            - ((today.month, today.day) < (born.month, born.day)))


def is_minor(user: User) -> bool:
    """Whether this account needs a guardian's consent.

    An unknown date of birth counts as a minor. Guessing the other way
    would let a student skip consent simply by leaving the field blank.
    """
    from flask import current_app

    years = age_on(user.date_of_birth)
    if years is None:
        return True
    return years < current_app.config["MINOR_AGE_THRESHOLD"]


@dataclass(frozen=True)
class RegistrationResult:
    ok: bool
    user: User | None = None
    message: str = ""
    #: True when a guardian consent code was sent as well.
    guardian_required: bool = False


def register(*, email: str, full_name: str, password: str, role_name: str,
             date_of_birth: date | None = None, phone: str = "",
             guardian_email: str = "", guardian_name: str = "") -> RegistrationResult:
    """Create a self-service account.

    Only ever a student or a parent. A visitor cannot register as staff
    under any circumstances - the check is here, in the service, so no
    future route can bypass it by passing a different role.
    """
    if role_name not in RoleName.SELF_SERVICE:
        # Not a user-facing message: reaching this means a bug or an
        # attempt to tamper with the form.
        logger.warning("Blocked public registration attempt as %r", role_name)
        raise ValueError("public registration is limited to students and parents")

    email = (email or "").strip().lower()
    existing = find_by_email(email)
    if existing is not None:
        # Deliberately the same message a fresh registration would give.
        # Saying "that email is taken" tells a stranger who has an
        # account here, which for a school is information worth
        # withholding.
        return RegistrationResult(
            ok=False, message="ALREADY_REGISTERED", user=existing,
        )

    role = db.session.scalar(select(Role).where(Role.name == role_name))
    if role is None:
        raise ValueError(
            f"Role {role_name!r} is missing. Run 'flask sync-rbac' first."
        )

    user = User(
        email=email,
        full_name=full_name.strip(),
        phone=(phone or "").strip() or None,
        date_of_birth=date_of_birth,
        password_hash=hash_password(password),
        status=AccountStatus.ACTIVE,
        password_changed_at=utcnow(),
    )

    needs_guardian = False
    if role_name == RoleName.STUDENT:
        needs_guardian = is_minor(user)
        if needs_guardian:
            user.guardian_email = (guardian_email or "").strip().lower() or None
            user.guardian_name = (guardian_name or "").strip() or None
        user.student_profile = StudentProfile()
    elif role_name == RoleName.PARENT:
        user.parent_profile = ParentProfile()

    user.roles.append(role)
    db.session.add(user)
    db.session.commit()

    return RegistrationResult(ok=True, user=user,
                              guardian_required=needs_guardian)


def mark_email_verified(user: User) -> User:
    if user.email_verified_at is None:
        user.email_verified_at = utcnow()
        db.session.commit()
        record_audit(AuditAction.ACCOUNT_VERIFIED, actor=user,
                     target=f"user:{user.public_id}", summary="Email verified")
    return user


def mark_guardian_verified(user: User) -> User:
    if user.guardian_verified_at is None:
        user.guardian_verified_at = utcnow()
        db.session.commit()
        record_audit(AuditAction.GUARDIAN_VERIFIED, actor=user,
                     target=f"user:{user.public_id}",
                     summary="Guardian consent confirmed")
    return user


def set_password(user: User, password: str) -> User:
    """Change a password and invalidate everything tied to the old one."""
    user.password_hash = hash_password(password)
    user.password_changed_at = utcnow()
    db.session.commit()
    record_audit(AuditAction.PASSWORD_RESET, actor=user,
                 target=f"user:{user.public_id}", summary="Password changed")
    return user


# ---------------------------------------------------------------------------
# Access gating
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AccessState:
    """Why an account may or may not use the platform yet."""

    allowed: bool
    reason: str = ""
    message: str = ""


def access_state(user: User) -> AccessState:
    """Whether a signed-in account may reach protected areas.

    Signing in and being allowed through are different questions. A
    student who has not verified their email can sign in - so they can
    see what is missing and act on it - but cannot enrol or sit a paper.
    """
    if user is None or not getattr(user, "is_authenticated", False):
        return AccessState(False, "anonymous", "Sign in to continue.")

    if user.status == AccountStatus.SUSPENDED:
        return AccessState(
            False, "suspended",
            "This account is suspended. Contact us if that is a mistake.",
        )

    if user.email_verified_at is None:
        return AccessState(
            False, "unverified",
            "Confirm your email address to finish setting up your account.",
        )

    if (user.guardian_email and user.guardian_verified_at is None):
        return AccessState(
            False, "guardian_pending",
            "We are waiting for your parent or guardian to confirm their "
            "consent.",
        )

    return AccessState(True)
