"""Storage backend interface.

Two implementations: local disk for development, Cloudflare R2 for
production. Selected by STORAGE_BACKEND. Callers deal in object keys and
never in filesystem paths or bucket names, so swapping the backend
changes no calling code.
"""
from __future__ import annotations

from typing import BinaryIO, Protocol


class StorageError(RuntimeError):
    """A backend operation failed. The cause is logged, not shown."""


class Storage(Protocol):
    def save(self, key: str, stream: BinaryIO, content_type: str) -> None:
        """Write an object, replacing anything already at `key`."""

    def delete(self, key: str) -> None:
        """Remove an object. Deleting a missing key is not an error."""

    def exists(self, key: str) -> bool:
        ...

    def open(self, key: str) -> BinaryIO:
        """Read an object back. Used by the development file server."""

    def url(self, key: str) -> str:
        """A URL a browser can load this object from."""

    def signed_url(self, key: str, expires_in: int = 300) -> str:
        """A time-limited URL for an asset that is not public.

        Paid and private material must not sit behind a permanent
        unguessable URL: once such a link leaks it is valid forever.
        """
