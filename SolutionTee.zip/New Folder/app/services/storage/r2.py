"""Cloudflare R2 storage.

R2 speaks the S3 API, so boto3 drives it. Credentials come from the
environment and are never logged, including in an exception message.
"""
from __future__ import annotations

import logging
import threading
from typing import BinaryIO

from app.services.storage.base import StorageError

logger = logging.getLogger(__name__)


class R2Storage:
    def __init__(self, *, access_key: str, secret_key: str, endpoint: str,
                 bucket: str, public_url: str = "") -> None:
        missing = [name for name, value in (
            ("R2_ACCESS_KEY", access_key), ("R2_SECRET_KEY", secret_key),
            ("R2_ENDPOINT", endpoint), ("R2_BUCKET", bucket),
        ) if not value]
        if missing:
            # Names only. Never the values.
            raise StorageError(
                "R2 storage is selected but not configured: "
                + ", ".join(missing)
            )

        self._access_key = access_key
        self._secret_key = secret_key
        self._endpoint = endpoint
        self.bucket = bucket
        self.public_url = public_url.rstrip("/")
        self._client = None
        self._lock = threading.Lock()

    @property
    def client(self):
        """Built once, lazily, and shared.

        boto3 clients are thread-safe once constructed but their creation
        is not, hence the lock. Building one per request would add a
        needless handshake to every upload.
        """
        if self._client is None:
            with self._lock:
                if self._client is None:
                    import boto3
                    from botocore.config import Config

                    self._client = boto3.client(
                        "s3",
                        endpoint_url=self._endpoint,
                        aws_access_key_id=self._access_key,
                        aws_secret_access_key=self._secret_key,
                        region_name="auto",
                        config=Config(
                            signature_version="s3v4",
                            retries={"max_attempts": 3, "mode": "standard"},
                        ),
                    )
        return self._client

    def save(self, key: str, stream: BinaryIO, content_type: str) -> None:
        try:
            stream.seek(0)
            self.client.upload_fileobj(
                stream, self.bucket, key,
                ExtraArgs={
                    "ContentType": content_type,
                    # Immutable: every key contains a unique id, so a key
                    # never points at different bytes later.
                    "CacheControl": "public, max-age=31536000, immutable",
                },
            )
        except Exception as exc:  # noqa: BLE001 - boto3 raises broadly
            logger.exception("R2 upload failed for key %s", key)
            raise StorageError("could not upload object") from exc

    def delete(self, key: str) -> None:
        try:
            self.client.delete_object(Bucket=self.bucket, Key=key)
        except Exception as exc:  # noqa: BLE001
            logger.exception("R2 delete failed for key %s", key)
            raise StorageError("could not delete object") from exc

    def exists(self, key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:  # noqa: BLE001 - a 404 is the expected miss
            return False

    def open(self, key: str) -> BinaryIO:
        import io

        try:
            buffer = io.BytesIO()
            self.client.download_fileobj(self.bucket, key, buffer)
            buffer.seek(0)
            return buffer
        except Exception as exc:  # noqa: BLE001
            logger.exception("R2 download failed for key %s", key)
            raise StorageError("could not read object") from exc

    def url(self, key: str) -> str:
        if not self.public_url:
            # Without a public hostname there is no unauthenticated URL;
            # a signed one is the only correct answer.
            return self.signed_url(key)
        return f"{self.public_url}/{key}"

    def signed_url(self, key: str, expires_in: int = 300) -> str:
        try:
            return self.client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket, "Key": key},
                ExpiresIn=expires_in,
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("R2 presign failed for key %s", key)
            raise StorageError("could not sign object URL") from exc
