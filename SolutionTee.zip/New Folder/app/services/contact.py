"""Handling contact enquiries.

The order matters and is the whole point: **store, then send**. Email is
the part that fails — a wrong key, a bounced sender, the provider down
for an hour — and an enquiry that only ever existed inside a failed email
is a customer nobody knows they lost. A failed forward flags the row
instead of losing it.
"""
from __future__ import annotations

import logging

from sqlalchemy import func, select

from app.extensions import db
from app.models.base import utcnow
from app.models.contact import ContactMessage, ContactStatus, ContactTopic
from app.services import mail

logger = logging.getLogger(__name__)


class ContactError(ValueError):
    """The enquiry could not be accepted. The message is shown."""


def validate(*, full_name: str, email: str, message: str) -> None:
    if not full_name.strip():
        raise ContactError("Tell us your name.")
    if not email.strip() or "@" not in email:
        raise ContactError("We need an email address we can reply to.")
    if len(message.strip()) < 10:
        raise ContactError(
            "Tell us a little more so we can actually answer you."
        )


def record(*, full_name: str, email: str, message: str, topic: str = "",
           subject: str = "", phone: str = "", user=None,
           ip_address: str | None = None) -> ContactMessage:
    """Store an enquiry and try to forward it.

    Returns the stored row whether or not the forward worked. The caller
    thanks the sender either way: from their side the message *has* been
    received, and telling them otherwise would make them send it twice.
    """
    validate(full_name=full_name, email=email, message=message)

    entry = ContactMessage(
        full_name=full_name.strip()[:120],
        email=email.strip().lower()[:255],
        phone=phone.strip()[:32],
        topic=topic if topic in ContactTopic.LABELS else ContactTopic.OTHER,
        subject=subject.strip()[:200],
        message=message.strip(),
        user_id=getattr(user, "id", None) if user else None,
        ip_address=ip_address,
    )
    db.session.add(entry)
    db.session.commit()

    entry.was_forwarded = _forward(entry)
    db.session.commit()

    if not entry.was_forwarded:
        # Stored but nobody was told. Loud in the log, and flagged in the
        # admin so it can be picked up by hand.
        logger.error("Contact message %s stored but NOT forwarded",
                     entry.public_id)

    return entry


def _forward(entry: ContactMessage) -> bool:
    """Send the enquiry to the contact inbox.

    Never raises: a mail failure must not roll back a stored enquiry or
    show the sender an error for something already safely recorded.
    """
    from flask import current_app

    inbox = current_app.config.get("CONTACT_INBOX")
    if not inbox:
        logger.warning("No CONTACT_INBOX configured; message %s not sent",
                       entry.public_id)
        return False

    try:
        result = mail.send(mail.Message(
            to=inbox,
            subject=f"[{entry.topic_label}] {entry.subject or 'Website enquiry'}",
            html=render_forward(entry),
            # The identity key, not an address: the transport resolves
            # it to the configured support sender.
            sender="support",
            # So staff can hit reply and reach the sender directly.
            reply_to=entry.email,
        ))
        return bool(getattr(result, "ok", True))
    except Exception:  # noqa: BLE001 - logged; the enquiry is already safe
        logger.exception("Forwarding contact message %s failed",
                         entry.public_id)
        return False


def render_forward(entry: ContactMessage) -> str:
    from flask import render_template

    return render_template("email/contact_forward.html", entry=entry)


# ---------------------------------------------------------------------------
# Staff side
# ---------------------------------------------------------------------------

def unanswered_count() -> int:
    return db.session.scalar(
        select(func.count()).select_from(ContactMessage)
        .where(ContactMessage.status == ContactStatus.NEW)
    ) or 0


def not_forwarded() -> list[ContactMessage]:
    """Enquiries nobody was emailed about.

    Surfaced deliberately: these are the ones most likely to be missed,
    because the usual signal that one arrived never went out.
    """
    return list(db.session.scalars(
        select(ContactMessage)
        .where(ContactMessage.was_forwarded.is_(False),
               ContactMessage.status == ContactStatus.NEW)
        .order_by(ContactMessage.created_at.desc())
    ))


def browse(*, status: str = "", limit: int = 100) -> list[ContactMessage]:
    statement = (
        select(ContactMessage)
        .order_by(ContactMessage.created_at.desc())
        .limit(limit)
    )
    if status:
        statement = statement.where(ContactMessage.status == status)
    return list(db.session.scalars(statement))


def mark(entry: ContactMessage, status: str, *, actor=None,
         note: str = "") -> ContactMessage:
    if status not in ContactStatus.LABELS:
        raise ContactError("Unknown status.")

    entry.status = status
    entry.handled_by_id = getattr(actor, "id", None)
    if status == ContactStatus.REPLIED and entry.replied_at is None:
        entry.replied_at = utcnow()
    if note:
        entry.internal_note = note.strip()
    db.session.commit()
    return entry
