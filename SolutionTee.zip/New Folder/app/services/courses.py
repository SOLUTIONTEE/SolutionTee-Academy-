"""Courses: what a student may see, and how far they have got.

The access decision lives in `lesson_access` and nowhere else. A template
may show a padlock, and the curriculum is deliberately visible to
everyone - somebody deciding whether to pay should be able to see what
they would get - but the *content* is served only after this function
says so. Hiding a link is not access control.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.base import utcnow
from app.models.courses import Course, Lesson, LessonProgress, Module
from app.models.payments import Enrolment, EnrolmentStatus
from app.services import payments

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Access
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Access:
    """Whether a lesson may be opened, and why not if it may not."""

    allowed: bool
    reason: str = ""
    message: str = ""

    #: True when the answer would change if they paid. Lets the page
    #: offer the right next step rather than a flat refusal.
    payable: bool = False


def enrolment_for(user, course: Course) -> Enrolment | None:
    """The user's enrolment on whatever this course belongs to."""
    if course.offering_id is None or user is None:
        return None
    if not getattr(user, "is_authenticated", False):
        return None

    return db.session.scalar(
        select(Enrolment).where(Enrolment.user_id == user.id,
                                Enrolment.offering_id == course.offering_id)
    )


def lesson_access(user, lesson: Lesson) -> Access:
    """The single decision about whether this lesson may be read.

    Called by every route that serves lesson content, including the
    media it references. Nothing else is permitted to decide.
    """
    course = lesson.module.course

    if not lesson.is_published or not course.is_published:
        # Unpublished material is invisible to students regardless of
        # payment. Staff preview it through the admin, not through here.
        return Access(False, "unpublished",
                      "This lesson is not available yet.")

    if lesson.is_preview:
        # A deliberate free sample: readable by anyone, signed in or not.
        return Access(True, "preview")

    if course.offering_id is None:
        # Nothing sells this course, so nothing gates it.
        return Access(True, "free")

    if user is None or not getattr(user, "is_authenticated", False):
        return Access(False, "anonymous",
                      "Sign in to open this lesson.", payable=True)

    enrolment = enrolment_for(user, course)
    if enrolment is None:
        return Access(False, "not_enrolled",
                      "Enrol on this programme to open the lessons.",
                      payable=True)

    if enrolment.status == EnrolmentStatus.CANCELLED:
        return Access(False, "cancelled",
                      "This enrolment was cancelled.")

    if not payments.has_access(enrolment):
        balance = payments.balance_for(enrolment)
        return Access(
            False, "unpaid",
            f"Your first payment opens this course. "
            f"₦{balance.naira(balance.outstanding_kobo)} is outstanding.",
            payable=True,
        )

    return Access(True, "enrolled")


def course_access(user, course: Course) -> Access:
    """Whether the paid body of a course is open.

    Distinct from `lesson_access`, which also considers preview lessons:
    a course whose only open lesson is a free sample is not "open".
    """
    if not course.is_published:
        return Access(False, "unpublished", "This course is not available yet.")
    if course.offering_id is None:
        return Access(True, "free")

    if user is None or not getattr(user, "is_authenticated", False):
        return Access(False, "anonymous", "Sign in to open this course.",
                      payable=True)

    enrolment = enrolment_for(user, course)
    if enrolment is None:
        return Access(False, "not_enrolled",
                      "Enrol to open this course.", payable=True)
    if not payments.has_access(enrolment):
        return Access(False, "unpaid",
                      "Your first payment opens this course.", payable=True)
    return Access(True, "enrolled")


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def published_courses(*, programme_slug: str = "") -> list[Course]:
    statement = (
        select(Course)
        .where(Course.is_published.is_(True))
        .order_by(Course.position, Course.title)
    )
    if programme_slug:
        statement = statement.where(Course.programme_slug == programme_slug)
    return list(db.session.scalars(statement))


def get_course(slug: str) -> Course | None:
    """One course with its whole curriculum, in a single round trip.

    selectinload rather than lazy loading: rendering a curriculum touches
    every module and every lesson, which lazily would be one query per
    module plus one per lesson.
    """
    return db.session.scalar(
        select(Course)
        .options(selectinload(Course.modules).selectinload(Module.lessons))
        .where(Course.slug == slug)
    )


def get_lesson(course: Course, lesson_slug: str) -> Lesson | None:
    """A lesson, but only from within this course.

    Looking it up by slug alone would let a lesson from a course the
    student has paid for be reached through the URL of one they have not.
    """
    for module in course.modules:
        for lesson in module.lessons:
            if lesson.slug == lesson_slug:
                return lesson
    return None


def adjacent_lessons(course: Course, lesson: Lesson
                     ) -> tuple[Lesson | None, Lesson | None]:
    """The previous and next published lessons, flattened across modules."""
    ordered = [
        item
        for module in sorted(course.modules, key=lambda m: m.position)
        for item in sorted(module.lessons, key=lambda x: x.position)
        if item.is_published
    ]
    try:
        index = ordered.index(lesson)
    except ValueError:
        return None, None

    previous = ordered[index - 1] if index > 0 else None
    following = ordered[index + 1] if index + 1 < len(ordered) else None
    return previous, following


# ---------------------------------------------------------------------------
# Progress
# ---------------------------------------------------------------------------

def progress_map(user, course: Course) -> dict[int, LessonProgress]:
    """Progress for this course, keyed by lesson id.

    One query for the whole curriculum rather than one per lesson, which
    is what a naive template loop would produce.
    """
    if user is None or not getattr(user, "is_authenticated", False):
        return {}

    lesson_ids = [lesson.id
                  for module in course.modules
                  for lesson in module.lessons]
    if not lesson_ids:
        return {}

    rows = db.session.scalars(
        select(LessonProgress).where(
            LessonProgress.user_id == user.id,
            LessonProgress.lesson_id.in_(lesson_ids),
        )
    ).all()
    return {row.lesson_id: row for row in rows}


def mark_started(user, lesson: Lesson) -> LessonProgress | None:
    """Record that a lesson was opened. Idempotent."""
    if user is None or not getattr(user, "is_authenticated", False):
        return None

    existing = db.session.scalar(
        select(LessonProgress).where(LessonProgress.user_id == user.id,
                                     LessonProgress.lesson_id == lesson.id)
    )
    if existing is not None:
        return existing

    progress = LessonProgress(user_id=user.id, lesson_id=lesson.id,
                              started_at=utcnow())
    db.session.add(progress)
    db.session.commit()
    return progress


def mark_complete(user, lesson: Lesson) -> LessonProgress | None:
    """Mark a lesson finished.

    Only ever set once: re-completing must not move the timestamp, or a
    student revisiting an old lesson would look like they had just
    finished it.
    """
    progress = mark_started(user, lesson)
    if progress is None:
        return None
    if progress.completed_at is None:
        progress.completed_at = utcnow()
        db.session.commit()
    return progress


@dataclass(frozen=True)
class CourseProgress:
    total: int
    completed: int

    @property
    def percent(self) -> int:
        if self.total == 0:
            return 0
        return round((self.completed / self.total) * 100)

    @property
    def is_complete(self) -> bool:
        return self.total > 0 and self.completed == self.total


def course_progress(user, course: Course) -> CourseProgress:
    """How far through a course a student is, counting published lessons."""
    published = [lesson
                 for module in course.modules
                 for lesson in module.lessons
                 if lesson.is_published]
    if not published or user is None or not getattr(user, "is_authenticated",
                                                    False):
        return CourseProgress(total=len(published), completed=0)

    completed = db.session.scalar(
        select(func.count())
        .select_from(LessonProgress)
        .where(LessonProgress.user_id == user.id,
               LessonProgress.completed_at.is_not(None),
               LessonProgress.lesson_id.in_([l.id for l in published]))
    ) or 0

    return CourseProgress(total=len(published), completed=int(completed))
