"""The administrator's overview.

Everything here is a count of real rows or a list of real work. There are
no trend lines, no percentage-change-on-last-month, and no tiles that
exist to fill a grid: this page is read by somebody deciding what to do
in the next ten minutes, and a number they cannot act on is noise.

The order is deliberate. What needs a person comes first; what merely
describes the academy comes last. A console that opens on totals makes
the reader hunt for the one thing that is actually waiting.

Counts are done in the database with count(), not by loading rows and
calling len() on them. The difference does not show on a development
database with four articles in it, and shows very clearly later.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.base import utcnow
from app.models.cbt import Attempt, AttemptStatus
from app.models.contact import ContactMessage, ContactStatus
from app.models.courses import Course
from app.models.editorial import Article, ArticleStatus
from app.models.enums import RoleName
from app.models.media import Media
from app.models.payments import (
    Enrolment, EnrolmentStatus, Payment, PaymentStatus,
)
from app.models.rbac import Role
from app.models.security import LoginAttempt
from app.models.user import User
from app.services import editorial
from app.services.payments import ledger

logger = logging.getLogger(__name__)

#: An article older than this without a review is flagged. Matches the
#: editorial service's own definition so the console and the editor cannot
#: disagree about what "overdue" means.
REVIEW_AFTER_DAYS = 365


@dataclass
class Task:
    """One piece of outstanding work.

    `url` is empty when the console that would handle it does not exist
    yet. The task is still reported - an administrator needs to know
    there are twelve unanswered messages whether or not there is a screen
    for them - but it is rendered as a statement rather than a link.
    Sending somebody to the Articles list under a heading that says
    "Unanswered messages" would be worse than sending them nowhere.
    """

    label: str
    detail: str
    url: str = ""
    count: int = 0
    urgency: str = "normal"          # "urgent" | "normal"

    @property
    def is_actionable(self) -> bool:
        return bool(self.url)


@dataclass
class Overview:
    tasks: list[Task] = field(default_factory=list)

    students: int = 0
    staff: int = 0
    active_enrolments: int = 0
    overdue_enrolments: int = 0

    articles_live: int = 0
    articles_draft: int = 0
    media_items: int = 0
    courses_live: int = 0
    courses_draft: int = 0

    #: Money, in kobo. Never a float - see the payments service.
    revenue_kobo: int = 0
    revenue_30d_kobo: int = 0
    outstanding_kobo: int = 0

    papers_sat: int = 0
    failed_logins_7d: int = 0

    recent_attempts: list = field(default_factory=list)

    @property
    def has_tasks(self) -> bool:
        return bool(self.tasks)


def _count(statement) -> int:
    return db.session.scalar(statement) or 0


def _role_count(role_names) -> int:
    return _count(
        select(func.count(func.distinct(User.id)))
        .join(User.roles)
        .where(Role.name.in_(role_names))
    )


def build() -> Overview:
    overview = Overview()

    # ---- What needs somebody -------------------------------------------
    new_messages = _count(
        select(func.count(ContactMessage.id))
        .where(ContactMessage.status == ContactStatus.NEW)
    )
    if new_messages:
        overview.tasks.append(Task(
            label="Unanswered messages",
            detail="Somebody used the contact form and has had no reply. "
                   "They are stored and also forwarded to the contact "
                   "inbox; the console for them is not built yet.",
            count=new_messages,
            urgency="urgent",
        ))

    overdue = _count(
        select(func.count(Enrolment.id))
        .where(Enrolment.status == EnrolmentStatus.OVERDUE)
    )
    overview.overdue_enrolments = overdue
    if overdue:
        overview.tasks.append(Task(
            label="Overdue payments",
            detail="Enrolments past their agreed instalment date. "
                   "The payments console is not built yet.",
            count=overdue,
            urgency="urgent",
        ))

    stale_before = utcnow() - timedelta(days=REVIEW_AFTER_DAYS)
    stale = _count(
        select(func.count(Article.id)).where(
            Article.status == ArticleStatus.PUBLISHED,
            Article.last_reviewed_at < stale_before,
        )
    )
    if stale:
        overview.tasks.append(Task(
            label="Articles due a check",
            detail="Published over a year ago and not confirmed since. "
                   "Anything time-sensitive in them may now be wrong.",
            url="/admin/articles/",
            count=stale,
        ))

    drafts = _count(
        select(func.count(Article.id))
        .where(Article.status == ArticleStatus.DRAFT)
    )
    if drafts:
        overview.tasks.append(Task(
            label="Articles in draft",
            detail="Written but not published.",
            url="/admin/articles/?status=draft",
            count=drafts,
        ))

    # ---- What the academy looks like ------------------------------------
    overview.students = _role_count([RoleName.STUDENT])
    overview.staff = _role_count(list(RoleName.STAFF_ONLY))
    overview.active_enrolments = _count(
        select(func.count(Enrolment.id))
        .where(Enrolment.status == EnrolmentStatus.ACTIVE)
    )

    overview.articles_live = _count(
        select(func.count(Article.id))
        .where(Article.status.in_(list(editorial.LIVE_STATUSES)))
    )
    overview.articles_draft = drafts
    overview.media_items = _count(select(func.count(Media.id)))
    overview.courses_live = _count(
        select(func.count(Course.id)).where(Course.is_published.is_(True))
    )
    overview.courses_draft = _count(
        select(func.count(Course.id)).where(Course.is_published.is_(False))
    )

    # ---- Money ----------------------------------------------------------
    # Only settled payments count as revenue. A pending row is a reference
    # handed to the gateway, not money received, and reporting it as
    # income is how a dashboard starts lying.
    overview.revenue_kobo = _count(
        select(func.coalesce(func.sum(Payment.paid_amount_kobo), 0))
        .where(Payment.status == PaymentStatus.SUCCESS)
    )
    overview.revenue_30d_kobo = _count(
        select(func.coalesce(func.sum(Payment.paid_amount_kobo), 0))
        .where(Payment.status == PaymentStatus.SUCCESS,
               Payment.verified_at >= utcnow() - timedelta(days=30))
    )

    # Outstanding is derived per enrolment by the ledger, which applies
    # discounts, waivers and write-offs. Summing agreed prices here
    # instead would report money that has been formally written off.
    overview.outstanding_kobo = sum(
        ledger.balance_for(enrolment).outstanding_kobo
        for enrolment in db.session.scalars(
            select(Enrolment).where(
                Enrolment.status.in_([EnrolmentStatus.ACTIVE,
                                      EnrolmentStatus.OVERDUE])
            )
        )
    )

    overview.papers_sat = _count(
        select(func.count(Attempt.id))
        .where(Attempt.status == AttemptStatus.SUBMITTED)
    )
    overview.failed_logins_7d = _count(
        select(func.count(LoginAttempt.id)).where(
            LoginAttempt.successful.is_(False),
            LoginAttempt.created_at >= utcnow() - timedelta(days=7),
        )
    )

    overview.recent_attempts = list(
        db.session.scalars(
            select(Attempt)
            .options(selectinload(Attempt.user), selectinload(Attempt.exam))
            .where(Attempt.status == AttemptStatus.SUBMITTED)
            .order_by(Attempt.submitted_at.desc())
            .limit(8)
        )
    )

    return overview
