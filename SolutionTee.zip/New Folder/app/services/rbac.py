"""Role-based access control.

The authorisation decision lives here and nowhere else. A template may
hide a control the user cannot use, but hiding is presentation - it is
never the thing that stops the request. Every protected view calls
`require_permission`, which raises 403 rather than returning a boolean a
caller could forget to check.
"""
from __future__ import annotations

import logging
from functools import wraps

from flask import abort, jsonify, redirect, request, url_for
from flask_login import current_user
from sqlalchemy import select

from app.extensions import db
from app.models.enums import AccountStatus, RoleName
from app.models.rbac import Permission, Role

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# The permission catalogue
#
# Dotted names, grouped by the area they govern. Adding a permission here
# and granting it to a role is the whole of adding a capability.
# ---------------------------------------------------------------------------

PERMISSIONS: dict[str, str] = {
    "media.view": "See the media library",
    "media.upload": "Upload new media",
    "media.edit": "Edit media metadata and folders",
    "media.delete": "Archive media, and permanently delete unused media",
    "media.force_delete": "Delete media that published content still uses",

    "users.view": "See user accounts",
    "users.manage": "Create, suspend and restore accounts",
    "roles.manage": "Assign roles and permissions",

    "content.edit": "Edit website content",
    "content.publish": "Publish content to the public site",

    "payments.view": "See payments and the ledger",
    "payments.manage": "Adjust payment plans and record adjustments",
    "payments.adjust": "Discount, waive or write off a fee",

    # Teaching. Scoped by ownership rather than by permission: holding
    # teaching.view does not let somebody see every student in the
    # academy, only the ones enrolled on courses they teach. The service
    # layer enforces that; the permission only decides who gets a
    # workspace at all.
    "teaching.view": "See your own courses, students and their progress",
    "teaching.manage": "Build and edit the courses you teach",
    "teaching.publish": "Publish a course to students",
}

#: Which permissions each role carries by default. A user may also hold
#: direct grants that no role gave them.
ROLE_PERMISSIONS: dict[str, tuple[str, ...]] = {
    RoleName.SUPER_ADMIN: tuple(PERMISSIONS),
    RoleName.ADMIN: (
        "media.view", "media.upload", "media.edit", "media.delete",
        "users.view", "users.manage",
        "content.edit", "content.publish",
        "payments.view", "payments.manage",
        "teaching.view", "teaching.manage", "teaching.publish",
    ),
    RoleName.EMPLOYEE: (
        "media.view", "media.upload", "media.edit",
        "content.edit",
        "teaching.view", "teaching.manage",
    ),
    RoleName.INSTRUCTOR: (
        "media.view", "media.upload",
        "teaching.view", "teaching.manage",
    ),
    RoleName.STUDENT: (),
    RoleName.PARENT: (),
}

ROLE_LABELS: dict[str, str] = {
    RoleName.SUPER_ADMIN: "Super administrator",
    RoleName.ADMIN: "Administrator",
    RoleName.EMPLOYEE: "Employee",
    RoleName.INSTRUCTOR: "Instructor",
    RoleName.STUDENT: "Student",
    RoleName.PARENT: "Parent",
}


# ---------------------------------------------------------------------------
# Checking
# ---------------------------------------------------------------------------

def permissions_for(user) -> frozenset[str]:
    """Every permission a user holds, from roles plus direct grants."""
    if user is None or not getattr(user, "is_authenticated", False):
        return frozenset()
    # A suspended account keeps its roles but exercises none of them.
    if getattr(user, "status", None) != AccountStatus.ACTIVE:
        return frozenset()

    names: set[str] = set()
    for role in user.roles:
        # super_admin is defined as holding everything, so a permission
        # added later does not need a migration to reach them.
        if role.name == RoleName.SUPER_ADMIN:
            return frozenset(PERMISSIONS)
        names.update(permission.name for permission in role.permissions)

    names.update(permission.name for permission in user.extra_permissions)
    return frozenset(names)


def has_permission(user, permission: str) -> bool:
    return permission in permissions_for(user)


#: Where a signed-in person belongs, in order of privilege. The first
#: entry whose permission the user holds wins.
#:
#: This exists because "your account" is not one page. An administrator
#: signing in and landing on the student portal - a dashboard about
#: enrolments and practice papers they do not have - reads as though the
#: console does not exist. Staff belong in the console; a tutor who is not
#: an administrator belongs in their workspace; everyone else belongs in
#: the portal.
LANDING_BY_PERMISSION: tuple[tuple[str, str], ...] = (
    # Run the academy: the console.
    ("users.view", "admin_overview.index"),
    ("content.publish", "admin_overview.index"),
    # Teach in it: your own workspace. This sits ABOVE media.view on
    # purpose - an instructor holds media.view too, and landing them in
    # the console would put a tutor on a page of totals rather than on
    # their own students.
    ("teaching.view", "teaching.workspace"),
    # Any other staff permission still means the console rather than a
    # student portal they have no enrolments in.
    ("media.view", "admin_overview.index"),
    ("content.edit", "admin_overview.index"),
)


def landing_endpoint(user) -> str:
    """The endpoint this user's "home" means."""
    held = permissions_for(user)
    for permission, endpoint in LANDING_BY_PERMISSION:
        if permission in held:
            return endpoint
    return "portal.dashboard"


def require_permission(permission: str):
    """Decorator enforcing one permission.

    An anonymous visitor is sent to sign in (or given a 401 if the caller
    is a script); a signed-in user who lacks the permission gets 403.
    Distinguishing the two matters: showing "please sign in" to somebody
    who already is sends them round a loop they cannot escape.
    """
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            # Deliberately not getattr(..., False): that swallows any
            # AttributeError raised while loading the user and turns a
            # real fault into a silent "unauthorised", which is both
            # wrong and very hard to diagnose.
            if not current_user.is_authenticated:
                return _unauthenticated()
            if not has_permission(current_user, permission):
                logger.warning(
                    "Denied %s to user %s", permission,
                    getattr(current_user, "public_id", "?"),
                )
                abort(403)
            return view(*args, **kwargs)
        return wrapper
    return decorator


def _wants_json() -> bool:
    """True when the caller is a script rather than a browsing person.

    The upload endpoint is called by fetch/XHR, and answering it with a
    redirect to an HTML login page produces a confusing parse error
    rather than a usable status.
    """
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return True
    accept = request.accept_mimetypes
    return (accept.best == "application/json"
            or (accept["application/json"] >= accept["text/html"]
                and accept["application/json"] > 0))


def _unauthenticated():
    """Send a person to sign in; tell a script it is unauthenticated."""
    if _wants_json():
        return jsonify({"ok": False, "error": "Sign in to continue."}), 401
    return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))


# ---------------------------------------------------------------------------
# Seeding
# ---------------------------------------------------------------------------

def sync_roles_and_permissions() -> dict[str, int]:
    """Make the database match the catalogue above.

    Additive by design: it creates what is missing and grants what is
    declared. It does not delete a permission that has disappeared from
    the catalogue, because a stray revoke during a deploy is a far worse
    failure than a stale row.
    """
    created_permissions = 0
    existing = {
        p.name: p for p in db.session.scalars(select(Permission))
    }
    for name, description in PERMISSIONS.items():
        permission = existing.get(name)
        if permission is None:
            permission = Permission(name=name, description=description)
            db.session.add(permission)
            existing[name] = permission
            created_permissions += 1
        elif not permission.description:
            permission.description = description

    db.session.flush()

    created_roles = 0
    roles = {r.name: r for r in db.session.scalars(select(Role))}
    for role_name, permission_names in ROLE_PERMISSIONS.items():
        role = roles.get(role_name)
        if role is None:
            role = Role(name=role_name, label=ROLE_LABELS.get(role_name, ""))
            db.session.add(role)
            roles[role_name] = role
            created_roles += 1

        held = {p.name for p in role.permissions}
        for permission_name in permission_names:
            if permission_name not in held:
                role.permissions.append(existing[permission_name])

    db.session.commit()
    return {"permissions_created": created_permissions,
            "roles_created": created_roles}
