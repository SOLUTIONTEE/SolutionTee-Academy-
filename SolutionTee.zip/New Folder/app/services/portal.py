"""What a student sees when they sign in.

The dashboard answers four questions in the order a student actually has
them: what do I owe, what should I do next, how am I doing, and what is
new. Everything on it is either actionable or a real number — there are
no decorative statistics, because a dashboard that mostly displays itself
is one nobody reads twice.

Assembled here rather than by the template. A page that lazily walks
relationships turns into thirty queries without anybody noticing.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.cbt import Attempt, AttemptStatus
from app.models.courses import Course, LessonProgress
from app.models.payments import Enrolment, EnrolmentStatus
from app.services import courses as course_service
from app.services import editorial, payments

logger = logging.getLogger(__name__)


@dataclass
class NextStep:
    """One thing worth doing, with the reason it is worth doing."""

    label: str
    detail: str
    url: str
    urgency: str = "normal"     # "urgent" | "normal"


@dataclass
class Dashboard:
    enrolments: list = field(default_factory=list)
    outstanding_kobo: int = 0
    next_steps: list[NextStep] = field(default_factory=list)
    courses: list = field(default_factory=list)
    recent_attempts: list = field(default_factory=list)
    weakest_topics: list = field(default_factory=list)
    updates: list = field(default_factory=list)

    @property
    def has_anything(self) -> bool:
        return bool(self.enrolments or self.recent_attempts)


def build(user) -> Dashboard:
    """Assemble everything the dashboard shows."""
    board = Dashboard()

    board.enrolments = list(db.session.scalars(
        select(Enrolment)
        .options(selectinload(Enrolment.offering),
                 selectinload(Enrolment.payments))
        .where(Enrolment.user_id == user.id,
               Enrolment.status != EnrolmentStatus.CANCELLED)
        .order_by(Enrolment.created_at.desc())
    ))

    for enrolment in board.enrolments:
        balance = payments.balance_for(enrolment)
        board.outstanding_kobo += max(0, balance.outstanding_kobo)

        if balance.outstanding_kobo > 0:
            # Money first: it is the thing that blocks everything else.
            has_access = payments.has_access(enrolment)
            board.next_steps.append(NextStep(
                label=("Pay to open your course" if not has_access
                       else "Pay your balance"),
                detail=(
                    f"{balance.naira(balance.outstanding_kobo)} outstanding "
                    f"on {enrolment.offering.title}."
                ),
                url=f"/enrolments/{enrolment.public_id}",
                urgency="urgent" if not has_access else "normal",
            ))

    # Only courses the student can actually open, with real progress.
    open_offerings = {
        enrolment.offering_id for enrolment in board.enrolments
        if payments.has_access(enrolment)
    }
    if open_offerings:
        found = db.session.scalars(
            select(Course)
            .options(selectinload(Course.modules))
            .where(Course.offering_id.in_(open_offerings),
                   Course.is_published.is_(True))
        ).all()
        for course in found:
            progress = course_service.course_progress(user, course)
            board.courses.append((course, progress))

            if not progress.is_complete:
                following = _next_lesson(user, course)
                if following is not None:
                    board.next_steps.append(NextStep(
                        label=(f"Continue {course.title}" if progress.completed
                               else f"Start {course.title}"),
                        detail=f"Next: {following.title}",
                        url=f"/academy/{course.slug}/{following.slug}",
                    ))

    board.recent_attempts = list(db.session.scalars(
        select(Attempt)
        .options(selectinload(Attempt.exam))
        .where(Attempt.user_id == user.id,
               Attempt.status != AttemptStatus.IN_PROGRESS)
        .order_by(Attempt.started_at.desc())
        .limit(5)
    ))
    board.weakest_topics = _weakest_topics(board.recent_attempts)

    unfinished = db.session.scalar(
        select(Attempt)
        .options(selectinload(Attempt.exam))
        .where(Attempt.user_id == user.id,
               Attempt.status == AttemptStatus.IN_PROGRESS)
        .order_by(Attempt.started_at.desc())
    )
    if unfinished is not None:
        # A paper with a running clock outranks everything else here.
        board.next_steps.insert(0, NextStep(
            label="Finish your paper",
            detail=f"{unfinished.exam.title} is still open and timed.",
            url=f"/cbt/attempt/{unfinished.public_id}",
            urgency="urgent",
        ))

    board.updates = editorial.published(limit=3)
    return board


def _next_lesson(user, course: Course):
    """The first published lesson the student has not completed."""
    done = {
        row.lesson_id for row in db.session.scalars(
            select(LessonProgress).where(
                LessonProgress.user_id == user.id,
                LessonProgress.completed_at.is_not(None),
            )
        )
    }
    for module in sorted(course.modules, key=lambda m: m.position):
        for lesson in sorted(module.lessons, key=lambda item: item.position):
            if lesson.is_published and lesson.id not in done:
                return lesson
    return None


def _weakest_topics(attempts, *, limit: int = 4):
    """Topics scoring worst across recent papers.

    Aggregated across attempts rather than shown per paper: one bad score
    is noise, the same topic failing three times is a finding.
    """
    totals: dict[str, list[int]] = {}
    for attempt in attempts:
        for topic, data in (attempt.topic_breakdown or {}).items():
            bucket = totals.setdefault(topic, [0, 0])
            bucket[0] += data.get("correct", 0)
            bucket[1] += data.get("total", 0)

    rows = [
        {"topic": topic, "correct": correct, "total": total,
         "percent": round(correct / total * 100) if total else 0}
        for topic, (correct, total) in totals.items() if total
    ]
    rows.sort(key=lambda row: (row["percent"], -row["total"]))
    return rows[:limit]
