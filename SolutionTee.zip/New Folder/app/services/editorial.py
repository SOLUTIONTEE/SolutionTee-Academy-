"""The Education Information Centre.

Publication is derived, not flagged. `is_live` asks whether the article
was meant to go out AND whether `published_at` has actually arrived.
Because an arrived scheduled piece counts, scheduling needs nothing
running in the background: there is no window where a story is late
because a job was.

Reading time and the table of contents are computed from the body rather
than typed by an editor: a hand-entered "5 min read" is wrong the moment
a paragraph is added, and a hand-maintained contents list drifts from the
headings it describes.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from sqlalchemy import func, or_, select
from sqlalchemy.orm import selectinload

from app.extensions import db
from app.models.base import as_utc, slugify, utcnow
from app.models.editorial import (
    Article, ArticleRevision, ArticleStatus, Category, Tag,
)

logger = logging.getLogger(__name__)

#: Average adult reading speed for informational prose, in words per
#: minute. Deliberately conservative: over-promising "2 min" on something
#: that takes five is a small lie that annoys people.
WORDS_PER_MINUTE = 200

#: Guidance about examinations ages badly. Past this, the article says so
#: rather than presenting itself with the same confidence as last week's.
REVIEW_DUE_DAYS = 180


class EditorialError(RuntimeError):
    """Something the editor should be told about."""


# ---------------------------------------------------------------------------
# Visibility
# ---------------------------------------------------------------------------

#: A scheduled article whose moment has arrived is published in every
#: sense that matters to a reader. Including it here is what lets
#: scheduling work with nothing running in the background: the label is
#: tidied later by promote_scheduled, but visibility never waits for it.
LIVE_STATUSES = (ArticleStatus.PUBLISHED, ArticleStatus.SCHEDULED)


def is_live(article: Article, *, now: datetime | None = None) -> bool:
    """Whether the public may see this.

    Both halves matter. A future `published_at` is not yet live whatever
    the status says; and a draft or archived piece stays hidden even if
    its date has passed, because somebody deliberately took it down.
    """
    if article.status not in LIVE_STATUSES:
        return False
    if article.published_at is None:
        return False
    return as_utc(article.published_at) <= (now or utcnow())


def _live_filter():
    """The same rule, as SQL, so listings do not load then discard."""
    return (Article.status.in_(LIVE_STATUSES),
            Article.published_at.is_not(None),
            Article.published_at <= utcnow())


# ---------------------------------------------------------------------------
# Derived reading aids
# ---------------------------------------------------------------------------

_TAG_RE = re.compile(r"<[^>]+>")
_HEADING_RE = re.compile(
    r"<h([23])(?P<attrs>[^>]*)>(?P<text>.*?)</h\1>", re.I | re.S
)


def plain_text(html: str) -> str:
    return _TAG_RE.sub(" ", html or "")


def word_count(article: Article) -> int:
    return len(plain_text(article.body_html).split())


def reading_minutes(article: Article) -> int:
    """Always at least one minute: "0 min read" is not a useful claim."""
    return max(1, round(word_count(article) / WORDS_PER_MINUTE))


@dataclass(frozen=True)
class Heading:
    level: int
    text: str
    anchor: str


def outline(article: Article) -> list[Heading]:
    """The h2s and h3s in the body, in order.

    Derived rather than maintained by hand so the contents list cannot
    drift from the headings it describes.
    """
    headings: list[Heading] = []
    seen: dict[str, int] = {}

    for match in _HEADING_RE.finditer(article.body_html or ""):
        text = " ".join(plain_text(match.group("text")).split())
        if not text:
            continue
        base = slugify(text, max_length=60)
        # Two sections called "Requirements" must not share an anchor.
        seen[base] = seen.get(base, 0) + 1
        anchor = base if seen[base] == 1 else f"{base}-{seen[base]}"
        headings.append(Heading(level=int(match.group(1)), text=text,
                                anchor=anchor))
    return headings


def body_with_anchors(article: Article) -> str:
    """The body with an id on every heading, matching `outline`.

    Added at render time rather than stored: the stored HTML stays exactly
    what the editor wrote and sanitisation approved, and the anchors
    cannot fall out of step with the outline because both come from the
    same pass.
    """
    seen: dict[str, int] = {}

    def add_id(match: re.Match) -> str:
        level = match.group(1)
        attrs = match.group("attrs") or ""
        inner = match.group("text")
        text = " ".join(plain_text(inner).split())
        if not text or "id=" in attrs:
            return match.group(0)
        base = slugify(text, max_length=60)
        seen[base] = seen.get(base, 0) + 1
        anchor = base if seen[base] == 1 else f"{base}-{seen[base]}"
        return f'<h{level}{attrs} id="{anchor}">{inner}</h{level}>'

    return _HEADING_RE.sub(add_id, article.body_html or "")


@dataclass(frozen=True)
class ReviewState:
    """How much a reader should trust the date on this."""

    days_ago: int | None
    is_due: bool
    message: str


def review_state(article: Article) -> ReviewState:
    reviewed = article.last_reviewed_at or article.published_at
    if reviewed is None:
        return ReviewState(None, False, "")

    days = (utcnow() - as_utc(reviewed)).days
    if days <= REVIEW_DUE_DAYS:
        return ReviewState(days, False, "")

    return ReviewState(
        days, True,
        f"This was last checked {days // 30} months ago. Examination rules "
        f"and dates change — confirm anything time-sensitive against the "
        f"official source before you act on it.",
    )


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------

def _base_query():
    return (
        select(Article)
        .options(selectinload(Article.category), selectinload(Article.tags))
        .where(*_live_filter())
        .order_by(Article.published_at.desc())
    )


@dataclass
class Front:
    """The section front, arranged rather than listed.

    A lead, a few seconds, then the rest as a dated list. Six identical
    cards would tell a reader nothing about what matters most, which is
    the entire job of a front page.
    """

    lead: Article | None = None
    secondary: list[Article] = field(default_factory=list)
    latest: list[Article] = field(default_factory=list)


def front_page(*, secondary: int = 2, latest: int = 8) -> Front:
    """Assemble the centre's front.

    A featured article takes the lead if there is one; otherwise the
    newest does. Nothing appears twice.
    """
    articles = list(db.session.scalars(_base_query().limit(
        1 + secondary + latest
    )))
    if not articles:
        return Front()

    lead = next((item for item in articles if item.is_featured), articles[0])
    rest = [item for item in articles if item.id != lead.id]

    return Front(
        lead=lead,
        secondary=rest[:secondary],
        latest=rest[secondary:secondary + latest],
    )


def published(*, category_slug: str = "", tag_slug: str = "",
              query: str = "", limit: int | None = None) -> list[Article]:
    statement = _base_query()

    if category_slug:
        statement = statement.join(Category).where(
            Category.slug == category_slug
        )
    if tag_slug:
        statement = statement.join(Article.tags).where(Tag.slug == tag_slug)

    term = (query or "").strip()
    if term:
        pattern = f"%{term}%"
        statement = statement.where(or_(
            Article.title.ilike(pattern),
            Article.dek.ilike(pattern),
        ))

    if limit:
        statement = statement.limit(limit)
    return list(db.session.scalars(statement))


def get_published(slug: str) -> Article | None:
    """One live article by slug.

    Returns None for a draft or a scheduled piece, so a leaked URL shows
    a 404 rather than tomorrow's story.
    """
    article = db.session.scalar(
        select(Article)
        .options(selectinload(Article.category), selectinload(Article.tags))
        .where(Article.slug == slug)
    )
    if article is None or not is_live(article):
        return None
    return article


def related(article: Article, *, limit: int = 3) -> list[Article]:
    """Other live pieces in the same section."""
    if article.category_id is None:
        return []
    return list(db.session.scalars(
        _base_query()
        .where(Article.category_id == article.category_id,
               Article.id != article.id)
        .limit(limit)
    ))


def live_categories() -> list[tuple[Category, int]]:
    """Sections that actually have something in them, with counts.

    One grouped query rather than a count per section.
    """
    rows = db.session.execute(
        select(Category, func.count(Article.id))
        .join(Article, Article.category_id == Category.id)
        .where(Category.is_published.is_(True), *_live_filter())
        .group_by(Category.id)
        .order_by(Category.position, Category.name)
    ).all()
    return [(category, count) for category, count in rows]


# ---------------------------------------------------------------------------
# The publishing workflow
# ---------------------------------------------------------------------------

def snapshot(article: Article, *, actor=None, note: str = "") -> ArticleRevision:
    """Keep the article as it stands before it is changed."""
    revision = ArticleRevision(
        article_id=article.id, title=article.title, dek=article.dek,
        body_html=article.body_html,
        saved_by_id=getattr(actor, "id", None),
        note=note[:200], created_at=utcnow(),
    )
    db.session.add(revision)
    return revision


def save_draft(article: Article, *, title: str, dek: str, body_html: str,
               actor=None, note: str = "") -> Article:
    """Update the content, keeping what it replaced.

    `content_updated_at` moves only when the body actually changes, so a
    metadata tweak does not tell every reader the guidance was revised.
    """
    from app.services.content import sanitise_html

    cleaned = sanitise_html(body_html)
    body_changed = cleaned != article.body_html

    if article.id is not None:
        snapshot(article, actor=actor, note=note)

    article.title = title.strip()[:200]
    article.dek = dek.strip()
    article.body_html = cleaned
    if body_changed:
        article.content_updated_at = utcnow()

    db.session.commit()
    return article


def publish(article: Article, *, actor=None,
            when: datetime | None = None) -> Article:
    """Publish now, or schedule for later.

    A future `when` leaves the article invisible until that moment
    without anything needing to run: visibility is derived from the pair
    on every read.
    """
    if not article.title.strip():
        raise EditorialError("An article needs a headline before it can go out.")
    if not article.body_html.strip():
        raise EditorialError("An article needs a body before it can go out.")

    moment = when or utcnow()
    article.published_at = moment
    article.status = (ArticleStatus.SCHEDULED if moment > utcnow()
                      else ArticleStatus.PUBLISHED)
    article.editor_id = getattr(actor, "id", None) or article.editor_id
    if article.last_reviewed_at is None:
        # Going out is itself a review: somebody signed it off.
        article.last_reviewed_at = moment

    db.session.commit()
    logger.info("Article %s %s for %s", article.slug, article.status, moment)
    return article


def unpublish(article: Article, *, actor=None) -> Article:
    """Back to draft, and immediately invisible."""
    article.status = ArticleStatus.DRAFT
    db.session.commit()
    logger.info("Article %s unpublished by %s", article.slug,
                getattr(actor, "public_id", "?"))
    return article


def archive(article: Article) -> Article:
    article.status = ArticleStatus.ARCHIVED
    db.session.commit()
    return article


def mark_reviewed(article: Article, *, actor=None) -> Article:
    """Record that somebody checked this is still true.

    Deliberately its own action rather than a side effect of saving:
    fixing a typo is not the same claim as confirming a deadline.
    """
    article.last_reviewed_at = utcnow()
    article.editor_id = getattr(actor, "id", None) or article.editor_id
    db.session.commit()
    return article


def restore(article: Article, revision: ArticleRevision, *,
            actor=None) -> Article:
    """Put a previous version back, keeping the one being replaced."""
    if revision.article_id != article.id:
        raise EditorialError("That revision belongs to another article.")

    snapshot(article, actor=actor, note="Replaced by a restore")
    article.title = revision.title
    article.dek = revision.dek
    article.body_html = revision.body_html
    article.content_updated_at = utcnow()
    db.session.commit()
    return article


def promote_scheduled(*, now: datetime | None = None) -> int:
    """Move arrived scheduled articles into the published state.

    Housekeeping only. Visibility never depended on this having run -
    `is_live` already treats an arrived scheduled piece as live - so a
    missed run delays a status label, not a publication.
    """
    moment = now or utcnow()
    rows = list(db.session.scalars(
        select(Article).where(Article.status == ArticleStatus.SCHEDULED,
                              Article.published_at.is_not(None),
                              Article.published_at <= moment)
    ))
    for article in rows:
        article.status = ArticleStatus.PUBLISHED
    if rows:
        db.session.commit()
    return len(rows)
