"""Application factory for SolutionTee Edu Academy."""
from __future__ import annotations

import logging
import secrets
from datetime import datetime, timezone

from flask import Flask, g, render_template, request, url_for

from config import get_config
from app.extensions import (
    cache, compress, csrf, db, limiter, login_manager, migrate,
)

logger = logging.getLogger(__name__)

# Self-hosted assets throughout. The only third-party origin is Cloudflare's
# challenge host, which the Turnstile widget on public forms needs.
CSP_DIRECTIVES = {
    "default-src": "'self'",
    "script-src": "'self' https://challenges.cloudflare.com",
    "style-src": "'self'",
    "img-src": "'self' data:",
    "font-src": "'self'",
    "connect-src": "'self'",
    "frame-src": "https://challenges.cloudflare.com",
    "frame-ancestors": "'none'",
    "base-uri": "'self'",
    "form-action": "'self'",
    "object-src": "'none'",
}


def _build_csp(app: Flask, nonce: str) -> str:
    directives = dict(CSP_DIRECTIVES)

    # One inline script is unavoidable: the theme has to be applied before
    # first paint, or a dark-mode visitor gets a white flash on every
    # navigation. It is allowed by a per-request nonce rather than by
    # 'unsafe-inline', which would permit every inline script on the page.
    directives["script-src"] = f"{directives['script-src']} 'nonce-{nonce}'"

    # Media served from R2 loads over its own hostname, so widen img-src
    # only when that hostname is actually configured.
    public_media = (app.config.get("R2_PUBLIC_URL") or "").strip()
    if public_media:
        directives["img-src"] = f"{directives['img-src']} {public_media}"
        directives["media-src"] = f"'self' {public_media}"

    return "; ".join(f"{k} {v}" for k, v in directives.items())


def create_app(config_name: str | None = None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(get_config(config_name))

    logging.basicConfig(
        level=app.config.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    _init_extensions(app)
    _register_blueprints(app)
    _register_error_handlers(app)
    _register_security_headers(app)
    _register_context(app)
    _register_health(app)

    from app.cli import register_cli

    register_cli(app)
    return app


def _init_extensions(app: Flask) -> None:
    # Imported as `from app import models`, not `import app.models`: the
    # latter would rebind the local name `app` from the Flask instance to
    # this package. Registers every table for Alembic autogenerate.
    from app import models as _models  # noqa: F401

    db.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)
    login_manager.init_app(app)
    cache.init_app(app)
    compress.init_app(app)

    if app.config.get("RATELIMIT_ENABLED", True):
        limiter.init_app(app)


def _register_blueprints(app: Flask) -> None:
    from app.blueprints.academy.routes import bp as academy_bp
    from app.blueprints.admissions.routes import bp as admissions_bp
    from app.blueprints.cbt.routes import bp as cbt_bp
    from app.blueprints.editorial.routes import bp as editorial_bp
    from app.blueprints.admin.overview import bp as admin_overview_bp
    from app.blueprints.admin.editorial import bp as admin_editorial_bp
    from app.blueprints.admin.media import bp as admin_media_bp
    from app.blueprints.admin.site_images import bp as admin_site_images_bp
    from app.blueprints.auth.routes import bp as auth_bp
    from app.blueprints.main.routes import bp as main_bp
    from app.blueprints.media_files.routes import bp as media_files_bp
    from app.blueprints.payments.routes import bp as payments_bp
    from app.blueprints.community.routes import bp as community_bp
    from app.blueprints.messages.routes import bp as messages_bp
    from app.blueprints.portal.routes import bp as portal_bp
    from app.blueprints.teaching.routes import bp as teaching_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(academy_bp)
    app.register_blueprint(admissions_bp)
    app.register_blueprint(cbt_bp)
    app.register_blueprint(editorial_bp)
    app.register_blueprint(admin_overview_bp)
    app.register_blueprint(admin_editorial_bp)
    app.register_blueprint(admin_media_bp)
    app.register_blueprint(admin_site_images_bp)
    app.register_blueprint(media_files_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(community_bp)
    app.register_blueprint(messages_bp)
    app.register_blueprint(portal_bp)
    app.register_blueprint(teaching_bp)

    # Registered last: it owns the broadest URL rules, including the
    # catch-all that renders "not built yet" destinations.
    app.register_blueprint(main_bp)


def _register_error_handlers(app: Flask) -> None:
    logger = logging.getLogger(__name__)

    def _handler(code: int):
        def render(_error):
            return render_template(f"errors/{code}.html"), code
        return render

    for code in (400, 403, 404, 413, 429):
        app.register_error_handler(code, _handler(code))

    @app.errorhandler(500)
    def internal_error(error):
        # Log the detail server-side; show the visitor nothing internal.
        logger.exception("Unhandled error at %s: %s", request.path, error)
        return render_template("errors/500.html"), 500


def _register_security_headers(app: Flask) -> None:
    @app.before_request
    def issue_nonce():
        # Fresh per request. A reused nonce is no better than
        # 'unsafe-inline', because an injected script could carry it.
        g.csp_nonce = secrets.token_urlsafe(16)

    @app.after_request
    def set_headers(response):
        nonce = getattr(g, "csp_nonce", "")
        response.headers.setdefault(
            "Content-Security-Policy", _build_csp(app, nonce)
        )
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault(
            "Referrer-Policy", "strict-origin-when-cross-origin"
        )
        response.headers.setdefault(
            "Permissions-Policy", "geolocation=(), microphone=(), camera=()"
        )
        if app.config.get("FORCE_HTTPS"):
            response.headers.setdefault(
                "Strict-Transport-Security",
                "max-age=31536000; includeSubDomains",
            )
        return response


def _register_health(app: Flask) -> None:
    @app.get("/healthz")
    def healthz():
        """Railway's health check.

        Reports the database separately so a failing check distinguishes
        "process is up but the database is unreachable" from a dead app.
        """
        from sqlalchemy import text

        database = "ok"
        try:
            db.session.execute(text("SELECT 1"))
        except Exception:  # noqa: BLE001 - the reason is logged, not returned
            logging.getLogger(__name__).exception("Health check: database")
            database = "unavailable"

        healthy = database == "ok"
        return (
            {"status": "ok" if healthy else "degraded", "database": database},
            200 if healthy else 503,
        )


def _register_context(app: Flask) -> None:
    from app import content
    from app.services import media as media_service

    def _site_images():
        """Slot assignments for the current request.

        Wrapped in try/except because the public site must still render
        when the database is unreachable: an unavailable photograph
        should degrade to its placeholder, not to a 500.
        """
        from app.services import site_images

        try:
            return site_images.all_assignments()
        except Exception:  # noqa: BLE001 - logged, then degraded
            logging.getLogger(__name__).exception(
                "Could not load site image assignments"
            )
            return {}

    @app.template_filter("naira")
    def naira(kobo) -> str:
        """Format an amount of kobo as naira.

        A filter rather than a format string repeated in every template:
        money appears on the fee tables, the enrolment statement, the
        course pages and the offering list, and eight copies of
        "%.2f"|format drift. Thousands are separated because
        250000.00 and 2500.00 are genuinely hard to tell apart at a
        glance, and this is the number somebody is about to pay.
        """
        if kobo is None:
            return ""
        return f"₦{kobo / 100:,.2f}"

    @app.context_processor
    def inject_media_helpers():
        return {
            "media_url": media_service.variant_url,
            "media_size": media_service.variant_size,
            "media_srcset": media_service.srcset_for,
        }

    def _unread_messages() -> int:
        """Rooms with something new, for the header.

        Wrapped like _account_home: a count is never worth a 500 on
        every page, and before the messaging tables exist this would
        otherwise raise on the first request after a deploy.
        """
        from flask_login import current_user

        if not getattr(current_user, "is_authenticated", False):
            return 0
        try:
            from app.services import messaging

            return messaging.unread_count(current_user)
        except Exception:  # noqa: BLE001 - the header must never 500
            logger.exception("Could not count unread conversations")
            return 0

    def _account_home() -> str:
        """Where this visitor's own "home" is, or the sign-in page."""
        from flask_login import current_user

        from app.services import rbac as rbac_service

        if not getattr(current_user, "is_authenticated", False):
            return url_for("auth.login")
        try:
            return url_for(rbac_service.landing_endpoint(current_user))
        except Exception:  # noqa: BLE001 - the header must never 500
            logger.exception("Could not resolve an account landing page")
            return url_for("portal.dashboard")

    @app.context_processor
    def inject_site_context():
        return {
            "site_images": _site_images(),
            "csp_nonce": getattr(g, "csp_nonce", ""),
            "org_name": app.config["ORG_NAME"],
            "org_short_name": app.config["ORG_SHORT_NAME"],
            "org_tagline": app.config["ORG_TAGLINE"],
            "primary_nav": content.PRIMARY_NAV,
            "header_groups": content.HEADER_GROUPS,
            "footer_nav": content.FOOTER_NAV,
            "now_year": datetime.now(timezone.utc).year,
            "turnstile_site_key": app.config.get("TURNSTILE_SITE_KEY"),
            "turnstile_enabled": bool(
                app.config.get("TURNSTILE_ENABLED")
                and app.config.get("TURNSTILE_SITE_KEY")
            ),
            # "Your account" is not one page. The header must send an
            # administrator to the console and a student to the portal,
            # or staff land on a dashboard about enrolments they do not
            # have and conclude the console does not exist.
            "account_home": _account_home(),
            "unread_messages": _unread_messages(),
        }
