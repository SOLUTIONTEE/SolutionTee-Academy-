"""The tutor workspace: your courses, your students, your drafts.

Every route here is scoped by ownership in the service layer, not by the
permission on the decorator. `teaching.view` decides who gets a workspace;
`teaching.assert_can_edit` decides whose course this actually is. A tutor
holding the permission still cannot open another tutor's course.

Publishing is a separate permission from building, exactly as it is for
articles: somebody who can write a course is not automatically somebody
who can put it in front of students.
"""
from __future__ import annotations

import logging

from flask import (
    Blueprint, abort, flash, redirect, render_template, request, url_for,
)
from flask_login import current_user
from sqlalchemy import select

from app.extensions import db
from app.models.courses import Course, Module
from app.models.messaging import ConversationKind
from app.models.user import User
from app.services import messaging, rbac, teaching
from app.services.rbac import require_permission

logger = logging.getLogger(__name__)

bp = Blueprint("teaching", __name__, url_prefix="/teaching")


def _course_or_404(public_id: str) -> Course:
    course = db.session.scalar(
        select(Course).where(Course.public_id == public_id)
    )
    if course is None:
        abort(404)
    return course


def _owned_or_403(public_id: str) -> Course:
    """Fetch and authorise in one step.

    Deliberately not two calls. A route that fetches first and checks
    second is one edit away from someone deleting the check and nothing
    failing.
    """
    course = _course_or_404(public_id)
    try:
        teaching.assert_can_edit(course, current_user)
    except teaching.TeachingError:
        abort(403)
    return course


@bp.get("/")
@require_permission("teaching.view")
def workspace():
    return render_template(
        "teaching/workspace.html",
        workspace=teaching.build(current_user),
        enrolment_count=teaching.enrolment_count,
        score_percent=teaching.score_percent,
    )


@bp.get("/students")
@require_permission("teaching.view")
def students():
    return render_template(
        "teaching/students.html",
        students=teaching.students_of(current_user),
    )


@bp.post("/students/<student_id>/message")
@require_permission("teaching.view")
def message_student(student_id: str):
    """Open (or reopen) the conversation with one of your students.

    Finds the existing direct room before creating one: two people should
    have one thread, not a new one per click. The ownership check is the
    same one the student list is built from, so somebody who is not on
    your list cannot be messaged by guessing an id.
    """
    student = db.session.scalar(
        select(User).where(User.public_id == student_id)
    )
    if student is None:
        abort(404)

    if not teaching.teaches(current_user, student):
        abort(403)

    conversation = messaging.direct_between(current_user, student)
    if conversation is None:
        conversation = messaging.start(
            creator=current_user, participants=[student],
            kind=ConversationKind.DIRECT,
        )
        messaging.system_note(
            conversation,
            f"{current_user.full_name} started this conversation.",
        )

    return redirect(url_for("messages.thread",
                            public_id=conversation.public_id))


@bp.get("/courses/<public_id>")
@require_permission("teaching.manage")
def course(public_id: str):
    item = _owned_or_403(public_id)
    return render_template(
        "teaching/course.html",
        course=item,
        enrolled=teaching.enrolment_count(item),
        can_publish=rbac.has_permission(current_user,
                                        "teaching.publish"),
    )


@bp.post("/courses/<public_id>/modules")
@require_permission("teaching.manage")
def add_module(public_id: str):
    item = _owned_or_403(public_id)
    title = (request.form.get("title") or "").strip()
    if not title:
        flash("A section needs a title before it can be added.", "warning")
        return redirect(url_for("teaching.course", public_id=public_id))

    teaching.add_module(item, title=title)
    flash("Section added.", "success")
    return redirect(url_for("teaching.course", public_id=public_id))


@bp.post("/courses/<public_id>/modules/<int:module_id>/lessons")
@require_permission("teaching.manage")
def add_lesson(public_id: str, module_id: int):
    item = _owned_or_403(public_id)

    module = db.session.get(Module, module_id)
    # The module has to belong to THIS course. Without this a valid course
    # of your own plus somebody else's module id would let you write into
    # their course.
    if module is None or module.course_id != item.id:
        abort(404)

    title = (request.form.get("title") or "").strip()
    if not title:
        flash("A lesson needs a title.", "warning")
        return redirect(url_for("teaching.course", public_id=public_id))

    teaching.add_lesson(module, title=title,
                        kind=(request.form.get("kind") or "text"))
    flash("Lesson added.", "success")
    return redirect(url_for("teaching.course", public_id=public_id))


@bp.post("/courses/<public_id>/publish")
@require_permission("teaching.publish")
def publish(public_id: str):
    item = _owned_or_403(public_id)
    item.is_published = True
    db.session.commit()
    flash("Published. Students enrolled on this offering can see it now.",
          "success")
    return redirect(url_for("teaching.course", public_id=public_id))


@bp.post("/courses/<public_id>/unpublish")
@require_permission("teaching.publish")
def unpublish(public_id: str):
    item = _owned_or_403(public_id)
    item.is_published = False
    db.session.commit()
    flash("Taken down. Students can no longer see it.", "success")
    return redirect(url_for("teaching.course", public_id=public_id))
