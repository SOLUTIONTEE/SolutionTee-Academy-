"""Admin: the front door of the console.

Deliberately requires only media.view - the lowest bar any staff member
clears. The page itself is counts and links; the things it links to each
enforce their own permission, so a member of staff who cannot publish
still gets a useful landing page rather than a 403 on sign-in.
"""
from __future__ import annotations

import logging

from flask import Blueprint, render_template

from app.services import console
from app.services.rbac import require_permission

logger = logging.getLogger(__name__)

bp = Blueprint("admin_overview", __name__, url_prefix="/admin")


@bp.get("/")
@require_permission("media.view")
def index():
    return render_template("admin/overview.html", overview=console.build())
