"""Custom Flask CLI commands."""
from __future__ import annotations

import click
from flask import Flask


def register_cli(app: Flask) -> None:

    @app.cli.command("routes-audit")
    def routes_audit() -> None:
        """List every route with its methods. Useful before a release."""
        rules = sorted(app.url_map.iter_rules(), key=lambda r: str(r))
        for rule in rules:
            methods = ",".join(sorted(rule.methods - {"HEAD", "OPTIONS"}))
            click.echo(f"{methods:<12} {rule}  ->  {rule.endpoint}")

    @app.cli.command("sync-rbac")
    def sync_rbac() -> None:
        """Create any missing roles and permissions.

        Additive: it never revokes. Safe to run on every deploy.
        """
        from app.services.rbac import sync_roles_and_permissions

        result = sync_roles_and_permissions()
        click.echo(f"Permissions created: {result['permissions_created']}")
        click.echo(f"Roles created:       {result['roles_created']}")

    @app.cli.command("create-superadmin")
    @click.option("--email", prompt=True)
    @click.option("--name", prompt="Full name")
    @click.password_option(
        "--password", prompt="Password", confirmation_prompt=True,
    )
    def create_superadmin(email: str, name: str, password: str) -> None:
        """Create the first super administrator.

        The password is prompted for, never taken from the command line:
        an argument would land in shell history and in the process list.
        """
        from app.models.enums import RoleName
        from app.services.accounts import create_staff_account
        from app.services.security.passwords import PasswordError, validate

        try:
            validate(password, email=email, full_name=name)
        except PasswordError as exc:
            raise click.ClickException(str(exc)) from exc

        try:
            user = create_staff_account(
                email=email, full_name=name, password=password,
                role_name=RoleName.SUPER_ADMIN,
            )
        except ValueError as exc:
            raise click.ClickException(str(exc)) from exc

        click.echo(f"Created super administrator {user.email}")

    @app.cli.command("seed-media-folders")
    def seed_media_folders() -> None:
        """Create a starting set of media folders.

        Only creates what is missing, so it is safe to re-run. Folders
        are admin-managed afterwards; this is a convenience, not a
        hard-coded list.
        """
        from app.extensions import db
        from app.models.base import slugify
        from app.models.media import MediaFolder
        from sqlalchemy import select

        names = ["Homepage", "Programmes", "CBT", "Classes", "Events",
                 "Facilities", "Tutors", "Student success", "Blog",
                 "General"]
        created = 0
        for position, name in enumerate(names):
            slug = slugify(name)
            exists = db.session.scalar(
                select(MediaFolder).where(MediaFolder.slug == slug)
            )
            if exists is None:
                db.session.add(MediaFolder(name=name, slug=slug,
                                           position=position))
                created += 1
        db.session.commit()
        click.echo(f"Media folders created: {created}")

    @app.cli.command("create-offering")
    @click.option("--title", prompt=True)
    @click.option("--programme", prompt="Programme slug (jamb, waec, ...)")
    @click.option("--mode", prompt="Mode (online, physical, hybrid)",
                  type=click.Choice(["online", "physical", "hybrid"]))
    @click.option("--price", prompt="Price in naira", type=int)
    @click.option("--plan", default="50,50",
                  help="Instalment percentages, e.g. 50,50 or 100 or 30,30,40")
    def create_offering(title: str, programme: str, mode: str, price: int,
                        plan: str) -> None:
        """Create something students can pay for.

        The price is entered in naira and stored in kobo. Money is never
        held as a float.
        """
        from app.extensions import db
        from app.models.base import slugify
        from app.models.payments import Offering, PaymentPlan
        from app.services.payments.ledger import validate_instalments

        if price <= 0:
            raise click.ClickException("A price must be greater than zero.")

        try:
            percents = [int(part) for part in plan.split(",") if part.strip()]
        except ValueError as exc:
            raise click.ClickException(
                "Percentages must be whole numbers, e.g. 50,50"
            ) from exc

        instalments = [{"percent": percent,
                        "due_day_offset": index * 30}
                       for index, percent in enumerate(percents)]
        try:
            validate_instalments(instalments)
        except ValueError as exc:
            raise click.ClickException(str(exc)) from exc

        # From the title alone. Prefixing programme and mode produced
        # "jamb-online-jamb-online-2026" whenever the title already said
        # so, which it usually does.
        slug = slugify(title)
        if db.session.scalar(
                db.select(Offering).where(Offering.slug == slug)):
            raise click.ClickException(
                f"An offering with the slug {slug!r} already exists."
            )
        offering = Offering(
            title=title, slug=slug, programme_slug=programme, mode=mode,
            price_kobo=price * 100, is_published=False,
        )
        db.session.add(offering)
        db.session.commit()

        db.session.add(PaymentPlan(
            offering_id=offering.id,
            name=" / ".join(f"{p}%" for p in percents),
            instalments=instalments, is_default=True,
        ))
        db.session.commit()

        click.echo(f"Created offering {slug}")
        click.echo(f"  price: {price:,} naira ({offering.price_kobo} kobo)")
        click.echo(f"  plan:  {' / '.join(str(p) + '%' for p in percents)}")
        click.echo("  It is unpublished. Publish it when the details are "
                   "confirmed.")
