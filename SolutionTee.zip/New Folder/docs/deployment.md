# Deployment — Railway

## Start command

`railway.json` and `Procfile` both use:

```
flask db upgrade && gunicorn --config gunicorn.conf.py wsgi:application
```

`flask db upgrade` only applies migrations that already exist and only
moves forward. It never drops a table or a column on its own. A
destructive schema change must be written deliberately into a migration
and reviewed before it is merged — it is not something a deploy decides.

Health check: `GET /healthz`. It returns `200` with
`{"status": "ok", "database": "ok"}`, or `503` with
`"database": "unavailable"` when PostgreSQL cannot be reached. The
database is reported separately on purpose, so a failing check tells you
whether the process died or the database did.

## Worker sizing

Configured in `gunicorn.conf.py`: **2 workers × 4 threads**, `gthread`.

The reasoning is written out in that file, but the short version is that
the binding constraint is PostgreSQL connections, not CPU:

```
workers × (DB_POOL_SIZE + DB_MAX_OVERFLOW) = 2 × (5 + 5) = 20 peak
```

Every worker carries its own SQLAlchemy pool, so adding a worker
multiplies connections. Raise `WEB_THREADS` before `WEB_CONCURRENCY`:
this application spends most of a request waiting on PostgreSQL or on an
outbound API, which releases the GIL.

Do not use the `(2 × CPU) + 1` formula here. Railway reports the host's
core count rather than the container's share, so it over-provisions
badly.

## Environment variables

Copy `.env.example` and fill it in **in the Railway dashboard**, not in a
file. Nothing in this repository should ever contain a real credential.

Required before first boot:

| Variable | Notes |
|---|---|
| `DATABASE_URL` | Railway's PostgreSQL plugin supplies it. A `postgres://` or `postgresql://` scheme is rewritten onto psycopg 3 automatically. |
| `SECRET_KEY` | `python -c "import secrets; print(secrets.token_urlsafe(48))"` |
| `SECURITY_PASSWORD_SALT` | Generate separately from `SECRET_KEY`. |
| `FLASK_ENV` | `production`. This is what turns on `SESSION_COOKIE_SECURE` and HSTS. |

Required before the relevant feature is used:

- **Email:** `EMAIL_TRANSPORT=brevo`, `BREVO_API_KEY`, and the three
  sender addresses. Left unset, mail prints to the log instead of
  sending.
- **Payments:** `PAYSTACK_SECRET_KEY`, `PAYSTACK_PUBLIC_KEY`,
  `PAYSTACK_WEBHOOK_SECRET`.
- **Media:** `STORAGE_BACKEND=r2` plus the five `R2_*` variables.
  `R2_PUBLIC_URL` is also read by the app factory and added to the
  Content-Security-Policy `img-src`, so images fail to load if it is
  wrong.
- **Bot protection:** `TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY`.

### Rate limiting across workers

`RATELIMIT_STORAGE_URI` defaults to `memory://`, which is **per
process**. With 2 workers, a limit of 5 attempts is effectively 10.
That is acceptable for coarse abuse limits and not acceptable for
anything protecting a credential. Before the login and OTP flows go
live, point it at a shared backend or reduce to a single worker.

## Backups and recovery

Railway's own PostgreSQL backups are the first line, but they are not a
recovery plan on their own — a plan is only real once it has been
restored at least once.

**Database.** Take a logical dump on a schedule, kept outside Railway:

```bash
pg_dump "$DATABASE_URL" --format=custom --file=solutiontee-$(date +%F).dump
```

Restore into an empty database:

```bash
pg_restore --dbname="$TARGET_DATABASE_URL" --clean --if-exists solutiontee-YYYY-MM-DD.dump
```

Restore into a **scratch** database first and point a staging deploy at
it. Never test a restore against production.

**Object storage.** R2 holds every uploaded image, document and
submission, and none of it is in the database — PostgreSQL stores only
metadata and object keys. A database restore without the matching R2
bucket gives you a catalogue of files that no longer exist. Enable
versioning on the bucket and keep the two backups aligned in time.

**Configuration.** Environment variables live only in the Railway
dashboard. Keep an offline record of *which variables exist*; keep the
values themselves in a password manager, never in this repository.

**Rehearse it.** Quarterly: restore the newest dump into a scratch
database, run `flask db upgrade`, boot the app against it, and confirm
`/healthz` returns `200`. A backup that has never been restored is an
assumption, not a backup.
