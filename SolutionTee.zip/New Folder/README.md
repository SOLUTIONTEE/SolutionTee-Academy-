# SolutionTee Edu Academy

Learn. Think. Solve.

An education platform for JAMB, WAEC, NECO, GCE and Post-UTME
preparation, with CBT practice, an online academy, admission support and
a student portal.

**Status: foundation, media, accounts, payments and the academy.** The
public site, design system, navigation, deployment configuration, the
admin media library with its reusable picker, the full account
lifecycle, payments, the online academy, the CBT engine and the
**Every page in the navigation is a real page.** The public site, the
design system, accounts, payments, the online academy, the CBT engine,
the admission centre, the Education Information Centre with its editorial
admin, the media library, the contact pipeline and the student dashboard
are all built and tested — 478 tests. The initial Alembic migration is
generated and verified against PostgreSQL.

Not built: parent accounts, staff-facing admin beyond media, site images
and articles, and the community/messaging features. Routes for them exist and render an honest "not built yet" page
rather than placeholder marketing copy. See [Roadmap](#roadmap).

## Stack

Flask 3 · SQLAlchemy 2.0 · PostgreSQL (Railway) · Alembic · Jinja ·
vanilla JS · Cloudflare R2 · Brevo · Paystack · Cloudflare Turnstile

Server-rendered throughout. JavaScript is progressive enhancement: every
page works with it disabled.

## Running it locally

```bash
py -3 -m venv .venv
.venv/Scripts/python.exe -m pip install -r requirements.txt
cp .env.example .env      # then fill it in
.venv/Scripts/python.exe run.py
```

You need a PostgreSQL server. Point `DATABASE_URL` at it and run
`flask db upgrade`. The public pages render without a database — they
read from `app/content` — so you can work on the site before the
database is set up, but nothing behind an account will work.

```bash
.venv/Scripts/python.exe -m pytest        # 478 tests
```

The suite runs against SQLite in a temporary directory so it needs no
database server. That is the one place SQLite is allowed: production is
PostgreSQL-only, and `check_production_config` refuses to boot otherwise.

### First administrator

```bash
.venv/Scripts/python.exe -m flask sync-rbac
.venv/Scripts/python.exe -m flask create-superadmin
.venv/Scripts/python.exe -m flask seed-media-folders
```

`create-superadmin` prompts for the password rather than taking it as an
argument, so it never lands in shell history or the process list.

### Creating something to sell

```bash
.venv/Scripts/python.exe -m flask create-offering
```

Prompts for a title, programme, mode, price **in naira** and an
instalment split (`50,50`, `100`, `30,30,40`). The price is stored in
kobo. New offerings start unpublished.

## Layout

```
app/
  __init__.py        application factory, CSP, error handlers, /healthz
  extensions.py      extension singletons, kept import-cycle free
  blueprints/        routing and validation only
  models/            SQLAlchemy 2.0 typed models
  services/          business logic and authorisation decisions
    media/           validation, processing, library operations
    storage/         R2 and local backends behind one interface
  content/           navigation and examination reference data
  templates/         Jinja, layouts + partials + per-page
  static/css/        tokens → base → layout → components → pages
config.py            every setting from the environment
gunicorn.conf.py     worker sizing, with the reasoning written down
docs/deployment.md   Railway, environment variables, backup and recovery
```

**Blueprints route. Services decide.** No authorisation decision, side
effect or business rule belongs in a route function or a template.

## Conventions worth knowing

**Nothing invents a fact.** No fee, date, deadline, pass rate, student
count, tutor or testimonial appears anywhere unless it was supplied.
Where a fact is missing the page says so plainly. This is enforced by
tests (`test_pages_state_no_unsupplied_facts`), not just by convention —
adding a price to a template will fail the suite.

**Secrets come from the environment, always.** `.env` is git-ignored,
`.env.example` holds empty placeholders, and a test asserts both.
`check_production_config` refuses to boot production on a non-PostgreSQL
database or the development `SECRET_KEY`.

**Money is integer kobo, and only the gateway is believed.** No float
ever touches a price. Nothing is granted on a claim — not a browser
arriving at the callback URL, not a webhook body, not a form field. Each
is only a prompt to ask Paystack directly, and the answer is checked
against the amount and currency we asked for. Every settle is
idempotent, because providers retry until they get a 200.

**Store first, send second.** A contact enquiry is written to the
database before anything is emailed. Email is the part that fails, and an
enquiry that only ever existed inside a failed email is a customer nobody
knows they lost. A failed forward flags the row rather than losing it, and
the sender is thanked either way — from their side the message *has* been
received.

**Publication is derived, not flagged.** An article is live when it was
meant to go out AND its moment has arrived. Because an arrived scheduled
piece counts as live, scheduling needs nothing running in the
background — there is no window where a story is late because a job was,
and `promote_scheduled` only tidies the label. Guidance also carries
three dates that mean different things: published, content updated, and
last checked. Collapsing them would let a typo fix masquerade as
re-confirming a deadline.

**A wrong admission fact costs somebody a year.** So the schema refuses
to hold one without provenance: `source_url` and `last_verified_at` are
NOT NULL on every application window. Status ("Open", "Closing soon") is
derived from the dates on every read rather than stored, because a stored
status is correct on the day it is typed and wrong every day after. A
listing nobody has checked in six weeks says so, in the reader's
interest rather than ours. A missing date renders as "Not announced",
never as a guess. And the institution's fee and SolutionTee's fee are
separate columns that are never summed — they are different transactions
with different recipients.

**The clock belongs to the server.** A CBT attempt's `expires_at` is
computed once and stored. The countdown in the browser is a courtesy;
every answer write re-reads the stored deadline, so changing a system
clock, editing the timer in devtools or leaving the tab open overnight
gains nothing. A question's correct choices are joined only when
marking — the paper a candidate is looking at has never contained them.

**Hiding a link is not access control.** Every route that serves paid
content calls `courses.lesson_access` first, and the "mark complete"
action re-checks rather than trusting that the page loaded. A lesson is
looked up within its course, never by slug alone, so a paid-for lesson
cannot be reached through the URL of a course that has not been paid
for.

**Rich text is sanitised on the way in, once.** Sanitising on the way
out would mean every template that forgets `| safe` is fine and every
one that remembers is a hole. Staff-authored is not the same as
trustworthy: a compromised staff account must not become stored XSS
against every student.

**Enumeration is not a feature.** Registering an address that already
exists, and asking to reset a password for an address that does not,
both produce exactly the same response as the ordinary case. Telling a
stranger which addresses have accounts would disclose who attends this
centre. Tests assert the responses are identical.

**The design system is in `tokens.css`.** Components pick from the
spacing scale rather than inventing margins. Colour values that look
arbitrary are the ones that passed contrast measurement — the comments
record what was rejected and why. Gold `#F2B233` is a fill colour and
fails as small text at 1.88:1; `--color-accent-ink` is the text-safe
version.

**Desktop and mobile navigation are different interfaces**, not one
interface at two widths. Both are rendered server-side.

## Roadmap

Ordered by what unblocks the most downstream work.

**Done**

- **Media library** — R2/local storage behind one interface, batch
  upload with per-file state, generated variants, EXIF stripping,
  deduplication by checksum, folders, search, pagination, usage
  tracking and deletion protection.
- **Media picker** — a reusable `<dialog>` shared by every image field,
  with search, folder filtering, pagination and upload-without-leaving.
  Its first consumer is **Site images**, which assigns media to the
  fixed slots the public templates expose.
- **Accounts** — registration for students and parents only, email
  verification by one-time code, guardian consent for under-18s, sign-in
  with per-email lockout, and password reset by signed expiring link.
- **RBAC** — a permission catalogue enforced in `require_permission`,
  with an audit trail.
- **Payments** — offerings, configurable instalment plans, Paystack
  checkout, server-side verification, signature-checked idempotent
  webhooks, and a ledger where discounts and waivers are recorded as
  adjustments rather than by rewriting the agreed price.

- **The academy** — courses, modules and lessons, with access decided in
  one place. A curriculum is public so somebody can see what they would
  be paying for; a lesson body is served only after that check passes.
  Rich text is sanitised on the way in.

- **The CBT engine** — configurable papers, a frozen question set per
  attempt, a server-held clock, autosave, marking with a per-topic
  breakdown, and result-visibility rules. Most of its test suite is
  attempts to cheat.

- **The admission centre** — institutions, application windows,
  requirements and fees. Status is derived from dates on every read, so
  it cannot go stale; every listing carries when it was last verified
  and a link to the source it came from.

- **The Education Information Centre** — an editorial front arranged by
  importance rather than a card grid, with reading time and a table of
  contents derived from the body, and three distinct dates: published,
  content updated, last checked.

**Next**

1. **The parent experience** — the models support a parent linked to a
   student; there is no parent-facing view yet.
2. **Staff admin for the remaining domains** — users, enrolments,
   payments, CBT question bank and contact messages are all
   service-complete and shell-driven.
3. **Communities and messaging** — there is still no account
   page, so the header names the signed-in user rather than linking
   anywhere.
