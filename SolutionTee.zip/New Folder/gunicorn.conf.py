"""Gunicorn configuration for Railway.

Sized for a small container, not for a large dedicated server. The usual
(2 x CPU) + 1 formula assumes a machine this service does not run on and
would open far more PostgreSQL connections than a small plan allows.

Connection arithmetic, which is the real constraint:

    workers x (DB_POOL_SIZE + DB_MAX_OVERFLOW)
      = 2 x (5 + 5)
      = 20 connections at absolute peak

Each worker holds its own SQLAlchemy pool, so raising the worker count
multiplies database connections rather than merely adding CPU.

Threads rather than extra workers: this application spends most of a
request waiting on PostgreSQL and on outbound HTTP (Paystack, Brevo,
Turnstile, R2), which releases the GIL. Threads absorb that concurrency
at a fraction of the memory an extra worker costs.
"""
from __future__ import annotations

import multiprocessing
import os


def _int(name: str, default: int) -> int:
    try:
        return int((os.getenv(name) or "").strip() or default)
    except (TypeError, ValueError):
        return default


bind = f"0.0.0.0:{os.getenv('PORT', '8000')}"

# Deliberately not derived from CPU count: Railway reports the host's
# cores, not the container's share, so the formula over-provisions badly.
workers = _int("WEB_CONCURRENCY", 2)
threads = _int("WEB_THREADS", 4)
worker_class = "gthread"

# Longer than a normal request but short enough that a wedged worker is
# recycled rather than holding a database connection indefinitely.
timeout = _int("WEB_TIMEOUT", 60)
graceful_timeout = 30

# Railway terminates idle upstream connections; keep-alive stays above the
# proxy's own idle window so a connection is not reused after it is gone.
keepalive = 5

# Recycling guards against slow leaks in a long-lived process. The jitter
# stops every worker restarting on the same request.
max_requests = _int("WEB_MAX_REQUESTS", 800)
max_requests_jitter = 80

# Logs go to the container's stdout/stderr, which is what Railway reads.
accesslog = "-"
errorlog = "-"
loglevel = os.getenv("LOG_LEVEL", "info").lower()

# Trust the platform proxy's forwarded headers so request.scheme is https
# and the client IP used for rate limiting is the real one.
forwarded_allow_ips = "*"

# Loading the app before forking shares its memory across workers.
preload_app = True


def on_starting(server):
    server.log.info(
        "SolutionTee Edu: %s workers x %s threads, peak DB connections %s",
        workers, threads, workers * 10,
    )
