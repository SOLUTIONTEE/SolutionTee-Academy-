"""Checkout, callback and webhook endpoints.

The service tests cover the money logic. These cover what the HTTP layer
exposes: who may reach what, and whether the webhook is reachable by the
gateway without being reachable by anyone else.
"""
from __future__ import annotations

import hashlib
import hmac
import json
from datetime import date

import pytest

from app.extensions import db
from app.models.enums import RoleName
from app.models.payments import Offering, Payment, PaymentPlan
from app.services import accounts, payments
from tests.test_payments import (
    PRICE, SECRET, StubGateway, success,
)


@pytest.fixture
def gateway(app, monkeypatch):
    stub = StubGateway()
    monkeypatch.setattr(payments, "get_gateway", lambda: stub)
    monkeypatch.setattr("app.services.payments.gateway.get_gateway",
                        lambda: stub)
    return stub


@pytest.fixture
def offering(app):
    item = Offering(
        title="JAMB Online, 2026 session", slug="jamb-online-2026",
        programme_slug="jamb", mode="online", price_kobo=PRICE,
        is_published=True,
    )
    db.session.add(item)
    db.session.commit()
    db.session.add(PaymentPlan(
        offering_id=item.id, name="Two instalments",
        instalments=[{"percent": 50, "due_day_offset": 0},
                     {"percent": 50, "due_day_offset": 30}],
        is_default=True,
    ))
    db.session.commit()
    return item


def make_student(email="student@example.com", *, verified=True):
    result = accounts.register(
        email=email, full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=date(1998, 5, 1),
    )
    if verified:
        accounts.mark_email_verified(result.user)
    return result.user


@pytest.fixture
def student(app):
    return make_student()


def sign(body: bytes, secret: str = SECRET) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha512).hexdigest()


def webhook_body(reference, amount, event="charge.success", event_id=999):
    return json.dumps({
        "event": event,
        "data": {"id": event_id, "reference": reference, "amount": amount,
                 "currency": "NGN", "status": "success"},
    }).encode()


# ---------------------------------------------------------------------------
# Enrolling
# ---------------------------------------------------------------------------

def test_anonymous_cannot_enrol(client, offering):
    response = client.post(f"/enrol/{offering.slug}")
    assert response.status_code in (302, 401)
    assert "/login" in response.headers.get("Location", "")


def test_an_unverified_account_cannot_enrol(client, app, gateway, offering,
                                            sign_in):
    """An unverified address cannot be billed to or written to."""
    user = make_student("unverified@example.com", verified=False)
    sign_in(user)

    response = client.post(f"/enrol/{offering.slug}", follow_redirects=False)
    assert response.status_code == 302
    assert "/verify" in response.headers["Location"]
    assert gateway.initialise_calls == []


def test_a_verified_student_is_sent_to_the_gateway(client, app, gateway,
                                                   offering, student,
                                                   sign_in):
    sign_in(student)
    response = client.post(f"/enrol/{offering.slug}", follow_redirects=False)

    assert response.status_code == 302
    assert response.headers["Location"].startswith("https://checkout.test/")
    # Server-computed: the first instalment, not anything from the form.
    assert gateway.initialise_calls[0]["amount_kobo"] == PRICE // 2


def test_enrolling_in_an_unpublished_offering_is_404(client, app, gateway,
                                                     offering, student,
                                                     sign_in):
    offering.is_published = False
    db.session.commit()
    sign_in(student)
    assert client.post(f"/enrol/{offering.slug}").status_code == 404


def test_the_form_cannot_dictate_the_amount(client, app, gateway, offering,
                                            student, sign_in):
    """A posted amount field must be ignored entirely."""
    sign_in(student)
    client.post(f"/enrol/{offering.slug}",
                data={"amount_kobo": "1", "amount": "1", "price": "1"})
    assert gateway.initialise_calls[0]["amount_kobo"] == PRICE // 2


# ---------------------------------------------------------------------------
# Viewing an enrolment
# ---------------------------------------------------------------------------

def test_a_student_sees_their_own_enrolment(client, app, gateway, offering,
                                            student, sign_in):
    enrolment = payments.enrol(student, offering)
    sign_in(student)

    response = client.get(f"/enrolments/{enrolment.public_id}")
    assert response.status_code == 200
    assert b"Outstanding" in response.data


def test_a_student_cannot_read_another_balance(client, app, offering,
                                               student, sign_in):
    """Otherwise enrolment ids become a way to read other people's fees."""
    enrolment = payments.enrol(student, offering)
    intruder = make_student("intruder@example.com")
    sign_in(intruder)

    assert client.get(f"/enrolments/{enrolment.public_id}").status_code == 403


def test_an_unknown_enrolment_is_404(client, app, student, sign_in):
    sign_in(student)
    assert client.get("/enrolments/does-not-exist").status_code == 404


# ---------------------------------------------------------------------------
# The callback
# ---------------------------------------------------------------------------

def test_the_callback_verifies_rather_than_believing_the_query_string(
        client, app, gateway, offering, student, sign_in):
    enrolment = payments.enrol(student, offering)
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)
    sign_in(student)

    client.get(f"/payments/callback?reference={start.payment.reference}")

    assert gateway.verify_calls == [start.payment.reference]
    db.session.refresh(enrolment)
    assert payments.has_access(enrolment)


def test_the_callback_grants_nothing_for_an_invented_reference(
        client, app, gateway, offering, student, sign_in):
    """Anyone can open this URL with any reference."""
    enrolment = payments.enrol(student, offering)
    sign_in(student)

    response = client.get("/payments/callback?reference=STE-invented",
                          follow_redirects=False)
    assert response.status_code == 302
    assert gateway.verify_calls == []
    db.session.refresh(enrolment)
    assert not payments.has_access(enrolment)


def test_the_callback_without_a_reference_does_not_error(client, app,
                                                         gateway):
    response = client.get("/payments/callback", follow_redirects=False)
    assert response.status_code == 302


# ---------------------------------------------------------------------------
# The webhook
# ---------------------------------------------------------------------------

def test_the_webhook_needs_no_csrf_token_but_needs_a_signature(
        client, app, gateway, offering, student):
    """Paystack has no session and cannot carry a CSRF token.

    The HMAC replaces it, and is the stronger check: a CSRF token proves
    a form came from our page, the signature proves the body came from
    the gateway.
    """
    enrolment = payments.enrol(student, offering)
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    body = webhook_body(start.payment.reference, PRICE // 2)

    # No CSRF token anywhere, and it is accepted.
    response = client.post("/payments/webhook/paystack", data=body,
                           headers={"x-paystack-signature": sign(body),
                                    "Content-Type": "application/json"})
    assert response.status_code == 200
    assert response.get_json()["detail"] == "settled"


def test_an_unsigned_webhook_is_refused(client, app, gateway, offering,
                                        student):
    enrolment = payments.enrol(student, offering)
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    body = webhook_body(start.payment.reference, PRICE // 2)

    response = client.post("/payments/webhook/paystack", data=body,
                           headers={"Content-Type": "application/json"})
    assert response.status_code == 400
    assert gateway.verify_calls == []
    db.session.refresh(enrolment)
    assert not payments.has_access(enrolment)


def test_a_wrongly_signed_webhook_is_refused(client, app, gateway, offering,
                                             student):
    enrolment = payments.enrol(student, offering)
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    body = webhook_body(start.payment.reference, PRICE // 2)

    response = client.post(
        "/payments/webhook/paystack", data=body,
        headers={"x-paystack-signature": sign(body, "attacker-key"),
                 "Content-Type": "application/json"})
    assert response.status_code == 400
    assert not payments.has_access(enrolment)


def test_a_retried_webhook_returns_200_so_the_provider_stops(
        client, app, gateway, offering, student):
    """A non-200 makes the provider retry, and retrying achieves nothing."""
    enrolment = payments.enrol(student, offering)
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    body = webhook_body(start.payment.reference, PRICE // 2)
    headers = {"x-paystack-signature": sign(body),
               "Content-Type": "application/json"}

    statuses = []
    for _ in range(4):
        response = client.post("/payments/webhook/paystack", data=body,
                               headers=headers)
        statuses.append((response.status_code,
                         response.get_json()["detail"]))

    assert statuses == [(200, "settled")] + [(200, "duplicate")] * 3
    assert payments.balance_for(enrolment).paid_kobo == PRICE // 2


def test_the_webhook_signature_covers_the_exact_bytes_received(
        client, app, gateway, offering, student):
    """Re-serialising the parsed JSON would change the digest.

    This is why the route reads the raw body rather than request.json.
    """
    enrolment = payments.enrol(student, offering)
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    body = webhook_body(start.payment.reference, PRICE // 2)
    signature = sign(body)

    # Same JSON, different byte layout: the signature must no longer fit.
    reformatted = json.dumps(json.loads(body), indent=2).encode()
    response = client.post("/payments/webhook/paystack", data=reformatted,
                           headers={"x-paystack-signature": signature,
                                    "Content-Type": "application/json"})
    assert response.status_code == 400


def test_a_webhook_for_an_unknown_reference_is_acknowledged_not_applied(
        client, app, gateway):
    body = webhook_body("STE-never-issued", 100)
    response = client.post("/payments/webhook/paystack", data=body,
                           headers={"x-paystack-signature": sign(body),
                                    "Content-Type": "application/json"})
    # Accepted so the provider stops retrying; nothing was created.
    assert response.status_code == 200
    assert db.session.query(payments.Payment).count() == 0 \
        if hasattr(payments, "Payment") else True
