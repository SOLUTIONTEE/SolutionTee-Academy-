"""Payments: verification, idempotency, and the ledger.

The rule under test throughout: nothing is granted on a claim. Not a
browser arriving at a callback URL, not a webhook body, not a form
field. Only what the gateway says when asked directly.

The gateway itself is stubbed - these tests are about what this
application does with an answer, not about Paystack's HTTP.
"""
from __future__ import annotations

import hashlib
import hmac
import json

import pytest

from app.extensions import db
from app.models.enums import RoleName
from app.models.payments import (
    AdjustmentKind, Enrolment, EnrolmentStatus, Offering, Payment,
    PaymentPlan, PaymentStatus, WebhookEvent,
)
from app.services import payments
from app.services.payments import ledger
from app.services.payments.gateway import (
    Authorization, GatewayError, PaystackGateway, Verification,
)

#: Deliberately not shaped like a real Paystack key. The secret scanner
#: in test_config.py looks for provider key prefixes, and a fixture that
#: trips it would teach everyone to ignore the alarm.
SECRET = "stub-signing-key-for-tests-only"
PRICE = 5_000_000          # 50,000 naira in kobo


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

class StubGateway:
    """Stands in for Paystack. Records what it was asked, answers what
    the test tells it to."""

    def __init__(self, secret_key=SECRET):
        self._secret_key = secret_key
        self.currency = "NGN"
        self.initialise_calls = []
        self.verify_calls = []
        self.next_verification = None
        self.raise_on_initialise = False

    @property
    def configured(self):
        return True

    def initialise(self, *, email, amount_kobo, reference, callback_url,
                   metadata=None):
        if self.raise_on_initialise:
            raise GatewayError("gateway down")
        self.initialise_calls.append({
            "email": email, "amount_kobo": amount_kobo,
            "reference": reference, "metadata": metadata,
        })
        return Authorization(
            authorization_url=f"https://checkout.test/{reference}",
            access_code="acc_test", reference=reference,
        )

    def verify(self, reference):
        self.verify_calls.append(reference)
        if self.next_verification is None:
            return Verification(ok=False, status="failed",
                                error="no stub configured")
        return self.next_verification

    def signature_is_valid(self, raw_body, signature):
        expected = hmac.new(self._secret_key.encode(), raw_body,
                            hashlib.sha512).hexdigest()
        return hmac.compare_digest(expected, signature or "")


@pytest.fixture
def gateway(app, monkeypatch):
    stub = StubGateway()
    monkeypatch.setattr(payments, "get_gateway", lambda: stub)
    monkeypatch.setattr("app.services.payments.gateway.get_gateway",
                        lambda: stub)
    return stub


@pytest.fixture
def offering(app):
    item = Offering(
        title="JAMB Online, 2026 session", slug="jamb-online-2026",
        programme_slug="jamb", mode="online", price_kobo=PRICE,
        is_published=True,
    )
    db.session.add(item)
    db.session.commit()
    return item


@pytest.fixture
def half_half_plan(app, offering):
    plan = PaymentPlan(
        offering_id=offering.id, name="Two instalments",
        instalments=[{"percent": 50, "due_day_offset": 0},
                     {"percent": 50, "due_day_offset": 30}],
        grace_days=7, is_default=True,
    )
    db.session.add(plan)
    db.session.commit()
    return plan


@pytest.fixture
def student(app):
    from app.services import accounts

    result = accounts.register(
        email="student@example.com", full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=__import__("datetime").date(1998, 5, 1),
    )
    accounts.mark_email_verified(result.user)
    return result.user


@pytest.fixture
def enrolment(app, student, offering, half_half_plan):
    return payments.enrol(student, offering, plan=half_half_plan)


def success(amount_kobo, currency="NGN", reference="ref"):
    return Verification(
        ok=True, status="success", amount_kobo=amount_kobo,
        currency=currency, gateway_reference="99887766",
        payload={"status": "success", "amount": amount_kobo},
    )


# ---------------------------------------------------------------------------
# Money arithmetic
# ---------------------------------------------------------------------------

def test_money_is_whole_kobo_never_a_float(app, offering):
    assert isinstance(offering.price_kobo, int)
    assert offering.price_naira == "50,000.00"


def test_instalments_must_total_one_hundred_percent(app):
    with pytest.raises(ValueError, match="total 100"):
        ledger.validate_instalments([{"percent": 50}, {"percent": 40}])
    with pytest.raises(ValueError, match="at least one"):
        ledger.validate_instalments([])
    ledger.validate_instalments([{"percent": 30}, {"percent": 30},
                                 {"percent": 40}])


def test_splitting_an_odd_amount_loses_nothing(app):
    """Three equal shares of an amount that will not divide by three."""
    parts = ledger.split_instalments(
        100_001, [{"percent": 33}, {"percent": 33}, {"percent": 34}]
    )
    assert sum(p.amount_kobo for p in parts) == 100_001, "a kobo went missing"


@pytest.mark.parametrize("total", [1, 7, 99, 100_001, 5_000_000, 33_333_333])
def test_no_amount_is_ever_lost_in_a_split(app, total):
    parts = ledger.split_instalments(
        total, [{"percent": 50}, {"percent": 25}, {"percent": 25}]
    )
    assert sum(p.amount_kobo for p in parts) == total


# ---------------------------------------------------------------------------
# Enrolment
# ---------------------------------------------------------------------------

def test_enrolling_copies_the_price_at_that_moment(app, student, offering,
                                                   half_half_plan):
    """A later price change must not alter an agreement already made."""
    place = payments.enrol(student, offering, plan=half_half_plan)
    assert place.agreed_price_kobo == PRICE

    offering.price_kobo = 9_000_000
    db.session.commit()
    db.session.refresh(place)
    assert place.agreed_price_kobo == PRICE


def test_enrolling_twice_returns_the_same_place(app, student, offering):
    first = payments.enrol(student, offering)
    second = payments.enrol(student, offering)
    assert first.id == second.id
    assert db.session.query(Enrolment).count() == 1


def test_a_new_enrolment_has_no_access(app, enrolment):
    assert enrolment.status == EnrolmentStatus.PENDING
    assert not payments.has_access(enrolment)


# ---------------------------------------------------------------------------
# Starting a payment
# ---------------------------------------------------------------------------

def test_the_amount_comes_from_the_server_not_the_caller(app, gateway,
                                                         student, enrolment):
    """The first instalment of a 50/50 plan on 50,000 naira."""
    result = payments.start_payment(student, enrolment,
                                    callback_url="https://x.test/cb")
    assert result.ok
    assert gateway.initialise_calls[0]["amount_kobo"] == PRICE // 2


def test_a_caller_cannot_pay_more_than_is_owed(app, gateway, student,
                                               enrolment):
    """Overpaying creates a refund problem nobody asked for."""
    result = payments.start_payment(student, enrolment,
                                    callback_url="https://x.test/cb",
                                    amount_kobo=PRICE * 2)
    assert not result.ok
    assert "outstanding balance" in result.message
    assert gateway.initialise_calls == []


def test_a_caller_cannot_pay_zero_or_a_negative_amount(app, gateway, student,
                                                        enrolment):
    for bad in (0, -1, -PRICE):
        result = payments.start_payment(student, enrolment,
                                        callback_url="https://x.test/cb",
                                        amount_kobo=bad)
        assert not result.ok
    assert gateway.initialise_calls == []


def test_nobody_can_start_a_payment_on_another_account(app, gateway,
                                                       enrolment):
    from app.services import accounts

    other = accounts.register(
        email="other@example.com", full_name="Other Person",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=__import__("datetime").date(1998, 5, 1),
    ).user

    with pytest.raises(payments.PaymentError, match="another account"):
        payments.start_payment(other, enrolment,
                               callback_url="https://x.test/cb")


def test_a_pending_payment_row_exists_before_leaving_for_the_gateway(
        app, gateway, student, enrolment):
    """So a payment that succeeds but never returns is still recoverable."""
    result = payments.start_payment(student, enrolment,
                                    callback_url="https://x.test/cb")
    stored = db.session.query(Payment).one()
    assert stored.reference == result.payment.reference
    assert stored.status == PaymentStatus.PENDING
    assert stored.verified_at is None


def test_a_gateway_failure_marks_the_payment_not_the_request(app, gateway,
                                                             student,
                                                             enrolment):
    gateway.raise_on_initialise = True
    result = payments.start_payment(student, enrolment,
                                    callback_url="https://x.test/cb")
    assert not result.ok
    assert db.session.query(Payment).one().status == PaymentStatus.FAILED


def test_references_are_unique_and_unguessable(app, gateway, student,
                                                enrolment):
    seen = {payments.generate_reference() for _ in range(200)}
    assert len(seen) == 200
    # Not a bare counter: a neighbouring reference must not be derivable.
    assert all(len(ref) > 20 for ref in seen)


# ---------------------------------------------------------------------------
# Settling - the part that grants things
# ---------------------------------------------------------------------------

def test_a_verified_payment_grants_access(app, gateway, student, enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    result = payments.settle(start.payment.reference)
    assert result.ok and result.newly_settled

    db.session.refresh(enrolment)
    assert enrolment.status == EnrolmentStatus.ACTIVE
    assert payments.has_access(enrolment)


def test_settling_asks_the_gateway_rather_than_trusting_the_caller(
        app, gateway, student, enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)
    payments.settle(start.payment.reference)
    assert gateway.verify_calls == [start.payment.reference]


def test_an_underpayment_is_recorded_but_grants_nothing(app, gateway,
                                                        student, enrolment):
    """The classic attack: change the amount at the gateway."""
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(100)     # one naira, not 25,000

    result = payments.settle(start.payment.reference)
    assert not result.ok

    payment = db.session.query(Payment).one()
    assert payment.status == PaymentStatus.FAILED
    assert "underpaid" in payment.failure_reason
    # The evidence is kept.
    assert payment.paid_amount_kobo == 100

    db.session.refresh(enrolment)
    assert not payments.has_access(enrolment)


def test_the_wrong_currency_grants_nothing(app, gateway, student, enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2, currency="USD")

    result = payments.settle(start.payment.reference)
    assert not result.ok
    assert "currency" in db.session.query(Payment).one().failure_reason
    assert not payments.has_access(enrolment)


def test_a_failed_verification_grants_nothing(app, gateway, student,
                                              enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = Verification(ok=False, status="failed",
                                             error="declined")

    result = payments.settle(start.payment.reference)
    assert not result.ok
    assert db.session.query(Payment).one().status == PaymentStatus.FAILED
    assert not payments.has_access(enrolment)


def test_an_unknown_reference_is_refused(app, gateway):
    """Someone guessing references must learn nothing and get nothing."""
    result = payments.settle("STE-not-a-real-reference")
    assert not result.ok
    assert gateway.verify_calls == []


def test_a_gateway_outage_leaves_the_payment_recoverable(app, gateway,
                                                          student, enrolment):
    """Not marked failed: the money may well have been taken."""
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")

    def raise_error(reference):
        raise GatewayError("timed out")

    gateway.verify = raise_error

    result = payments.settle(start.payment.reference)
    assert not result.ok
    assert db.session.query(Payment).one().status == PaymentStatus.PENDING


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------

def test_settling_twice_records_one_payment(app, gateway, student, enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    first = payments.settle(start.payment.reference)
    second = payments.settle(start.payment.reference)

    assert first.newly_settled is True
    assert second.ok and second.newly_settled is False
    # The gateway is not asked again once it is settled.
    assert gateway.verify_calls == [start.payment.reference]
    assert ledger.balance_for(enrolment).paid_kobo == PRICE // 2


def test_settling_many_times_never_double_credits(app, gateway, student,
                                                  enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    for _ in range(10):
        payments.settle(start.payment.reference)

    assert ledger.balance_for(enrolment).paid_kobo == PRICE // 2
    assert db.session.query(Payment).count() == 1


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------

def sign(body: bytes, secret: str = SECRET) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha512).hexdigest()


def webhook_body(reference: str, amount: int, event="charge.success",
                 event_id=12345):
    return json.dumps({
        "event": event,
        "data": {"id": event_id, "reference": reference, "amount": amount,
                 "currency": "NGN", "status": "success"},
    }).encode()


def test_a_forged_webhook_is_rejected(app, gateway, student, enrolment):
    """Anyone can POST to a webhook URL. The HMAC is the only gate."""
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    body = webhook_body(start.payment.reference, PRICE // 2)
    accepted, message = payments.handle_webhook(body, "not-a-real-signature")

    assert not accepted
    assert message == "invalid signature"
    assert gateway.verify_calls == []
    assert not payments.has_access(enrolment)


def test_a_webhook_signed_with_the_wrong_key_is_rejected(app, gateway,
                                                         student, enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    body = webhook_body(start.payment.reference, PRICE // 2)

    accepted, _ = payments.handle_webhook(body, sign(body, "wrong-key"))
    assert not accepted
    assert not payments.has_access(enrolment)


def test_a_tampered_body_fails_its_signature(app, gateway, student,
                                             enrolment):
    """Changing the amount after signing must invalidate the digest."""
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    body = webhook_body(start.payment.reference, PRICE // 2)
    signature = sign(body)

    tampered = body.replace(str(PRICE // 2).encode(), b"1")
    accepted, _ = payments.handle_webhook(tampered, signature)
    assert not accepted


def test_a_valid_webhook_settles_the_payment(app, gateway, student,
                                             enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    body = webhook_body(start.payment.reference, PRICE // 2)
    accepted, message = payments.handle_webhook(body, sign(body))

    assert accepted and message == "settled"
    db.session.refresh(enrolment)
    assert payments.has_access(enrolment)


def test_a_repeated_webhook_is_accepted_but_applied_once(app, gateway,
                                                         student, enrolment):
    """Providers retry until they get a 200. Retrying must change nothing."""
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)

    body = webhook_body(start.payment.reference, PRICE // 2)
    signature = sign(body)

    outcomes = [payments.handle_webhook(body, signature) for _ in range(5)]

    assert all(accepted for accepted, _ in outcomes)
    assert [m for _, m in outcomes] == ["settled"] + ["duplicate"] * 4
    assert db.session.query(WebhookEvent).count() == 1
    assert ledger.balance_for(enrolment).paid_kobo == PRICE // 2


def test_a_webhook_body_is_never_trusted_for_the_amount(app, gateway,
                                                        student, enrolment):
    """A correctly signed webhook still does not set the amount.

    Even a genuine notification is only a prompt to go and ask.
    """
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    # The body claims the full price; the gateway will say otherwise.
    gateway.next_verification = success(100)

    body = webhook_body(start.payment.reference, PRICE)
    payments.handle_webhook(body, sign(body))

    payment = db.session.query(Payment).one()
    assert payment.status == PaymentStatus.FAILED
    assert payment.paid_amount_kobo == 100


def test_an_unrelated_event_is_acknowledged_and_ignored(app, gateway):
    body = webhook_body("STE-whatever", 1000, event="customer.created")
    accepted, message = payments.handle_webhook(body, sign(body))
    assert accepted and message == "ignored"
    assert gateway.verify_calls == []


def test_an_unreadable_body_is_rejected(app, gateway):
    body = b"this is not json at all"
    accepted, message = payments.handle_webhook(body, sign(body))
    assert not accepted
    assert message == "unreadable body"


# ---------------------------------------------------------------------------
# The ledger
# ---------------------------------------------------------------------------

def test_a_part_payment_leaves_the_right_balance(app, gateway, student,
                                                 enrolment):
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)
    payments.settle(start.payment.reference)

    balance = ledger.balance_for(enrolment)
    assert balance.paid_kobo == PRICE // 2
    assert balance.outstanding_kobo == PRICE // 2
    assert not balance.is_settled


def test_paying_both_instalments_settles_the_enrolment(app, gateway, student,
                                                       enrolment):
    for _ in range(2):
        start = payments.start_payment(student, enrolment,
                                       callback_url="https://x.test/cb")
        gateway.next_verification = success(start.payment.amount_kobo)
        payments.settle(start.payment.reference)

    balance = ledger.balance_for(enrolment)
    assert balance.paid_kobo == PRICE
    assert balance.is_settled
    assert payments.next_instalment_due(enrolment) is None


def test_a_discount_reduces_what_is_owed_without_rewriting_the_price(
        app, student, enrolment, admin_user):
    ledger.record_adjustment(enrolment, kind=AdjustmentKind.DISCOUNT,
                             amount_kobo=1_000_000,
                             reason="Sibling discount agreed with the centre",
                             actor=admin_user)

    balance = ledger.balance_for(enrolment)
    assert balance.agreed_kobo == PRICE, "the original agreement stands"
    assert balance.owed_kobo == PRICE - 1_000_000
    assert enrolment.adjustments[0].reason.startswith("Sibling")
    assert enrolment.adjustments[0].actor_user_id == admin_user.id


def test_a_discount_can_never_increase_the_bill(app, enrolment, admin_user):
    """A positive amount passed as a discount must still reduce."""
    ledger.record_adjustment(enrolment, kind=AdjustmentKind.DISCOUNT,
                             amount_kobo=500_000, reason="Agreed reduction",
                             actor=admin_user)
    assert ledger.balance_for(enrolment).owed_kobo == PRICE - 500_000


def test_an_adjustment_must_say_why(app, enrolment, admin_user):
    """An unexplained change to somebody's fees is not auditable."""
    with pytest.raises(ValueError, match="why"):
        ledger.record_adjustment(enrolment, kind=AdjustmentKind.DISCOUNT,
                                 amount_kobo=100, reason="   ",
                                 actor=admin_user)
    with pytest.raises(ValueError, match="changes nothing"):
        ledger.record_adjustment(enrolment, kind=AdjustmentKind.DISCOUNT,
                                 amount_kobo=0, reason="Nothing",
                                 actor=admin_user)


def test_a_full_waiver_settles_without_any_payment(app, enrolment,
                                                   admin_user):
    ledger.record_adjustment(enrolment, kind=AdjustmentKind.WAIVER,
                             amount_kobo=PRICE,
                             reason="Scholarship approved by the director",
                             actor=admin_user)
    balance = ledger.balance_for(enrolment)
    assert balance.owed_kobo == 0
    assert balance.is_settled


def test_an_over_large_discount_never_produces_a_negative_balance(
        app, enrolment, admin_user):
    """Otherwise the ledger reads as the centre owing the student."""
    ledger.record_adjustment(enrolment, kind=AdjustmentKind.WAIVER,
                             amount_kobo=PRICE * 3,
                             reason="Mistaken over-large waiver",
                             actor=admin_user)
    assert ledger.balance_for(enrolment).owed_kobo == 0
    assert ledger.balance_for(enrolment).outstanding_kobo == 0


def test_an_unverified_payment_never_counts_towards_the_balance(
        app, gateway, student, enrolment):
    """A pending row is not money."""
    payments.start_payment(student, enrolment,
                           callback_url="https://x.test/cb")
    assert ledger.balance_for(enrolment).paid_kobo == 0


def test_the_next_instalment_accounts_for_what_is_already_paid(
        app, gateway, student, enrolment):
    first = payments.next_instalment_due(enrolment)
    assert first.amount_kobo == PRICE // 2

    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(PRICE // 2)
    payments.settle(start.payment.reference)

    second = payments.next_instalment_due(enrolment)
    assert second.amount_kobo == PRICE // 2
    assert second.index == 1


# ---------------------------------------------------------------------------
# Signature verification in the real gateway class
# ---------------------------------------------------------------------------

def test_the_real_signature_check_accepts_only_the_exact_body(app):
    gw = PaystackGateway(secret_key=SECRET)
    body = b'{"event":"charge.success","data":{"reference":"abc"}}'
    good = hmac.new(SECRET.encode(), body, hashlib.sha512).hexdigest()

    assert gw.signature_is_valid(body, good)
    assert not gw.signature_is_valid(body + b" ", good)
    assert not gw.signature_is_valid(body, good[:-1] + "0")
    assert not gw.signature_is_valid(body, "")
    assert not gw.signature_is_valid(body, None)


def test_an_unconfigured_gateway_refuses_to_validate_anything(app):
    """No secret must mean no signature passes, not every signature."""
    gw = PaystackGateway(secret_key="")
    body = b'{"event":"charge.success"}'
    assert not gw.signature_is_valid(body, "anything")
    assert not gw.signature_is_valid(body, "")


def test_an_unconfigured_gateway_refuses_to_charge(app):
    gw = PaystackGateway(secret_key="")
    with pytest.raises(GatewayError, match="not configured"):
        gw.initialise(email="a@b.com", amount_kobo=100, reference="r",
                      callback_url="https://x.test/cb")


def test_the_gateway_refuses_a_non_positive_charge(app):
    gw = PaystackGateway(secret_key=SECRET)
    with pytest.raises(GatewayError, match="non-positive"):
        gw.initialise(email="a@b.com", amount_kobo=0, reference="r",
                      callback_url="https://x.test/cb")
