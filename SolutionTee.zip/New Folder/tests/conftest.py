"""Shared test fixtures.

The suite runs against SQLite in a temporary directory rather than
PostgreSQL. That is a deliberate, narrow exception: it keeps the tests
runnable on any machine without a database server, and nothing in the
production path depends on it - `ProductionConfig` is PostgreSQL-only and
`test_config.py` asserts as much. The two PostgreSQL-specific column
types carry portable variants for exactly this reason.

Storage is likewise redirected to a temporary directory, so a test run
never writes into `instance/`.
"""
from __future__ import annotations

import io
import os
import sqlite3
import tempfile

# These are set before `config` is imported, because TestingConfig reads
# the environment at class-definition time and Flask-SQLAlchemy builds
# its engine during init_app. Changing app.config afterwards would leave
# the already-built PostgreSQL engine in place.
_TMP_ROOT = tempfile.mkdtemp(prefix="solutiontee-tests-")
os.environ["FLASK_ENV"] = "testing"
os.environ["TEST_DATABASE_URL"] = (
    "sqlite:///" + os.path.join(_TMP_ROOT, "test.sqlite3").replace("\\", "/")
)
os.environ["STORAGE_BACKEND"] = "local"
os.environ["LOCAL_STORAGE_ROOT"] = os.path.join(_TMP_ROOT, "media")
os.environ["EMAIL_TRANSPORT"] = "console"
os.environ["TURNSTILE_ENABLED"] = "false"

import pytest  # noqa: E402
from flask import g  # noqa: E402
from flask.testing import FlaskClient  # noqa: E402
from sqlalchemy import event  # noqa: E402
from sqlalchemy.engine import Engine  # noqa: E402
from PIL import Image  # noqa: E402

from app import create_app  # noqa: E402
from app.extensions import db as _db  # noqa: E402
from app.models.enums import AccountStatus, RoleName  # noqa: E402
from app.models.rbac import Role  # noqa: E402
from app.models.user import User  # noqa: E402
from app.services.rbac import sync_roles_and_permissions  # noqa: E402


@event.listens_for(Engine, "connect")
def _enforce_sqlite_foreign_keys(dbapi_connection, _record):
    """Make SQLite behave like PostgreSQL about foreign keys.

    SQLite ships with foreign key enforcement OFF, so ON DELETE SET NULL
    and CASCADE silently do nothing. Without this the suite is weaker
    than production: deleting a referenced row would appear to work in a
    test and break in Postgres, or vice versa.
    """
    if isinstance(dbapi_connection, sqlite3.Connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


@pytest.fixture(scope="session")
def app():
    application = create_app("testing")

    # Flask-Login's "strong" protection ties a session to an identifier
    # derived from the request, and deletes any session whose identifier
    # does not match. The fixtures below build a session directly rather
    # than posting to a login form - which does not exist yet - so strong
    # protection would discard it and every signed-in test would read as
    # anonymous. Relaxed here only; production keeps "strong", and the
    # login flow gets its own tests when it is built.
    application.login_manager.session_protection = "basic"

    with application.app_context():
        _db.create_all()
        sync_roles_and_permissions()
        yield application
        _db.session.remove()


class _IsolatedClient(FlaskClient):
    """A test client that never inherits a cached logged-in user.

    The `app` fixture holds an application context open for the whole
    session so fixtures and assertions can touch the database directly.
    Flask reuses an already-pushed context rather than creating one per
    request, which means every request shares a single `g` - and
    Flask-Login caches the resolved user there as `_login_user`.

    Left alone, the first request's user (often the anonymous one) is
    reused by every later request, so authorisation results depend on
    test order. Dropping the cache before each request restores the
    per-request behaviour a real deployment has.
    """

    def open(self, *args, **kwargs):
        g.pop("_login_user", None)
        # Flask-WTF caches the generated CSRF token on `g` too, and for the
        # same reason it must not survive into a request whose session is
        # different - the page would render a token belonging to an
        # earlier test and every POST would be rejected.
        g.pop("csrf_token", None)
        return super().open(*args, **kwargs)


@pytest.fixture
def client(app):
    app.test_client_class = _IsolatedClient
    return app.test_client()


@pytest.fixture(autouse=True)
def clean_tables(app):
    """Leave the database as each test found it.

    Roles and permissions are seeded once for the session and preserved;
    everything else is cleared, so tests cannot leak state into one
    another through the media or user tables.
    """
    yield
    _db.session.rollback()
    keep = {"roles", "permissions", "role_permissions"}
    for table in reversed(_db.metadata.sorted_tables):
        if table.name not in keep:
            _db.session.execute(table.delete())
    _db.session.commit()
    # Deleting the rows does not empty SQLAlchemy's identity map. Without
    # this, SQLite reuses primary keys and the next test's user loads as
    # the previous test's stale object - roles and all - which makes
    # authorisation results depend on test order.
    _db.session.remove()


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

def _make_user(email: str, *role_names: str) -> User:
    user = User(
        email=email,
        full_name="Test Person",
        password_hash="not-a-real-hash",
        status=AccountStatus.ACTIVE,
    )
    for name in role_names:
        role = _db.session.query(Role).filter_by(name=name).one()
        user.roles.append(role)
    _db.session.add(user)
    _db.session.commit()
    return user


@pytest.fixture
def admin_user(app):
    return _make_user("admin@example.test", RoleName.ADMIN)


@pytest.fixture
def super_admin_user(app):
    return _make_user("super@example.test", RoleName.SUPER_ADMIN)


@pytest.fixture
def instructor_user(app):
    return _make_user("tutor@example.test", RoleName.INSTRUCTOR)


@pytest.fixture
def student_user(app):
    return _make_user("student@example.test", RoleName.STUDENT)


@pytest.fixture
def sign_in(client):
    """Authenticate as a user without going through the login form.

    Flask-Login reads the session; setting it directly keeps these tests
    about media and authorisation rather than about the login flow.
    """
    def _sign_in(user):
        with client.session_transaction() as session:
            session["_user_id"] = str(user.id)
            session["_fresh"] = True
        return user
    return _sign_in


# ---------------------------------------------------------------------------
# Images
# ---------------------------------------------------------------------------

def make_image_bytes(width: int = 1200, height: int = 800, *,
                     fmt: str = "JPEG", colour=(90, 120, 180)) -> bytes:
    buffer = io.BytesIO()
    Image.new("RGB", (width, height), colour).save(buffer, format=fmt)
    return buffer.getvalue()


@pytest.fixture
def image_bytes():
    return make_image_bytes


@pytest.fixture
def upload_file():
    """A (stream, filename) pair shaped for the Flask test client."""
    def _upload(data: bytes, filename: str = "photo.jpg"):
        return (io.BytesIO(data), filename)
    return _upload
