"""Registration, verification, guardian consent and password reset.

The highest-risk code in the project: it decides who gets an account,
what a failed attempt costs, and what an attacker can learn by probing.
Several tests here assert on what the application deliberately does NOT
reveal.
"""
from __future__ import annotations

import re
from datetime import date, timedelta

import pytest

from app.extensions import db
from app.models.base import utcnow
from app.models.enums import AccountStatus, OtpPurpose, RoleName
from app.models.security import OtpToken
from app.models.user import User
from app.services import accounts
from app.services.security import otp, tokens
from app.services.security.passwords import (
    PasswordError, hash_password, validate, verify_password,
)

TODAY = date.today()
ADULT_DOB = TODAY.replace(year=TODAY.year - 25)
MINOR_DOB = TODAY.replace(year=TODAY.year - 14)


def register_payload(**overrides):
    payload = {
        "account_type": RoleName.STUDENT,
        "full_name": "Ada Okoro",
        "email": "ada@example.com",
        "phone": "",
        "date_of_birth": ADULT_DOB.isoformat(),
        "guardian_name": "",
        "guardian_email": "",
        "password": "correct-horse-battery",
        "confirm": "correct-horse-battery",
    }
    payload.update(overrides)
    return payload


def latest_code_hash(user, purpose):
    return db.session.scalar(
        db.select(OtpToken)
        .where(OtpToken.user_id == user.id, OtpToken.purpose == purpose)
        .order_by(OtpToken.created_at.desc())
    )


# ---------------------------------------------------------------------------
# Passwords
# ---------------------------------------------------------------------------

def test_password_hashes_are_salted_and_verify(app):
    first = hash_password("correct-horse-battery")
    second = hash_password("correct-horse-battery")
    assert first != second, "identical passwords must not share a hash"
    assert first.startswith("$argon2id$")
    assert verify_password(first, "correct-horse-battery")
    assert not verify_password(first, "wrong-password-entirely")


def test_verify_never_raises_on_a_corrupt_hash(app):
    """A damaged row must not turn the login page into a 500."""
    assert verify_password("", "anything") is False
    assert verify_password("not-a-hash", "anything") is False


@pytest.mark.parametrize("bad,reason", [
    ("short", "at least"),
    ("", "Enter"),
    ("adminadmin", "too easy"),
])
def test_weak_passwords_are_refused(app, bad, reason):
    with pytest.raises(PasswordError, match=reason):
        validate(bad)


def test_a_password_may_not_contain_the_email_or_name(app):
    with pytest.raises(PasswordError, match="email"):
        validate("adaokoro-is-here", email="adaokoro@example.com")
    with pytest.raises(PasswordError, match="name"):
        validate("okoro-family-2026", full_name="Ada Okoro")


# ---------------------------------------------------------------------------
# One-time codes
# ---------------------------------------------------------------------------

@pytest.fixture
def pending_user(app):
    result = accounts.register(
        email="ada@example.com", full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=ADULT_DOB,
    )
    return result.user


def test_codes_are_stored_hashed_never_in_plain_text(app, pending_user):
    issued = otp.issue(pending_user, OtpPurpose.REGISTER)
    token = latest_code_hash(pending_user, OtpPurpose.REGISTER)

    assert issued.ok and len(issued.code) == 6
    assert issued.code not in token.code_hash
    assert len(token.code_hash) == 64  # sha256 hex


def test_a_correct_code_verifies_once_and_then_is_spent(app, pending_user):
    issued = otp.issue(pending_user, OtpPurpose.REGISTER)
    assert otp.verify(pending_user, OtpPurpose.REGISTER, issued.code).ok

    # Replaying the same code must fail.
    again = otp.verify(pending_user, OtpPurpose.REGISTER, issued.code)
    assert not again.ok


def test_a_wrong_code_is_refused_and_counted(app, pending_user):
    otp.issue(pending_user, OtpPurpose.REGISTER)
    result = otp.verify(pending_user, OtpPurpose.REGISTER, "000000")
    assert not result.ok

    token = latest_code_hash(pending_user, OtpPurpose.REGISTER)
    assert token.attempts == 1


def test_codes_lock_after_the_attempt_limit(app, pending_user):
    issued = otp.issue(pending_user, OtpPurpose.REGISTER)
    limit = app.config["OTP_MAX_ATTEMPTS"]

    for _ in range(limit):
        otp.verify(pending_user, OtpPurpose.REGISTER, "000000")

    # Even the right code no longer works once the limit is reached.
    result = otp.verify(pending_user, OtpPurpose.REGISTER, issued.code)
    assert not result.ok
    assert "Too many" in result.message


def test_an_expired_code_is_refused(app, pending_user):
    issued = otp.issue(pending_user, OtpPurpose.REGISTER)
    token = latest_code_hash(pending_user, OtpPurpose.REGISTER)
    token.expires_at = utcnow() - timedelta(seconds=1)
    db.session.commit()

    result = otp.verify(pending_user, OtpPurpose.REGISTER, issued.code)
    assert not result.ok
    assert "expired" in result.message


def test_reissuing_supersedes_the_previous_code(app, pending_user):
    """Two live codes for one purpose would double an attacker's odds."""
    first = otp.issue(pending_user, OtpPurpose.REGISTER)

    # Step past the resend cooldown.
    latest_code_hash(pending_user, OtpPurpose.REGISTER).created_at = (
        utcnow() - timedelta(minutes=5)
    )
    db.session.commit()

    second = otp.issue(pending_user, OtpPurpose.REGISTER)
    assert second.ok

    assert not otp.verify(pending_user, OtpPurpose.REGISTER, first.code).ok
    assert otp.verify(pending_user, OtpPurpose.REGISTER, second.code).ok


def test_resending_too_quickly_is_refused(app, pending_user):
    otp.issue(pending_user, OtpPurpose.REGISTER)
    again = otp.issue(pending_user, OtpPurpose.REGISTER)
    assert not again.ok
    assert again.retry_after_seconds > 0


def test_a_code_cannot_be_replayed_for_a_different_purpose(app, pending_user):
    """A verification code must not double as guardian consent."""
    issued = otp.issue(pending_user, OtpPurpose.REGISTER)
    assert not otp.verify(pending_user, OtpPurpose.GUARDIAN, issued.code).ok


def test_a_code_cannot_be_redeemed_by_another_account(app, pending_user):
    other = accounts.register(
        email="bola@example.com", full_name="Bola Ade",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=ADULT_DOB,
    ).user
    issued = otp.issue(pending_user, OtpPurpose.REGISTER)
    assert not otp.verify(other, OtpPurpose.REGISTER, issued.code).ok


# ---------------------------------------------------------------------------
# Registration service
# ---------------------------------------------------------------------------

def test_registration_creates_a_student_with_a_profile(app):
    result = accounts.register(
        email="ada@example.com", full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=ADULT_DOB,
    )
    assert result.ok
    assert result.user.student_profile is not None
    assert [r.name for r in result.user.roles] == [RoleName.STUDENT]
    assert result.user.email_verified_at is None
    assert not result.guardian_required


@pytest.mark.parametrize("role", [RoleName.ADMIN, RoleName.SUPER_ADMIN,
                                  RoleName.EMPLOYEE, RoleName.INSTRUCTOR])
def test_nobody_can_self_register_as_staff(app, role):
    """The check lives in the service so no route can bypass it."""
    with pytest.raises(ValueError, match="students and parents"):
        accounts.register(
            email="sneaky@example.com", full_name="Sneaky Person",
            password="correct-horse-battery", role_name=role,
        )
    assert db.session.query(User).count() == 0


def test_a_minor_requires_a_guardian(app):
    result = accounts.register(
        email="kid@example.com", full_name="Chidi Nwosu",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=MINOR_DOB, guardian_email="parent@example.com",
        guardian_name="Mrs Nwosu",
    )
    assert result.guardian_required
    assert result.user.guardian_email == "parent@example.com"


def test_a_missing_date_of_birth_is_treated_as_a_minor(app):
    """Otherwise leaving the field blank would skip consent entirely."""
    result = accounts.register(
        email="unknown@example.com", full_name="Unknown Age",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=None, guardian_email="parent@example.com",
    )
    assert result.guardian_required


def test_registering_an_existing_address_does_not_confirm_it_exists(app):
    accounts.register(
        email="ada@example.com", full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=ADULT_DOB,
    )
    again = accounts.register(
        email="ada@example.com", full_name="Someone Else",
        password="different-passphrase", role_name=RoleName.STUDENT,
        date_of_birth=ADULT_DOB,
    )
    assert not again.ok
    assert again.message == "ALREADY_REGISTERED"
    # The original account is untouched.
    assert db.session.query(User).count() == 1
    assert accounts.find_by_email("ada@example.com").full_name == "Ada Okoro"


# ---------------------------------------------------------------------------
# Access gating
# ---------------------------------------------------------------------------

def test_an_unverified_account_is_gated(app, pending_user):
    state = accounts.access_state(pending_user)
    assert not state.allowed
    assert state.reason == "unverified"


def test_a_verified_adult_is_allowed(app, pending_user):
    accounts.mark_email_verified(pending_user)
    assert accounts.access_state(pending_user).allowed


def test_a_minor_stays_gated_until_the_guardian_confirms(app):
    user = accounts.register(
        email="kid@example.com", full_name="Chidi Nwosu",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=MINOR_DOB, guardian_email="parent@example.com",
    ).user
    accounts.mark_email_verified(user)

    state = accounts.access_state(user)
    assert not state.allowed
    assert state.reason == "guardian_pending"

    accounts.mark_guardian_verified(user)
    assert accounts.access_state(user).allowed


def test_a_suspended_account_is_gated(app, pending_user):
    accounts.mark_email_verified(pending_user)
    pending_user.status = AccountStatus.SUSPENDED
    db.session.commit()
    assert accounts.access_state(pending_user).reason == "suspended"


# ---------------------------------------------------------------------------
# Registration through the form
# ---------------------------------------------------------------------------

def test_the_form_creates_an_account_and_sends_a_code(client, app):
    response = client.post("/register", data=register_payload(),
                           follow_redirects=False)
    assert response.status_code == 302
    assert "/verify" in response.headers["Location"]

    user = accounts.find_by_email("ada@example.com")
    assert user is not None
    assert latest_code_hash(user, OtpPurpose.REGISTER) is not None


def test_the_form_refuses_a_staff_role(client, app):
    """Tampering with the hidden role must not create an admin."""
    client.post("/register",
                data=register_payload(account_type=RoleName.SUPER_ADMIN))
    assert accounts.find_by_email("ada@example.com") is None


def test_a_minor_without_a_guardian_email_is_refused(client, app):
    response = client.post("/register", data=register_payload(
        date_of_birth=MINOR_DOB.isoformat(), guardian_email=""))
    assert response.status_code == 200
    assert b"parent or guardian" in response.data
    assert accounts.find_by_email("ada@example.com") is None


def test_a_minor_cannot_use_their_own_address_as_the_guardian(client, app):
    response = client.post("/register", data=register_payload(
        date_of_birth=MINOR_DOB.isoformat(),
        guardian_email="ada@example.com"))
    assert response.status_code == 200
    assert b"not your own" in response.data
    assert accounts.find_by_email("ada@example.com") is None


def test_mismatched_passwords_are_refused(client, app):
    response = client.post("/register", data=register_payload(
        confirm="something-else-entirely"))
    assert response.status_code == 200
    assert b"do not match" in response.data
    assert accounts.find_by_email("ada@example.com") is None


def test_registering_an_existing_address_looks_identical(client, app):
    """Both paths must redirect to /verify and say nothing different."""
    first = client.post("/register", data=register_payload())
    second = client.post("/register", data=register_payload(
        full_name="Someone Else"))
    assert first.status_code == second.status_code == 302
    assert first.headers["Location"] == second.headers["Location"]


# ---------------------------------------------------------------------------
# Verification through the form
# ---------------------------------------------------------------------------

def test_verifying_signs_the_student_in(client, app):
    client.post("/register", data=register_payload())
    user = accounts.find_by_email("ada@example.com")

    issued = otp.issue(user, OtpPurpose.REGISTER)
    # The registration code was just issued, so step past the cooldown.
    latest_code_hash(user, OtpPurpose.REGISTER).created_at = (
        utcnow() - timedelta(minutes=5)
    )
    db.session.commit()
    issued = otp.issue(user, OtpPurpose.REGISTER)

    response = client.post("/verify", data={"code": issued.code},
                           follow_redirects=False)
    assert response.status_code == 302

    db.session.refresh(user)
    assert user.email_verified_at is not None


def test_a_wrong_code_keeps_the_account_unverified(client, app):
    client.post("/register", data=register_payload())
    user = accounts.find_by_email("ada@example.com")

    response = client.post("/verify", data={"code": "000000"})
    assert response.status_code == 200
    db.session.refresh(user)
    assert user.email_verified_at is None


# ---------------------------------------------------------------------------
# Password reset
# ---------------------------------------------------------------------------

@pytest.fixture
def verified_user(app):
    user = accounts.register(
        email="ada@example.com", full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=ADULT_DOB,
    ).user
    accounts.mark_email_verified(user)
    return user


def test_a_reset_token_round_trips(app, verified_user):
    token = tokens.make_reset_token(verified_user)
    assert tokens.read_reset_token(token).id == verified_user.id


def test_a_tampered_token_is_rejected(app, verified_user):
    token = tokens.make_reset_token(verified_user)
    assert tokens.read_reset_token(token + "x") is None
    assert tokens.read_reset_token("nonsense") is None
    assert tokens.read_reset_token("") is None


def test_a_token_expires(app, verified_user):
    token = tokens.make_reset_token(verified_user)
    assert tokens.read_reset_token(token, max_age=-1) is None


def test_changing_the_password_invalidates_outstanding_links(app,
                                                             verified_user):
    """A leaked link must not work after the account is already recovered."""
    token = tokens.make_reset_token(verified_user)
    accounts.set_password(verified_user, "a-brand-new-passphrase")
    assert tokens.read_reset_token(token) is None


def test_forgot_password_says_the_same_thing_either_way(client, app,
                                                        verified_user):
    """Otherwise the form becomes a way to test which addresses exist."""
    known = client.post("/forgot", data={"email": "ada@example.com"})
    unknown = client.post("/forgot", data={"email": "nobody@example.com"})

    assert known.status_code == unknown.status_code == 200
    # Both render the same page, with only the echoed address differing.
    assert b"has a SolutionTee account" in known.data
    assert b"has a SolutionTee account" in unknown.data


def test_reset_changes_the_password_and_the_old_one_stops_working(
        client, app, verified_user):
    token = tokens.make_reset_token(verified_user)
    response = client.post(f"/reset/{token}", data={
        "password": "a-brand-new-passphrase",
        "confirm": "a-brand-new-passphrase",
    }, follow_redirects=False)
    assert response.status_code == 302

    db.session.refresh(verified_user)
    assert verify_password(verified_user.password_hash,
                           "a-brand-new-passphrase")
    assert not verify_password(verified_user.password_hash,
                               "correct-horse-battery")


def test_a_used_reset_link_cannot_be_used_again(client, app, verified_user):
    token = tokens.make_reset_token(verified_user)
    client.post(f"/reset/{token}", data={
        "password": "a-brand-new-passphrase",
        "confirm": "a-brand-new-passphrase",
    })
    assert client.get(f"/reset/{token}").status_code == 400


def test_an_invalid_reset_link_explains_without_disclosing(client, app):
    response = client.get("/reset/not-a-real-token")
    assert response.status_code == 400
    body = response.get_data(as_text=True)
    assert "no longer works" in body
    # It must not say which of expired / forged / used it was.
    assert "forged" not in body.lower()


# ---------------------------------------------------------------------------
# Sign-in interaction
# ---------------------------------------------------------------------------

def test_sign_in_with_a_wrong_password_is_indistinguishable(client, app,
                                                            verified_user):
    unknown = client.post("/login", data={"email": "nobody@example.com",
                                          "password": "whatever-goes-here"})
    wrong = client.post("/login", data={"email": "ada@example.com",
                                        "password": "wrong-password-here"})
    assert unknown.status_code == wrong.status_code == 401

    def message(response):
        match = re.search(r'notice__body">\s*(.*?)\s*</span>',
                          response.get_data(as_text=True), re.S)
        return " ".join(match.group(1).split()) if match else ""

    assert message(unknown) == message(wrong)


def test_repeated_failures_lock_the_account_briefly(client, app,
                                                    verified_user):
    for _ in range(accounts.MAX_FAILED_ATTEMPTS):
        client.post("/login", data={"email": "ada@example.com",
                                    "password": "wrong-password-here"})

    # Even the correct password is refused during the lock-out.
    response = client.post("/login", data={"email": "ada@example.com",
                                           "password": "correct-horse-battery"})
    assert b"Too many failed attempts" in response.data


def test_a_get_cannot_log_anyone_out(client, app, verified_user, sign_in):
    """A GET logout can be fired by any image tag on any site.

    Asserts the property that matters - the session survives - rather
    than a status code, which varies with how routing resolves a
    method mismatch.
    """
    sign_in(verified_user)
    assert client.get("/admin/media/").status_code == 403  # signed in

    client.get("/logout")

    # Still signed in: a 403 rather than a redirect to the login page.
    assert client.get("/admin/media/").status_code == 403
