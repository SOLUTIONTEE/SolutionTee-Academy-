"""Configuration and deployment safety.

These tests guard the things that are silently catastrophic in
production: a leaked secret, a cookie without Secure, a database URL on
the wrong driver.
"""
from __future__ import annotations

import pathlib

import pytest

from config import (
    ConfigurationError, DevelopmentConfig, ProductionConfig, TestingConfig,
    _database_url, check_production_config,
)

REPO = pathlib.Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------------
# Database URL normalisation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("supplied,expected", [
    # Railway hands out this scheme; SQLAlchemy would pick psycopg2.
    ("postgresql://u:p@host:5432/db", "postgresql+psycopg://u:p@host:5432/db"),
    # The legacy scheme SQLAlchemy rejects outright.
    ("postgres://u:p@host:5432/db", "postgresql+psycopg://u:p@host:5432/db"),
    # Already explicit: left alone.
    ("postgresql+psycopg://u:p@host/db", "postgresql+psycopg://u:p@host/db"),
    ("", ""),
])
def test_database_url_is_normalised_onto_psycopg3(supplied, expected):
    assert _database_url(supplied) == expected


def test_production_refuses_to_boot_on_a_non_postgres_database():
    """The guard, not the ambient environment, is what is under test.

    Asserting on ProductionConfig.SQLALCHEMY_DATABASE_URI directly would
    make this test pass or fail according to whatever the developer
    happens to have in their local .env, which tests nothing.
    """
    class Sqlite(ProductionConfig):
        SQLALCHEMY_DATABASE_URI = "sqlite:///prod.sqlite3"
        SECRET_KEY = "a-real-key"
        SECURITY_PASSWORD_SALT = "a-real-salt"

    with pytest.raises(ConfigurationError, match="PostgreSQL"):
        check_production_config(Sqlite)


def test_production_refuses_to_boot_without_a_database():
    class NoDatabase(ProductionConfig):
        SQLALCHEMY_DATABASE_URI = ""
        SECRET_KEY = "a-real-key"
        SECURITY_PASSWORD_SALT = "a-real-salt"

    with pytest.raises(ConfigurationError, match="DATABASE_URL"):
        check_production_config(NoDatabase)


def test_production_refuses_to_boot_with_the_development_secret_key():
    """A shared default SECRET_KEY lets anyone forge a session cookie."""
    class DefaultKey(ProductionConfig):
        SQLALCHEMY_DATABASE_URI = "postgresql+psycopg://u:p@host/db"
        SECRET_KEY = "dev-only-insecure-key-change-me"
        SECURITY_PASSWORD_SALT = "a-real-salt"

    with pytest.raises(ConfigurationError, match="SECRET_KEY"):
        check_production_config(DefaultKey)


def test_a_correctly_configured_production_passes_the_guard():
    class Good(ProductionConfig):
        SQLALCHEMY_DATABASE_URI = "postgresql+psycopg://u:p@host:5432/db"
        SECRET_KEY = "a-real-key"
        SECURITY_PASSWORD_SALT = "a-real-salt"

    check_production_config(Good)  # must not raise


def test_the_guard_never_leaks_the_database_password():
    class Sqlite(ProductionConfig):
        SQLALCHEMY_DATABASE_URI = "mysql://user:hunter2@host/db"
        SECRET_KEY = "a-real-key"
        SECURITY_PASSWORD_SALT = "a-real-salt"

    with pytest.raises(ConfigurationError) as caught:
        check_production_config(Sqlite)
    assert "hunter2" not in str(caught.value)


# ---------------------------------------------------------------------------
# Session and transport security
# ---------------------------------------------------------------------------

def test_production_cookies_are_secure_and_httponly():
    assert ProductionConfig.SESSION_COOKIE_SECURE is True
    assert ProductionConfig.SESSION_COOKIE_HTTPONLY is True
    assert ProductionConfig.SESSION_COOKIE_SAMESITE == "Lax"


def test_development_does_not_require_https():
    """Otherwise the session cookie is dropped on http://localhost."""
    assert DevelopmentConfig.SESSION_COOKIE_SECURE is False


def test_testing_disables_outbound_side_effects():
    assert TestingConfig.EMAIL_TRANSPORT == "console"
    assert TestingConfig.TURNSTILE_ENABLED is False
    assert TestingConfig.WTF_CSRF_ENABLED is False


# ---------------------------------------------------------------------------
# Connection pooling
# ---------------------------------------------------------------------------

def test_pool_is_sized_conservatively_for_railway():
    """workers x (pool_size + max_overflow) must stay well under the plan."""
    options = ProductionConfig.SQLALCHEMY_ENGINE_OPTIONS
    per_worker = options["pool_size"] + options["max_overflow"]
    assert per_worker <= 15, "a single worker should not monopolise the pool"
    assert options["pool_pre_ping"] is True, (
        "Railway drops idle connections; without pre-ping the first query "
        "after an idle period fails"
    )
    assert options["pool_recycle"] > 0


# ---------------------------------------------------------------------------
# Secrets
# ---------------------------------------------------------------------------

SECRET_KEYS = [
    "SECRET_KEY", "SECURITY_PASSWORD_SALT", "DATABASE_URL", "BREVO_API_KEY",
    "PAYSTACK_SECRET_KEY", "PAYSTACK_WEBHOOK_SECRET", "R2_ACCESS_KEY",
    "R2_SECRET_KEY", "TURNSTILE_SECRET_KEY",
]


def test_env_example_holds_placeholders_only():
    """.env.example is committed, so every value in it must be empty."""
    populated = []
    for line in (REPO / ".env.example").read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, _, value = line.partition("=")
        if name.strip() in SECRET_KEYS and value.strip():
            populated.append(name.strip())
    assert populated == [], f".env.example has real values for: {populated}"


def test_env_example_documents_every_secret():
    text = (REPO / ".env.example").read_text(encoding="utf-8")
    missing = [k for k in SECRET_KEYS if f"{k}=" not in text]
    assert missing == [], f"undocumented environment variables: {missing}"


def test_dotenv_is_git_ignored():
    ignored = (REPO / ".gitignore").read_text(encoding="utf-8")
    assert ".env" in ignored
    assert "!.env.example" in ignored


def test_no_secret_is_hard_coded_in_source():
    """A credential must never appear as a literal in a tracked file."""
    suspicious = []
    markers = ("sk_live_", "sk_test_", "xkeysib-", "pk_live_")
    this_file = pathlib.Path(__file__).resolve()
    for path in REPO.rglob("*.py"):
        # This file necessarily contains the markers it searches for.
        if path.resolve() == this_file:
            continue
        if any(part in {".venv", "migrations", "__pycache__"}
               for part in path.parts):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in markers:
            if marker in text:
                suspicious.append(f"{path.name}: {marker}")
    assert suspicious == [], f"hard-coded credentials: {suspicious}"
