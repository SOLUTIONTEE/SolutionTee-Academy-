"""The admission centre.

The tests that matter most here are not about features. They are about
honesty: that a status cannot go stale, that an unverified fact cannot be
published as though it were checked, that a missing date is shown as
missing rather than guessed, and that SolutionTee never appears to be the
body doing the admitting.
"""
from __future__ import annotations

import re
from datetime import date, timedelta

import pytest

from app.extensions import db
from app.models.admissions import (
    AdmissionEnquiry, Application, ApplicationType, Institution,
    InstitutionKind,
)
from app.models.base import utcnow
from app.services import admissions


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def make_institution(*, name="University of Lagos", short="UNILAG",
                     kind=InstitutionKind.FEDERAL_UNIVERSITY,
                     state="Lagos", published=True) -> Institution:
    item = Institution(
        name=name, short_name=short,
        slug=short.lower() if short else name.lower().replace(" ", "-"),
        kind=kind, state=state, town="Akoka",
        website_url="https://example.test/school",
        is_published=published,
    )
    db.session.add(item)
    db.session.commit()
    return item


def make_application(institution, *, opens=None, closes=None,
                     verified_days_ago=0, published=True,
                     application_type=ApplicationType.POST_UTME,
                     session="2026/2027", programme="",
                     official_fee=None, service_fee=None,
                     assistance=False) -> Application:
    item = Application(
        institution_id=institution.id,
        programme_name=programme,
        application_type=application_type,
        session=session,
        opens_on=opens, closes_on=closes,
        official_fee_kobo=official_fee,
        service_fee_kobo=service_fee,
        eligibility="Five credits including English and Mathematics.",
        requirements=["JAMB result slip", "O'Level result", "Passport photo"],
        official_portal_url="https://example.test/school/apply",
        assistance_available=assistance,
        source_url="https://example.test/school/admissions-news",
        last_verified_at=utcnow() - timedelta(days=verified_days_ago),
        is_published=published,
    )
    db.session.add(item)
    db.session.commit()
    return item


@pytest.fixture
def school(app):
    return make_institution()


# ---------------------------------------------------------------------------
# Status is derived, never stored
# ---------------------------------------------------------------------------

def test_a_window_closing_next_month_is_open(app, school):
    item = make_application(school, opens=date(2026, 1, 1),
                            closes=date(2026, 12, 31))
    assert admissions.status_of(item, today=date(2026, 6, 1)) == \
        admissions.Status.OPEN


def test_a_window_closing_within_a_fortnight_is_closing_soon(app, school):
    item = make_application(school, opens=date(2026, 1, 1),
                            closes=date(2026, 6, 10))
    assert admissions.status_of(item, today=date(2026, 6, 1)) == \
        admissions.Status.CLOSING_SOON


def test_a_window_that_has_passed_is_closed(app, school):
    item = make_application(school, opens=date(2026, 1, 1),
                            closes=date(2026, 5, 31))
    assert admissions.status_of(item, today=date(2026, 6, 1)) == \
        admissions.Status.CLOSED


def test_a_window_that_has_not_started_is_opening_soon(app, school):
    item = make_application(school, opens=date(2026, 9, 1),
                            closes=date(2026, 10, 1))
    assert admissions.status_of(item, today=date(2026, 6, 1)) == \
        admissions.Status.OPENING_SOON


def test_a_window_with_no_dates_says_so_rather_than_guessing(app, school):
    """"Not announced" is the truth, and it is not the same as "open"."""
    item = make_application(school, opens=None, closes=None)
    assert admissions.status_of(item) == admissions.Status.UNDATED


def test_the_same_row_changes_status_as_time_passes(app, school):
    """The whole reason status is derived rather than stored."""
    item = make_application(school, opens=date(2026, 1, 1),
                            closes=date(2026, 6, 15))

    assert admissions.status_of(item, today=date(2025, 12, 1)) == \
        admissions.Status.OPENING_SOON
    assert admissions.status_of(item, today=date(2026, 3, 1)) == \
        admissions.Status.OPEN
    assert admissions.status_of(item, today=date(2026, 6, 10)) == \
        admissions.Status.CLOSING_SOON
    assert admissions.status_of(item, today=date(2026, 6, 16)) == \
        admissions.Status.CLOSED


def test_closing_today_still_counts_as_open(app, school):
    """A window that closes today has not closed yet."""
    item = make_application(school, closes=date(2026, 6, 1))
    assert admissions.status_of(item, today=date(2026, 6, 1)) == \
        admissions.Status.CLOSING_SOON
    assert admissions.days_until_close(item, today=date(2026, 6, 1)) == 0


# ---------------------------------------------------------------------------
# Provenance cannot be skipped
# ---------------------------------------------------------------------------

def test_an_application_cannot_exist_without_a_source(app, school):
    """The schema refuses it, not just the form."""
    from sqlalchemy.exc import IntegrityError

    item = Application(
        institution_id=school.id, application_type=ApplicationType.UTME,
        session="2026/2027", official_portal_url="https://example.test/x",
        source_url="", last_verified_at=utcnow(),
    )
    db.session.add(item)
    with pytest.raises(IntegrityError):
        db.session.commit()
    db.session.rollback()


def test_an_application_cannot_exist_without_a_portal_link(app, school):
    from sqlalchemy.exc import IntegrityError

    item = Application(
        institution_id=school.id, application_type=ApplicationType.UTME,
        session="2026/2027", official_portal_url="",
        source_url="https://example.test/x", last_verified_at=utcnow(),
    )
    db.session.add(item)
    with pytest.raises(IntegrityError):
        db.session.commit()
    db.session.rollback()


def test_an_institution_cannot_exist_without_a_website(app):
    from sqlalchemy.exc import IntegrityError

    db.session.add(Institution(name="Nowhere", slug="nowhere",
                               kind=InstitutionKind.POLYTECHNIC,
                               website_url=""))
    with pytest.raises(IntegrityError):
        db.session.commit()
    db.session.rollback()


# ---------------------------------------------------------------------------
# Freshness
# ---------------------------------------------------------------------------

def test_a_recently_checked_listing_reads_as_verified(app, school):
    item = make_application(school, verified_days_ago=1)
    freshness = admissions.freshness_of(item)
    assert freshness.level == "fresh"
    assert not freshness.is_stale
    assert "yesterday" in freshness.message


def test_a_listing_checked_last_month_is_ageing(app, school):
    item = make_application(school, verified_days_ago=30)
    freshness = admissions.freshness_of(item)
    assert freshness.level == "ageing"
    # It tells the reader what to do about it.
    assert "official portal" in freshness.message


def test_a_long_unchecked_listing_is_stale_and_says_so(app, school):
    item = make_application(school, verified_days_ago=120)
    freshness = admissions.freshness_of(item)
    assert freshness.is_stale
    assert "out of date" in freshness.message


def test_freshness_travels_with_every_listing(app, school):
    make_application(school, closes=date(2099, 1, 1), verified_days_ago=90)
    listing = admissions.browse()[0]
    assert listing.freshness.is_stale


# ---------------------------------------------------------------------------
# Browsing
# ---------------------------------------------------------------------------

def test_closed_windows_are_hidden_unless_asked_for(app, school):
    make_application(school, closes=date(2020, 1, 1))          # long gone
    make_application(school, closes=date(2099, 1, 1),
                     application_type=ApplicationType.UTME)

    assert len(admissions.browse()) == 1
    assert len(admissions.browse(include_closed=True)) == 2


def test_listings_are_ordered_by_what_closes_soonest(app, school):
    far = make_application(school, closes=date(2099, 1, 1),
                           application_type=ApplicationType.UTME)
    near = make_application(school,
                            closes=utcnow().date() + timedelta(days=3),
                            application_type=ApplicationType.POST_UTME)
    undated = make_application(school,
                               application_type=ApplicationType.DIRECT_ENTRY)

    order = [item.application.id for item in admissions.browse()]
    assert order.index(near.id) < order.index(far.id)
    assert order.index(far.id) < order.index(undated.id)


def test_unpublished_rows_are_invisible(app, school):
    make_application(school, closes=date(2099, 1, 1), published=False)
    assert admissions.browse() == []


def test_an_unpublished_institution_hides_its_applications(app):
    hidden = make_institution(name="Draft Poly", short="DP",
                              kind=InstitutionKind.POLYTECHNIC,
                              published=False)
    make_application(hidden, closes=date(2099, 1, 1))
    assert admissions.browse() == []


def test_groups_filter_by_institution_kind(app):
    uni = make_institution(name="Uni", short="U")
    poly = make_institution(name="Poly", short="P",
                            kind=InstitutionKind.POLYTECHNIC)
    make_application(uni, closes=date(2099, 1, 1))
    make_application(poly, closes=date(2099, 1, 1))

    assert len(admissions.browse(group="universities")) == 1
    assert len(admissions.browse(group="polytechnics")) == 1
    assert len(admissions.browse(group="nursing")) == 0


def test_search_covers_institution_and_programme(app, school):
    make_application(school, closes=date(2099, 1, 1),
                     programme="Mechanical Engineering")

    assert len(admissions.browse(query="unilag")) == 1
    assert len(admissions.browse(query="Mechanical")) == 1
    assert len(admissions.browse(query="nothing-like-this")) == 0


def test_counts_exclude_closed_windows(app, school):
    make_application(school, closes=date(2020, 1, 1))
    make_application(school, closes=date(2099, 1, 1),
                     application_type=ApplicationType.UTME)
    assert admissions.counts_by_group()["universities"] == 1


# ---------------------------------------------------------------------------
# The pages
# ---------------------------------------------------------------------------

def test_the_index_states_what_solutiontee_is_not(client, app):
    """Stated on the page, not buried in a footer."""
    body = client.get("/admission/").get_data(as_text=True)
    assert "independent academy" in body
    assert "cannot admit anyone" in body


@pytest.mark.parametrize("group", ["universities", "polytechnics",
                                    "colleges", "nursing"])
def test_every_group_in_the_navigation_has_a_page(client, app, group):
    assert client.get(f"/admission/{group}").status_code == 200


def test_an_unknown_group_is_404(client, app):
    assert client.get("/admission/spaceships").status_code == 404


def test_an_empty_group_explains_why_rather_than_showing_nothing(client, app):
    body = client.get("/admission/nursing").get_data(as_text=True)
    assert "Nothing listed here yet" in body
    assert "verified and" in body


def test_a_filter_that_matches_nothing_differs_from_an_empty_section(
        client, app, school):
    make_application(school, closes=date(2099, 1, 1))
    body = client.get(
        "/admission/universities?q=zzzz").get_data(as_text=True)
    assert "Nothing matches that filter" in body
    assert "Nothing listed here yet" not in body


def test_the_detail_page_links_the_official_portal_first(client, app,
                                                          school):
    item = make_application(school, closes=date(2099, 1, 1))
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)

    assert "Apply on the official portal" in body
    assert item.official_portal_url in body
    # And it opens safely.
    assert 'rel="noopener noreferrer"' in body


def test_the_two_fees_are_never_added_together(client, app, school):
    """They are different transactions with different recipients."""
    item = make_application(school, closes=date(2099, 1, 1),
                            official_fee=250000, service_fee=500000,
                            assistance=True)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)

    assert "Institution's fee" in body
    assert "SolutionTee's fee" in body
    assert "2,500.00" in body
    assert "5,000.00" in body
    # 7,500.00 would be the two summed, which must never appear.
    assert "7,500.00" not in body and "7500.00" not in body


def test_an_unconfirmed_fee_says_so_rather_than_showing_zero(client, app,
                                                              school):
    item = make_application(school, closes=date(2099, 1, 1),
                            official_fee=None)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)
    assert "Not confirmed" in body
    assert "&#8358;0.00" not in body


def test_a_missing_date_renders_as_not_announced(client, app, school):
    item = make_application(school, opens=None, closes=None)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)
    assert body.count("Not announced") >= 2


def test_the_detail_page_always_shows_when_it_was_verified(client, app,
                                                            school):
    item = make_application(school, closes=date(2099, 1, 1),
                            verified_days_ago=0)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)
    assert "Checked against the official source today" in body
    assert item.source_url in body


def test_a_stale_listing_warns_rather_than_reassures(client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            verified_days_ago=200)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)
    assert "Check this yourself" in body
    assert "Verified<" not in body


def test_an_unpublished_application_is_404(client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            published=False)
    assert client.get(
        f"/admission/application/{item.public_id}").status_code == 404


def test_assistance_states_plainly_what_we_cannot_do(client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            assistance=True, service_fee=500000)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)
    # Collapsed: a sentence wrapping across source lines is not a change
    # of content, and asserting on the raw HTML would make the test fail
    # every time the template is re-indented.
    flat = " ".join(body.split())

    assert "What we cannot do" in flat
    assert "cannot submit on your behalf" in flat
    assert "cannot influence whether you are offered a place" in flat


def test_no_assistance_form_when_we_do_not_offer_help(client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            assistance=False)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)
    assert "We do not offer help with this one." in body
    assert 'id="assistance"' not in body


# ---------------------------------------------------------------------------
# Enquiries
# ---------------------------------------------------------------------------

def test_an_enquiry_is_recorded(client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            assistance=True)
    response = client.post(
        f"/admission/application/{item.public_id}/enquire",
        data={"full_name": "Ada Okoro", "email": "ada@example.test",
              "message": "Which subjects do I need?"},
        follow_redirects=True,
    )
    assert response.status_code == 200

    enquiry = db.session.query(AdmissionEnquiry).one()
    assert enquiry.full_name == "Ada Okoro"
    assert enquiry.application_id == item.id


def test_the_confirmation_repeats_where_applying_actually_happens(
        client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            assistance=True)
    response = client.post(
        f"/admission/application/{item.public_id}/enquire",
        data={"full_name": "Ada", "email": "ada@example.test"},
        follow_redirects=True,
    )
    body = response.get_data(as_text=True)
    assert "institution&#39;s own portal" in body or \
           "institution's own portal" in body


def test_an_enquiry_without_contact_details_is_refused(client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            assistance=True)
    client.post(f"/admission/application/{item.public_id}/enquire",
                data={"full_name": "", "email": ""}, follow_redirects=True)
    assert db.session.query(AdmissionEnquiry).count() == 0


def test_an_enquiry_on_an_unpublished_application_is_404(client, app,
                                                          school):
    item = make_application(school, closes=date(2099, 1, 1),
                            published=False)
    assert client.post(
        f"/admission/application/{item.public_id}/enquire",
        data={"full_name": "A", "email": "a@example.test"},
    ).status_code == 404


# ---------------------------------------------------------------------------
# Nothing is invented
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path", ["/admission/", "/admission/universities",
                                   "/admission/nursing"])
def test_admission_pages_state_no_dates_of_their_own(client, app, path):
    """A hard-coded deadline in a template is how somebody misses a year."""
    body = client.get(path).get_data(as_text=True)
    invented = re.search(r"\b\d{1,2}\s+(January|February|March|April|May|"
                         r"June|July|August|September|October|November|"
                         r"December)\s+20\d\d", body)
    assert invented is None, f"{path} states a date nobody supplied: {invented}"


def test_no_page_claims_solutiontee_admits_anyone(client, app, school):
    item = make_application(school, closes=date(2099, 1, 1),
                            assistance=True)
    for path in ("/admission/", "/admission/universities",
                 f"/admission/application/{item.public_id}"):
        body = client.get(path).get_data(as_text=True).lower()
        for claim in ("we admit", "guaranteed admission", "secure your place",
                      "we can get you in", "official jamb partner"):
            assert claim not in body, f"{path} claims: {claim}"


def test_money_is_formatted_with_thousands_separated(client, app, school):
    """250000.00 and 2500.00 are hard to tell apart at a glance.

    This is the number somebody is about to pay, so it is worth the
    comma.
    """
    item = make_application(school, closes=date(2099, 1, 1),
                            official_fee=2500000, assistance=True)
    body = client.get(
        f"/admission/application/{item.public_id}").get_data(as_text=True)
    assert "25,000.00" in body


def test_the_guidance_page_quotes_no_figures_of_its_own(client, app):
    """Cut-off marks and requirements change yearly and differ by school.

    The page explains the process; the institution's portal holds the
    numbers. A figure printed here would be wrong for somebody.
    """
    body = client.get("/admission/guidance").get_data(as_text=True)

    # No cut-off-shaped numbers, no fees, no dated deadlines.
    assert re.search(r"\bcut[- ]off\s*(mark\s*)?(of|is|:)?\s*\d", body, re.I) is None
    assert re.search(r"₦|&#8358;", body) is None
    assert re.search(r"\b\d{1,2}\s+(January|February|March|April|May|June|"
                     r"July|August|September|October|November|December)\s+20\d\d",
                     body) is None
    # And it says why there are none.
    assert "No numbers on this page" in body


def test_the_guidance_page_promises_nothing(client, app):
    body = client.get("/admission/guidance").get_data(as_text=True).lower()
    for claim in ("guaranteed", "we can get you", "secure your place",
                  "we admit"):
        assert claim not in body
