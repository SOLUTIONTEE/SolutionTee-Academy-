"""Courses, lessons and access control.

The property under test throughout: paid content is served only after
`lesson_access` allows it. A locked lesson is still *listed* - somebody
deciding whether to pay must see what they would get - but its body
never reaches an unpaid reader.
"""
from __future__ import annotations

from datetime import date

import pytest

from app.extensions import db
from app.models.courses import Course, Lesson, LessonKind, Module
from app.models.enums import RoleName
from app.models.payments import EnrolmentStatus, Offering, PaymentPlan
from app.services import accounts, courses, payments
from app.services.content import sanitise_html
from tests.test_payments import PRICE, StubGateway, success

SECRET_TEXT = "The examiner allocates two marks for the working."


@pytest.fixture
def gateway(app, monkeypatch):
    stub = StubGateway()
    monkeypatch.setattr(payments, "get_gateway", lambda: stub)
    monkeypatch.setattr("app.services.payments.gateway.get_gateway",
                        lambda: stub)
    return stub


@pytest.fixture
def offering(app):
    item = Offering(title="JAMB Online 2026", slug="jamb-online-2026",
                    programme_slug="jamb", mode="online",
                    price_kobo=PRICE, is_published=True)
    db.session.add(item)
    db.session.commit()
    db.session.add(PaymentPlan(offering_id=item.id, name="Full",
                               instalments=[{"percent": 100}],
                               is_default=True))
    db.session.commit()
    return item


@pytest.fixture
def course(app, offering):
    item = Course(title="JAMB Mathematics", slug="jamb-mathematics",
                  summary="Every topic on the syllabus.",
                  offering_id=offering.id, programme_slug="jamb",
                  is_published=True)
    db.session.add(item)
    db.session.commit()

    module = Module(course_id=item.id, title="Algebra", position=0)
    db.session.add(module)
    db.session.commit()

    db.session.add_all([
        Lesson(module_id=module.id, title="What algebra is for",
               slug="what-algebra-is-for", kind=LessonKind.TEXT,
               body_html="<p>A free sample.</p>", position=0,
               is_preview=True, is_published=True),
        Lesson(module_id=module.id, title="Quadratic equations",
               slug="quadratic-equations", kind=LessonKind.TEXT,
               body_html=f"<p>{SECRET_TEXT}</p>", position=1,
               is_preview=False, is_published=True),
        Lesson(module_id=module.id, title="Not finished yet",
               slug="not-finished-yet", kind=LessonKind.TEXT,
               body_html="<p>Draft.</p>", position=2,
               is_preview=False, is_published=False),
    ])
    db.session.commit()
    db.session.refresh(item)
    return item


def make_student(email="student@example.com"):
    result = accounts.register(
        email=email, full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=date(1998, 5, 1),
    )
    accounts.mark_email_verified(result.user)
    return result.user


@pytest.fixture
def student(app):
    return make_student()


@pytest.fixture
def paid_student(app, gateway, offering, student):
    enrolment = payments.enrol(student, offering)
    start = payments.start_payment(student, enrolment,
                                   callback_url="https://x.test/cb")
    gateway.next_verification = success(start.payment.amount_kobo)
    payments.settle(start.payment.reference)
    return student


def lesson_named(course: Course, slug: str) -> Lesson:
    return courses.get_lesson(course, slug)


# ---------------------------------------------------------------------------
# The access decision
# ---------------------------------------------------------------------------

def test_a_preview_lesson_is_open_to_everyone(app, course):
    access = courses.lesson_access(None, lesson_named(course,
                                                      "what-algebra-is-for"))
    assert access.allowed
    assert access.reason == "preview"


def test_a_paid_lesson_is_closed_to_an_anonymous_visitor(app, course):
    access = courses.lesson_access(None, lesson_named(course,
                                                      "quadratic-equations"))
    assert not access.allowed
    assert access.reason == "anonymous"
    assert access.payable


def test_a_paid_lesson_is_closed_to_a_signed_in_non_student(app, course,
                                                             student):
    access = courses.lesson_access(student,
                                   lesson_named(course, "quadratic-equations"))
    assert not access.allowed
    assert access.reason == "not_enrolled"


def test_enrolling_without_paying_does_not_open_it(app, course, offering,
                                                   student):
    payments.enrol(student, offering)
    access = courses.lesson_access(student,
                                   lesson_named(course, "quadratic-equations"))
    assert not access.allowed
    assert access.reason == "unpaid"
    # The message tells them what is outstanding rather than just "no".
    assert "outstanding" in access.message


def test_paying_opens_it(app, course, paid_student):
    access = courses.lesson_access(paid_student,
                                   lesson_named(course, "quadratic-equations"))
    assert access.allowed
    assert access.reason == "enrolled"


def test_a_cancelled_enrolment_closes_it_again(app, course, offering,
                                               paid_student):
    enrolment = courses.enrolment_for(paid_student, course)
    enrolment.status = EnrolmentStatus.CANCELLED
    db.session.commit()

    access = courses.lesson_access(paid_student,
                                   lesson_named(course, "quadratic-equations"))
    assert not access.allowed
    assert access.reason == "cancelled"


def test_an_unpublished_lesson_is_closed_even_to_a_payer(app, course,
                                                         paid_student):
    """Paying does not grant early sight of unfinished material."""
    access = courses.lesson_access(paid_student,
                                   lesson_named(course, "not-finished-yet"))
    assert not access.allowed
    assert access.reason == "unpublished"


def test_an_unpublished_course_closes_its_preview_lessons_too(app, course,
                                                              paid_student):
    course.is_published = False
    db.session.commit()
    for slug in ("what-algebra-is-for", "quadratic-equations"):
        assert not courses.lesson_access(paid_student,
                                         lesson_named(course, slug)).allowed


def test_a_course_with_no_offering_is_open(app, course):
    """Nothing sells it, so nothing gates it."""
    course.offering_id = None
    db.session.commit()
    assert courses.lesson_access(None,
                                 lesson_named(course,
                                              "quadratic-equations")).allowed


def test_paying_for_one_offering_does_not_open_another(app, gateway,
                                                        paid_student):
    """Access is per offering, not a blanket flag on the account."""
    other_offering = Offering(title="WAEC Physical", slug="waec-physical",
                              programme_slug="waec", mode="physical",
                              price_kobo=PRICE, is_published=True)
    db.session.add(other_offering)
    db.session.commit()

    other_course = Course(title="WAEC Biology", slug="waec-biology",
                          offering_id=other_offering.id, is_published=True)
    db.session.add(other_course)
    db.session.commit()
    module = Module(course_id=other_course.id, title="Cells", position=0)
    db.session.add(module)
    db.session.commit()
    db.session.add(Lesson(module_id=module.id, title="Cell structure",
                          slug="cell-structure", body_html="<p>Paid.</p>",
                          position=0, is_published=True))
    db.session.commit()
    db.session.refresh(other_course)

    access = courses.lesson_access(paid_student,
                                   lesson_named(other_course,
                                                "cell-structure"))
    assert not access.allowed
    assert access.reason == "not_enrolled"


# ---------------------------------------------------------------------------
# The routes
# ---------------------------------------------------------------------------

def test_the_curriculum_is_visible_to_everyone(client, app, course):
    """Somebody deciding whether to pay must see what they would get."""
    body = client.get(f"/academy/{course.slug}").get_data(as_text=True)
    assert "Quadratic equations" in body     # the locked lesson is named
    assert "Algebra" in body                  # so is its module
    assert SECRET_TEXT not in body            # but not its content


def test_a_locked_lesson_body_never_reaches_an_anonymous_visitor(client, app,
                                                                 course):
    response = client.get(f"/academy/{course.slug}/quadratic-equations")
    assert response.status_code == 403
    assert SECRET_TEXT not in response.get_data(as_text=True)


def test_a_locked_lesson_explains_what_opens_it(client, app, course):
    """403 with no explanation is how people give up."""
    body = client.get(
        f"/academy/{course.slug}/quadratic-equations").get_data(as_text=True)
    assert "Sign in" in body
    assert "curriculum" in body


def test_a_preview_lesson_opens_without_signing_in(client, app, course):
    response = client.get(f"/academy/{course.slug}/what-algebra-is-for")
    assert response.status_code == 200
    assert "A free sample." in response.get_data(as_text=True)


def test_an_unpaid_student_still_cannot_read_it(client, app, course,
                                                offering, student, sign_in):
    payments.enrol(student, offering)
    sign_in(student)

    response = client.get(f"/academy/{course.slug}/quadratic-equations")
    assert response.status_code == 403
    assert SECRET_TEXT not in response.get_data(as_text=True)


def test_a_paid_student_reads_it(client, app, course, paid_student, sign_in):
    sign_in(paid_student)
    response = client.get(f"/academy/{course.slug}/quadratic-equations")
    assert response.status_code == 200
    assert SECRET_TEXT in response.get_data(as_text=True)


def test_an_unpublished_lesson_is_403_not_a_leak(client, app, course,
                                                 paid_student, sign_in):
    sign_in(paid_student)
    response = client.get(f"/academy/{course.slug}/not-finished-yet")
    assert response.status_code == 403
    assert "Draft." not in response.get_data(as_text=True)


def test_a_lesson_cannot_be_reached_through_another_course_url(
        client, app, course, paid_student, sign_in):
    """Otherwise a paid-for lesson opens through an unpaid course's URL."""
    other = Course(title="Free Course", slug="free-course",
                   offering_id=None, is_published=True)
    db.session.add(other)
    db.session.commit()
    db.session.add(Module(course_id=other.id, title="Intro", position=0))
    db.session.commit()

    sign_in(paid_student)
    response = client.get("/academy/free-course/quadratic-equations")
    assert response.status_code == 404


def test_an_unknown_course_or_lesson_is_404(client, app, course):
    assert client.get("/academy/nope").status_code == 404
    assert client.get(f"/academy/{course.slug}/nope").status_code == 404


def test_an_unpublished_course_is_404_not_403(client, app, course):
    """Its existence is not disclosed at all."""
    course.is_published = False
    db.session.commit()
    assert client.get(f"/academy/{course.slug}").status_code == 404


# ---------------------------------------------------------------------------
# Progress
# ---------------------------------------------------------------------------

def test_opening_a_lesson_records_it_once(app, course, paid_student):
    item = lesson_named(course, "quadratic-equations")
    first = courses.mark_started(paid_student, item)
    second = courses.mark_started(paid_student, item)
    assert first.id == second.id


def test_completing_a_lesson_does_not_move_the_timestamp(app, course,
                                                         paid_student):
    """Revisiting an old lesson must not look like finishing it again."""
    item = lesson_named(course, "quadratic-equations")
    first = courses.mark_complete(paid_student, item)
    stamp = first.completed_at
    again = courses.mark_complete(paid_student, item)
    assert again.completed_at == stamp


def test_progress_counts_only_published_lessons(app, course, paid_student):
    progress = courses.course_progress(paid_student, course)
    # Two published of the three defined.
    assert progress.total == 2
    assert progress.completed == 0

    courses.mark_complete(paid_student, lesson_named(course,
                                                     "quadratic-equations"))
    assert courses.course_progress(paid_student, course).completed == 1
    assert courses.course_progress(paid_student, course).percent == 50


def test_completing_through_the_route_requires_current_access(
        client, app, course, offering, student, sign_in):
    """Access is re-checked, not assumed from having loaded the page."""
    payments.enrol(student, offering)          # enrolled but unpaid
    sign_in(student)

    response = client.post(
        f"/academy/{course.slug}/quadratic-equations/complete")
    assert response.status_code == 403
    assert courses.course_progress(student, course).completed == 0


def test_completing_moves_on_to_the_next_lesson(client, app, course,
                                                paid_student, sign_in):
    sign_in(paid_student)
    response = client.post(
        f"/academy/{course.slug}/what-algebra-is-for/complete",
        follow_redirects=False)
    assert response.status_code == 302
    assert "quadratic-equations" in response.headers["Location"]


def test_anonymous_cannot_record_progress(client, app, course):
    response = client.post(
        f"/academy/{course.slug}/what-algebra-is-for/complete")
    assert response.status_code in (302, 401)


# ---------------------------------------------------------------------------
# Stored content is sanitised
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("attack,must_not_contain", [
    ("<script>alert(1)</script>", "<script"),
    ("<img src=x onerror=alert(1)>", "onerror"),
    ("<p onclick='steal()'>hi</p>", "onclick"),
    ('<a href="javascript:alert(1)">x</a>', "javascript:"),
    ('<iframe src="https://evil.test"></iframe>', "<iframe"),
    ('<p style="position:fixed">x</p>', "style="),
])
def test_lesson_html_is_sanitised(app, attack, must_not_contain):
    """Staff-authored is not the same as trustworthy.

    A compromised staff account must not become stored XSS against every
    student in the centre.
    """
    assert must_not_contain not in sanitise_html(attack)


def test_sanitising_keeps_ordinary_prose_intact(app):
    raw = ('<h2>Working</h2><p>Show <strong>every</strong> step.</p>'
           '<ul><li>First</li></ul>')
    assert sanitise_html(raw) == raw


def test_links_that_open_a_new_tab_are_hardened(app):
    """Without rel=noopener the opened page can navigate this one."""
    cleaned = sanitise_html('<a href="https://x.test" target="_blank">go</a>')
    assert "noopener" in cleaned
    assert "noreferrer" in cleaned
