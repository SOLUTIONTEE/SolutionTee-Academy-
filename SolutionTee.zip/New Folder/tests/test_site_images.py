"""Site image slots: assignment, usage, and the picker endpoint.

This is where the media library meets the public site, so the tests
follow one image all the way through: uploaded, picked, assigned,
rendered, and then protected from deletion.
"""
from __future__ import annotations

import pytest

from app.content.site_slots import SLOTS, SLOTS_BY_KEY
from app.extensions import db
from app.models.media import Media
from app.models.site import SiteImage
from app.services import media as media_service
from app.services import site_images
from tests.conftest import make_image_bytes


@pytest.fixture
def stored_image(app, admin_user):
    return media_service.upload_image(
        make_image_bytes(1800, 1200), "classroom.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )


@pytest.fixture
def second_image(app, admin_user):
    return media_service.upload_image(
        make_image_bytes(1800, 1200, colour=(200, 40, 40)), "cbt-lab.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )


# ---------------------------------------------------------------------------
# Slot definitions
# ---------------------------------------------------------------------------

def test_every_slot_has_real_guidance():
    """"Add an engaging image" helps nobody choose a photograph."""
    for slot in SLOTS:
        assert slot.guidance and len(slot.guidance) > 30
        assert slot.location
        assert slot.display_width > 0


def test_slot_keys_are_unique():
    keys = [slot.key for slot in SLOTS]
    assert len(keys) == len(set(keys))


def test_assigning_an_unknown_slot_is_refused(app, stored_image):
    with pytest.raises(site_images.UnknownSlotError):
        site_images.assign("homepage.nonexistent", stored_image)


# ---------------------------------------------------------------------------
# Assignment
# ---------------------------------------------------------------------------

def test_assignment_round_trips(app, stored_image, admin_user):
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    assert site_images.get("homepage.hero").id == stored_image.id


def test_unassigned_slots_report_none(app):
    assignments = site_images.all_assignments()
    assert set(assignments) == set(SLOTS_BY_KEY)
    assert all(value is None for value in assignments.values())


def test_assignment_records_usage_so_the_image_cannot_be_deleted(
        app, stored_image, admin_user):
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    db.session.refresh(stored_image)

    assert len(stored_image.usages) == 1
    assert stored_image.usages[0].content_type == "site_image"
    assert stored_image.usages[0].label == "Homepage hero"

    with pytest.raises(media_service.MediaInUseError):
        media_service.delete(stored_image)


def test_replacing_an_image_moves_the_usage_with_it(app, stored_image,
                                                    second_image, admin_user):
    """The old occupant must stop counting as in use.

    Otherwise an image swapped out months ago is still 'used' and can
    never be deleted.
    """
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    site_images.assign("homepage.hero", second_image, actor=admin_user)

    db.session.refresh(stored_image)
    db.session.refresh(second_image)

    assert stored_image.usages == []
    assert len(second_image.usages) == 1
    assert site_images.get("homepage.hero").id == second_image.id

    # The replaced image is now free to delete.
    media_service.delete(stored_image)


def test_clearing_a_slot_releases_the_image(app, stored_image, admin_user):
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    site_images.clear("homepage.hero", actor=admin_user)

    db.session.refresh(stored_image)
    assert site_images.get("homepage.hero") is None
    assert stored_image.usages == []
    media_service.delete(stored_image)  # must not raise


def test_one_image_can_fill_several_slots(app, stored_image, admin_user):
    site_images.assign("learning.physical", stored_image, actor=admin_user)
    site_images.assign("learning.hybrid", stored_image, actor=admin_user)

    db.session.refresh(stored_image)
    assert len(stored_image.usages) == 2
    assert db.session.query(Media).count() == 1


def test_archived_images_fall_back_to_the_placeholder(app, stored_image,
                                                      admin_user):
    """An archived image must not keep rendering on the public site."""
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    media_service.archive(stored_image)

    assert site_images.get("homepage.hero") is None
    assert site_images.all_assignments()["homepage.hero"] is None


def test_force_deleting_an_assigned_image_leaves_the_slot_intact(
        app, stored_image, admin_user):
    """The slot survives so the page degrades to its placeholder."""
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    media_service.delete(stored_image, force=True)

    row = db.session.query(SiteImage).filter_by(slot="homepage.hero").one()
    assert row.media_id is None
    assert site_images.get("homepage.hero") is None


# ---------------------------------------------------------------------------
# The admin page
# ---------------------------------------------------------------------------

def test_page_requires_content_edit(client, sign_in, instructor_user,
                                    student_user):
    sign_in(student_user)
    assert client.get("/admin/site-images/").status_code == 403

    # An instructor may upload media but does not edit site content.
    sign_in(instructor_user)
    assert client.get("/admin/site-images/").status_code == 403


def test_anonymous_is_sent_to_sign_in(client):
    response = client.get("/admin/site-images/")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


def test_page_lists_every_slot_with_its_guidance(client, sign_in, admin_user):
    sign_in(admin_user)
    body = client.get("/admin/site-images/").get_data(as_text=True)
    for slot in SLOTS:
        assert slot.name in body
        assert slot.location in body


def test_saving_assigns_and_clears(client, sign_in, admin_user, stored_image):
    sign_in(admin_user)

    payload = {slot.key: "" for slot in SLOTS}
    payload["homepage.hero"] = stored_image.public_id
    client.post("/admin/site-images/", data=payload, follow_redirects=True)
    assert site_images.get("homepage.hero").id == stored_image.id

    payload["homepage.hero"] = ""
    client.post("/admin/site-images/", data=payload, follow_redirects=True)
    assert site_images.get("homepage.hero") is None


def test_saving_an_unknown_image_leaves_the_slot_alone(
        client, sign_in, admin_user, stored_image):
    """A stale id must not silently wipe a working assignment."""
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    sign_in(admin_user)

    payload = {slot.key: "" for slot in SLOTS}
    payload["homepage.hero"] = "not-a-real-public-id"
    response = client.post("/admin/site-images/", data=payload,
                           follow_redirects=True)

    assert b"no longer exist" in response.data
    assert site_images.get("homepage.hero").id == stored_image.id


def test_slots_absent_from_the_form_are_untouched(client, sign_in, admin_user,
                                                  stored_image):
    site_images.assign("homepage.cbt", stored_image, actor=admin_user)
    sign_in(admin_user)

    # Only the hero is submitted; the CBT slot is not in the payload.
    client.post("/admin/site-images/",
                data={"homepage.hero": ""}, follow_redirects=True)

    assert site_images.get("homepage.cbt").id == stored_image.id


# ---------------------------------------------------------------------------
# The picker
# ---------------------------------------------------------------------------

def test_picker_requires_permission(client, sign_in, student_user):
    sign_in(student_user)
    assert client.get("/admin/media/picker").status_code == 403


def test_picker_returns_selectable_cards(client, sign_in, admin_user,
                                         stored_image):
    sign_in(admin_user)
    body = client.get("/admin/media/picker").get_data(as_text=True)

    assert "data-picker-choice" in body
    assert f'data-media-id="{stored_image.public_id}"' in body
    assert "data-media-url=" in body
    assert stored_image.original_filename in body


def test_picker_search_and_folder_filters_apply(client, sign_in, admin_user,
                                                stored_image, second_image):
    sign_in(admin_user)

    assert stored_image.public_id in client.get(
        "/admin/media/picker?q=classroom").get_data(as_text=True)
    assert second_image.public_id not in client.get(
        "/admin/media/picker?q=classroom").get_data(as_text=True)


def test_picker_paginates(client, sign_in, admin_user):
    for index in range(30):
        media_service.upload_image(
            make_image_bytes(500, 400, colour=(index * 7 % 255, 20, 40)),
            f"image-{index}.jpg", uploaded_by_id=admin_user.id,
            max_bytes=10**7,
        )
    sign_in(admin_user)
    body = client.get("/admin/media/picker").get_data(as_text=True)
    # 24 per page, so a 30-image library must offer more.
    assert "data-picker-more" in body


def test_picker_flags_images_without_alt_text(client, sign_in, admin_user,
                                              stored_image):
    sign_in(admin_user)
    assert "No alt text" in client.get(
        "/admin/media/picker").get_data(as_text=True)

    media_service.update_metadata(stored_image, alt_text="A classroom")
    assert "No alt text" not in client.get(
        "/admin/media/picker").get_data(as_text=True)


def test_picker_offers_the_medium_variant_not_the_original(
        client, sign_in, admin_user, stored_image):
    """Selecting must not put a multi-megabyte original into a form."""
    sign_in(admin_user)
    body = client.get("/admin/media/picker").get_data(as_text=True)
    assert stored_image.variants["medium"]["key"] in body


# ---------------------------------------------------------------------------
# The public site
# ---------------------------------------------------------------------------

def test_homepage_shows_the_placeholder_until_a_slot_is_filled(client):
    body = client.get("/").get_data(as_text=True)
    assert "media--awaiting" in body
    assert "Assign one under Site images" in body


def test_homepage_renders_the_assigned_image(client, stored_image,
                                             admin_user):
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    body = client.get("/").get_data(as_text=True)

    assert stored_image.variants["medium"]["key"] in body
    # The hero is the largest contentful paint, so it is not deferred.
    assert 'fetchpriority="high"' in body


def test_assigned_images_carry_srcset_and_dimensions(client, stored_image,
                                                     admin_user):
    site_images.assign("homepage.hero", stored_image, actor=admin_user)
    body = client.get("/").get_data(as_text=True)

    assert "srcset=" in body and "sizes=" in body
    assert "400w" in body and "1000w" in body


def test_learning_pages_use_their_own_slot(client, stored_image, admin_user):
    site_images.assign("learning.online", stored_image, actor=admin_user)

    online = client.get("/learning/online").get_data(as_text=True)
    physical = client.get("/learning/physical").get_data(as_text=True)

    assert stored_image.variants["medium"]["key"] in online
    assert stored_image.variants["medium"]["key"] not in physical
    assert "media--awaiting" in physical


def test_alt_text_reaches_the_public_page(client, stored_image, admin_user):
    media_service.update_metadata(stored_image,
                                  alt_text="Students in a JAMB class")
    site_images.assign("homepage.hero", stored_image, actor=admin_user)

    body = client.get("/").get_data(as_text=True)
    assert 'alt="Students in a JAMB class"' in body


def test_a_decorative_image_renders_an_empty_alt(client, stored_image,
                                                 admin_user):
    media_service.update_metadata(stored_image, alt_text="Something",
                                  is_decorative=True)
    site_images.assign("homepage.hero", stored_image, actor=admin_user)

    body = client.get("/").get_data(as_text=True)
    assert 'alt=""' in body
    assert "Something" not in body
