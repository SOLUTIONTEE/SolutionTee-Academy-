"""Contact enquiries.

The property that matters: an enquiry is never lost. It is stored before
anything is emailed, so a mail failure costs a notification rather than a
customer.
"""
from __future__ import annotations

import pytest

from app.extensions import db
from app.models.contact import ContactMessage, ContactStatus, ContactTopic
from app.services import contact


@pytest.fixture
def sent(client, app):
    """Post a valid enquiry through the real route."""
    def _send(**overrides):
        data = {
            "full_name": "Ada Okoro",
            "email": "ada@example.test",
            "topic": ContactTopic.PROGRAMME,
            "subject": "JAMB classes",
            "message": "Which JAMB class starts soonest, and what does it cost?",
        }
        data.update(overrides)
        return client.post("/contact", data=data, follow_redirects=True)
    return _send


# ---------------------------------------------------------------------------
# Nothing is lost
# ---------------------------------------------------------------------------

def test_an_enquiry_is_stored(app, sent):
    response = sent()
    assert response.status_code == 200

    entry = db.session.query(ContactMessage).one()
    assert entry.full_name == "Ada Okoro"
    assert entry.email == "ada@example.test"
    assert entry.status == ContactStatus.NEW


def test_the_enquiry_survives_a_mail_failure(app, monkeypatch):
    """The whole reason it is stored first.

    An enquiry that only ever existed inside a failed email is a customer
    nobody knows they lost.
    """
    def explode(_message):
        raise RuntimeError("Brevo is down")

    monkeypatch.setattr(contact.mail, "send", explode)

    entry = contact.record(
        full_name="Ada", email="ada@example.test",
        message="My message is long enough to count.",
    )

    assert db.session.query(ContactMessage).count() == 1
    # Stored, but flagged so staff can see nobody was told.
    assert entry.was_forwarded is False


def test_a_failed_forward_is_surfaced_for_staff(app, monkeypatch):
    monkeypatch.setattr(contact.mail, "send",
                        lambda _m: (_ for _ in ()).throw(RuntimeError("x")))
    contact.record(full_name="Ada", email="ada@example.test",
                   message="Long enough to be accepted.")

    unsent = contact.not_forwarded()
    assert len(unsent) == 1


def test_the_sender_is_thanked_even_when_mail_fails(client, app, monkeypatch,
                                                     sent):
    """From their side the message HAS been received: it is stored.

    Showing an error because our provider blinked would only make them
    send it twice.
    """
    monkeypatch.setattr(contact.mail, "send",
                        lambda _m: (_ for _ in ()).throw(RuntimeError("x")))
    response = sent()
    assert response.status_code == 200
    assert b"we have it" in response.data.lower()


def test_the_reference_is_shown_so_it_can_be_quoted(app, sent):
    response = sent()
    entry = db.session.query(ContactMessage).one()
    assert entry.public_id.encode() in response.data


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("field,value,expected", [
    ("full_name", "", "name"),
    ("email", "", "email"),
    ("email", "not-an-email", "email"),
    ("message", "short", "more"),
])
def test_incomplete_enquiries_are_refused_with_a_reason(app, field, value,
                                                        expected):
    data = {"full_name": "Ada", "email": "ada@example.test",
            "message": "Long enough to be accepted normally."}
    data[field] = value

    with pytest.raises(contact.ContactError, match=expected):
        contact.validate(**data)


def test_a_refused_enquiry_is_not_stored(client, app, sent):
    sent(message="too short")
    assert db.session.query(ContactMessage).count() == 0


def test_a_refused_enquiry_keeps_what_was_typed(client, app):
    """Retyping a long message because one field was wrong is infuriating."""
    response = client.post("/contact", data={
        "full_name": "Ada Okoro", "email": "", "topic": "programme",
        "subject": "JAMB", "message": "A message worth not losing.",
    })
    body = response.get_data(as_text=True)
    assert "A message worth not losing." in body
    assert "Ada Okoro" in body


def test_an_unknown_topic_falls_back_rather_than_failing(app):
    entry = contact.record(full_name="Ada", email="a@example.test",
                           message="Long enough to be accepted.",
                           topic="nonsense")
    assert entry.topic == ContactTopic.OTHER


# ---------------------------------------------------------------------------
# Bot protection
# ---------------------------------------------------------------------------

def test_a_failed_turnstile_check_stores_nothing(client, app, monkeypatch):
    """A public form with no bot protection fills the inbox with rubbish
    until somebody stops reading it — at which point a real enquiry gets
    missed."""
    from app.blueprints.main import routes

    monkeypatch.setattr(routes.turnstile, "verify",
                        lambda *a, **k: False)

    response = client.post("/contact", data={
        "full_name": "Bot", "email": "bot@example.test",
        "message": "Buy cheap watches from this website today.",
    })
    assert response.status_code == 400
    assert db.session.query(ContactMessage).count() == 0


# ---------------------------------------------------------------------------
# Staff side
# ---------------------------------------------------------------------------

def test_a_signed_in_sender_is_linked_to_their_account(client, app, sign_in,
                                                        student_user, sent):
    sign_in(student_user)
    sent()
    entry = db.session.query(ContactMessage).one()
    assert entry.user_id == student_user.id


def test_marking_replied_records_when_and_who(app, admin_user):
    entry = contact.record(full_name="Ada", email="a@example.test",
                           message="Long enough to be accepted.")
    contact.mark(entry, ContactStatus.REPLIED, actor=admin_user,
                 note="Sent the timetable")

    assert entry.status == ContactStatus.REPLIED
    assert entry.replied_at is not None
    assert entry.handled_by_id == admin_user.id
    assert entry.internal_note == "Sent the timetable"


def test_an_unknown_status_is_refused(app):
    entry = contact.record(full_name="Ada", email="a@example.test",
                           message="Long enough to be accepted.")
    with pytest.raises(contact.ContactError):
        contact.mark(entry, "banana")


def test_unanswered_count_tracks_new_messages(app, admin_user):
    for index in range(3):
        contact.record(full_name=f"Person {index}",
                       email=f"p{index}@example.test",
                       message="Long enough to be accepted.")
    assert contact.unanswered_count() == 3

    first = contact.browse()[0]
    contact.mark(first, ContactStatus.REPLIED, actor=admin_user)
    assert contact.unanswered_count() == 2


def test_the_internal_note_never_reaches_the_sender(app, admin_user, client):
    entry = contact.record(full_name="Ada", email="a@example.test",
                           message="Long enough to be accepted.")
    contact.mark(entry, ContactStatus.CLOSED, actor=admin_user,
                 note="Time waster, do not chase")

    body = client.get("/contact").get_data(as_text=True)
    assert "Time waster" not in body


# ---------------------------------------------------------------------------
# The page itself
# ---------------------------------------------------------------------------

def test_the_contact_page_invents_no_phone_number_or_address(client, app):
    """None have been supplied, and a wrong one sends somebody to the
    wrong place."""
    import re

    body = client.get("/contact").get_data(as_text=True)
    assert re.search(r"\+234[\s\d-]{7,}", body) is None
    assert "Not published here yet" in body


def test_the_contact_page_offers_every_topic(client, app):
    body = client.get("/contact").get_data(as_text=True)
    for label in ContactTopic.LABELS.values():
        assert label in body
