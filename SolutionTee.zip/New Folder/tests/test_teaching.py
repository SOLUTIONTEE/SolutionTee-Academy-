"""The tutor workspace.

The property worth testing hardest is not that the page renders: it is
that a tutor sees their own students and nobody else's, and cannot edit
another tutor's course. The permission on the decorator decides who gets
a workspace; ownership decides what is in it, and those are different
questions.
"""
from __future__ import annotations

import pytest

from app.extensions import db
from app.models.courses import Course, Lesson, Module
from app.models.enums import AccountStatus, RoleName
from app.models.rbac import Role
from app.models.user import User
from app.services import teaching


def _user(email: str, role: str, name: str = "Tutor") -> User:
    user = User(email=email, full_name=name, password_hash="x",
                status=AccountStatus.ACTIVE)
    user.roles.append(
        db.session.query(Role).filter_by(name=role).one()
    )
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def tutor(app):
    return _user("tutor@example.test", RoleName.INSTRUCTOR, "First Tutor")


@pytest.fixture
def other_tutor(app):
    return _user("other@example.test", RoleName.INSTRUCTOR, "Second Tutor")


def _course(instructor, title="A course", slug=None, published=True) -> Course:
    course = Course(title=title, slug=slug or title.lower().replace(" ", "-"),
                    instructor_id=instructor.id, is_published=published)
    db.session.add(course)
    db.session.commit()
    return course


# ---------------------------------------------------------------------------
# Scope
# ---------------------------------------------------------------------------

def test_a_tutor_sees_only_their_own_courses(app, tutor, other_tutor):
    mine = _course(tutor, "Mine", "mine")
    _course(other_tutor, "Theirs", "theirs")

    titles = [c.title for c in teaching.courses_taught_by(tutor)]
    assert titles == [mine.title]


def test_a_tutor_with_no_courses_sees_nobody(app, tutor, student_user):
    """The empty-list trap.

    An `IN ()` built from an empty course list is the difference between
    a tutor seeing nobody and a tutor seeing every student in the academy,
    and it fails silently in the direction that leaks.
    """
    assert teaching.students_of(tutor) == []


def test_an_admin_sees_the_whole_academy(app, tutor, admin_user):
    _course(tutor, "Mine", "mine")
    assert len(teaching.courses_taught_by(admin_user)) == 1
    assert teaching.is_privileged(admin_user)
    assert not teaching.is_privileged(tutor)


# ---------------------------------------------------------------------------
# Ownership
# ---------------------------------------------------------------------------

def test_a_tutor_cannot_edit_another_tutors_course(app, tutor, other_tutor):
    theirs = _course(other_tutor, "Theirs", "theirs")

    assert not teaching.can_edit(theirs, tutor)
    with pytest.raises(teaching.TeachingError):
        teaching.assert_can_edit(theirs, tutor)


def test_the_route_refuses_another_tutors_course(client, app, sign_in,
                                                  tutor, other_tutor):
    theirs = _course(other_tutor, "Theirs", "theirs")
    sign_in(tutor)

    assert client.get(
        f"/teaching/courses/{theirs.public_id}").status_code == 403
    assert client.post(
        f"/teaching/courses/{theirs.public_id}/modules",
        data={"title": "Injected"}).status_code == 403

    db.session.refresh(theirs)
    assert theirs.modules == []


def test_a_module_from_another_course_cannot_be_written_into(client, app,
                                                             sign_in, tutor,
                                                             other_tutor):
    """A course of your own plus somebody else's module id.

    The ownership check passes - the course really is yours - so the only
    thing standing between the request and another tutor's course is the
    module-belongs-to-this-course check.
    """
    mine = _course(tutor, "Mine", "mine")
    theirs = _course(other_tutor, "Theirs", "theirs")
    their_module = teaching.add_module(theirs, title="Their section")

    sign_in(tutor)
    response = client.post(
        f"/teaching/courses/{mine.public_id}/modules/{their_module.id}/lessons",
        data={"title": "Injected", "kind": "text"},
    )
    assert response.status_code == 404
    db.session.refresh(their_module)
    assert their_module.lessons == []


def test_a_student_cannot_reach_the_workspace(client, app, sign_in,
                                              student_user):
    sign_in(student_user)
    assert client.get("/teaching/").status_code == 403
    assert client.get("/teaching/students").status_code == 403


def test_anonymous_is_sent_to_sign_in(client, app):
    response = client.get("/teaching/")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


# ---------------------------------------------------------------------------
# Building
# ---------------------------------------------------------------------------

def test_building_and_publishing_are_separate_permissions(client, app,
                                                          sign_in, tutor):
    """An instructor writes the course; an administrator puts it out."""
    mine = _course(tutor, "Mine", "mine", published=False)
    sign_in(tutor)

    # Building: allowed.
    client.post(f"/teaching/courses/{mine.public_id}/modules",
                data={"title": "Section one"}, follow_redirects=True)
    db.session.refresh(mine)
    assert [m.title for m in mine.modules] == ["Section one"]

    # Publishing: refused, and nothing changes.
    assert client.post(
        f"/teaching/courses/{mine.public_id}/publish").status_code == 403
    db.session.refresh(mine)
    assert mine.is_published is False


def test_the_editor_says_why_publishing_is_unavailable(client, app, sign_in,
                                                        tutor):
    """A missing button with no explanation is how people give up."""
    mine = _course(tutor, "Mine", "mine", published=False)
    sign_in(tutor)

    body = client.get(
        f"/teaching/courses/{mine.public_id}").get_data(as_text=True)
    assert "teaching.publish" in body
    assert "Ask an administrator" in body


def test_lessons_get_a_unique_slug(app, tutor, other_tutor):
    """Lesson slugs are unique across the whole table, not per course.

    Regression: add_lesson set no slug at all, and the insert died on a
    NOT NULL constraint - a 500 on a form that looked like it had worked.
    """
    mine = _course(tutor, "Mine", "mine")
    theirs = _course(other_tutor, "Theirs", "theirs")
    my_module = teaching.add_module(mine, title="One")
    their_module = teaching.add_module(theirs, title="One")

    first = teaching.add_lesson(my_module, title="Introduction", kind="text")
    second = teaching.add_lesson(their_module, title="Introduction",
                                 kind="text")

    assert first.slug
    assert second.slug
    assert first.slug != second.slug


def test_positions_survive_a_deletion(app, tutor):
    """max()+1, not len(). After a delete those disagree, and len() hands
    the new row a position an existing row already holds."""
    mine = _course(tutor, "Mine", "mine")
    first = teaching.add_module(mine, title="One")
    second = teaching.add_module(mine, title="Two")
    assert [first.position, second.position] == [0, 1]

    db.session.delete(first)
    db.session.commit()
    db.session.refresh(mine)

    third = teaching.add_module(mine, title="Three")
    positions = sorted(m.position for m in mine.modules)
    assert len(positions) == len(set(positions)), "positions collided"
    assert third.position == 2


def test_a_course_with_no_offering_reports_no_enrolments(app, tutor):
    mine = _course(tutor, "Mine", "mine")
    assert mine.offering_id is None
    assert teaching.enrolment_count(mine) == 0


# ---------------------------------------------------------------------------
# Speaking to a student
# ---------------------------------------------------------------------------

def _enrol(student, course):
    """Put a student on a course's offering so the tutor teaches them."""
    from app.models.payments import (
        Enrolment, EnrolmentStatus, Offering, PaymentPlan,
    )
    offering = Offering(title="An offering", slug="an-offering",
                        programme_slug="jamb", mode="online",
                        price_kobo=1000, is_published=True)
    db.session.add(offering)
    db.session.flush()
    course.offering_id = offering.id
    db.session.add(Enrolment(user_id=student.id, offering_id=offering.id,
                             status=EnrolmentStatus.ACTIVE,
                             agreed_price_kobo=1000))
    db.session.commit()


def test_a_tutor_can_open_a_conversation_with_their_student(
        client, app, sign_in, tutor, student_user):
    from app.services import messaging

    course = _course(tutor, "Mine", "mine")
    _enrol(student_user, course)
    sign_in(tutor)

    response = client.post(
        f"/teaching/students/{student_user.public_id}/message")
    assert response.status_code == 302
    assert "/messages/" in response.headers["Location"]

    conversation = messaging.direct_between(tutor, student_user)
    assert conversation is not None
    assert messaging.can_read(conversation, student_user)


def test_clicking_twice_does_not_create_two_threads(client, app, sign_in,
                                                     tutor, student_user):
    from app.models.messaging import Conversation

    course = _course(tutor, "Mine", "mine")
    _enrol(student_user, course)
    sign_in(tutor)

    for _ in range(2):
        client.post(f"/teaching/students/{student_user.public_id}/message")

    assert db.session.query(Conversation).count() == 1


def test_a_tutor_cannot_message_somebody_elses_student(client, app, sign_in,
                                                        tutor, other_tutor,
                                                        student_user):
    """Guessing an id must not be enough.

    The ownership check is the same query the student list is built
    from, so somebody who is not on your list cannot be reached.
    """
    theirs = _course(other_tutor, "Theirs", "theirs")
    _enrol(student_user, theirs)
    sign_in(tutor)

    response = client.post(
        f"/teaching/students/{student_user.public_id}/message")
    assert response.status_code == 403
