"""Messages.

The property worth testing hardest: access is participation, and nothing
else. There is no staff override, so a tutor cannot open a student's
conversation with the office, and an administrator cannot open a thread
they were never added to.

That is not a theoretical concern. The obvious "staff can see everything"
shortcut makes the first support conversation a student has *about* a
tutor readable by that tutor.
"""
from __future__ import annotations

import pytest

from app.extensions import db
from app.models.enums import AccountStatus, RoleName
from app.models.messaging import Conversation, ConversationKind, Message
from app.models.rbac import Role
from app.models.user import User
from app.services import messaging


def _user(email: str, role: str, name: str) -> User:
    user = User(email=email, full_name=name, password_hash="x",
                status=AccountStatus.ACTIVE)
    user.roles.append(db.session.query(Role).filter_by(name=role).one())
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def tutor(app):
    return _user("tutor-msg@example.test", RoleName.INSTRUCTOR, "A Tutor")


@pytest.fixture
def student(app):
    return _user("student-msg@example.test", RoleName.STUDENT, "A Student")


@pytest.fixture
def outsider(app):
    return _user("outsider-msg@example.test", RoleName.STUDENT, "Somebody Else")


@pytest.fixture
def room(app, tutor, student):
    return messaging.start(creator=tutor, participants=[student],
                           subject="About your algebra paper")


# ---------------------------------------------------------------------------
# Access is participation
# ---------------------------------------------------------------------------

def test_participants_can_read_it(app, room, tutor, student):
    assert messaging.can_read(room, tutor)
    assert messaging.can_read(room, student)


def test_an_outsider_cannot(app, room, outsider):
    assert not messaging.can_read(room, outsider)
    with pytest.raises(messaging.MessagingError):
        messaging.assert_can_read(room, outsider)


def test_being_staff_is_not_a_key(app, room, admin_user):
    """There is deliberately no staff override.

    An administrator who needs to read a thread has to be added to it,
    which is a visible act rather than an invisible capability.
    """
    assert not messaging.can_read(room, admin_user)


def test_the_route_refuses_a_conversation_that_is_not_yours(client, app,
                                                             sign_in, room,
                                                             outsider):
    sign_in(outsider)
    assert client.get(f"/messages/{room.public_id}").status_code == 403
    assert client.post(f"/messages/{room.public_id}",
                       data={"body": "Let me in"}).status_code == 403
    assert client.get(f"/messages/{room.public_id}/since").status_code == 403


def test_sending_is_refused_at_the_service_too(app, room, outsider):
    """The service does not trust its caller to have checked.

    A service that assumes the route authorised it leaks the first time
    somebody adds a second caller.
    """
    with pytest.raises(messaging.MessagingError):
        messaging.send(room, sender=outsider, body="Hello")


def test_anonymous_is_sent_to_sign_in(client, app, room):
    response = client.get(f"/messages/{room.public_id}")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


# ---------------------------------------------------------------------------
# Sending
# ---------------------------------------------------------------------------

def test_a_message_is_stored_as_plain_text(app, room, tutor):
    """Markup in a message is shown as the characters typed.

    A chat message that renders HTML is one somebody can put a
    link-shaped thing in that is not a link.
    """
    message = messaging.send(room, sender=tutor,
                             body='<script>alert(1)</script>Hello')
    assert "<script" not in message.body
    assert "Hello" in message.body


def test_an_empty_message_is_refused(app, room, tutor):
    for body in ("", "   ", "\n\n"):
        with pytest.raises(messaging.MessagingError):
            messaging.send(room, sender=tutor, body=body)


def test_a_closed_conversation_takes_nothing_new(app, room, tutor):
    room.is_closed = True
    db.session.commit()
    with pytest.raises(messaging.MessagingError):
        messaging.send(room, sender=tutor, body="One more thing")


def test_a_closed_conversation_is_still_readable(client, app, sign_in, room,
                                                  tutor, student):
    messaging.send(room, sender=tutor, body="Before it closed")
    room.is_closed = True
    db.session.commit()

    sign_in(student)
    body = client.get(f"/messages/{room.public_id}").get_data(as_text=True)
    assert "Before it closed" in body


# ---------------------------------------------------------------------------
# Unread
# ---------------------------------------------------------------------------

def test_your_own_message_does_not_leave_the_room_unread(app, room, tutor):
    messaging.send(room, sender=tutor, body="Hello")
    assert messaging.unread_count(tutor) == 0


def test_the_other_person_sees_it_as_unread(app, room, tutor, student):
    messaging.send(room, sender=tutor, body="Hello")
    assert messaging.unread_count(student) == 1


def test_opening_the_thread_clears_it(client, app, sign_in, room, tutor,
                                       student):
    messaging.send(room, sender=tutor, body="Hello")
    sign_in(student)
    client.get(f"/messages/{room.public_id}")
    assert messaging.unread_count(student) == 0


def test_a_room_nobody_has_spoken_in_is_not_unread(app, room, student):
    assert room.last_message_at is None
    assert messaging.unread_count(student) == 0


def test_unread_counts_rooms_not_messages(app, room, tutor, student):
    """"3 unread conversations" is actionable; "47 unread messages" is
    a number nobody can do anything with."""
    for _ in range(5):
        messaging.send(room, sender=tutor, body="Another one")
    assert messaging.unread_count(student) == 1


# ---------------------------------------------------------------------------
# Polling
# ---------------------------------------------------------------------------

def test_the_poll_returns_only_what_is_new(client, app, sign_in, room,
                                            tutor, student):
    first = messaging.send(room, sender=tutor, body="First")
    sign_in(student)

    response = client.get(f"/messages/{room.public_id}/since",
                          query_string={"after": first.created_at.isoformat()})
    assert response.get_json()["messages"] == []

    messaging.send(room, sender=tutor, body="Second")
    response = client.get(f"/messages/{room.public_id}/since",
                          query_string={"after": first.created_at.isoformat()})
    bodies = [m["body"] for m in response.get_json()["messages"]]
    assert bodies == ["Second"]


def test_an_unreadable_timestamp_returns_the_tail_not_an_error(client, app,
                                                                sign_in, room,
                                                                tutor,
                                                                student):
    """A poll that 400s is a thread that silently stops updating."""
    messaging.send(room, sender=tutor, body="Hello")
    sign_in(student)

    response = client.get(f"/messages/{room.public_id}/since",
                          query_string={"after": "next tuesday"})
    assert response.status_code == 200
    assert len(response.get_json()["messages"]) == 1


def test_posting_a_message_needs_the_csrf_token(client, app, room, tutor):
    """The route is not exempt just because a script posts to it."""
    app.config["WTF_CSRF_ENABLED"] = True
    try:
        with client.session_transaction() as session:
            session["_user_id"] = str(tutor.id)
            session["_fresh"] = True
        response = client.post(f"/messages/{room.public_id}",
                               data={"body": "No token"})
        assert response.status_code == 400
    finally:
        app.config["WTF_CSRF_ENABLED"] = False


# ---------------------------------------------------------------------------
# Starting one
# ---------------------------------------------------------------------------

def test_the_creator_is_always_a_participant(app, tutor, student):
    """Forgetting yourself would create a room its own author cannot read."""
    conversation = messaging.start(creator=tutor, participants=[student])
    assert messaging.can_read(conversation, tutor)


def test_somebody_is_added_once_even_if_passed_twice(app, tutor, student):
    conversation = messaging.start(creator=tutor,
                                   participants=[student, student, tutor])
    assert len(conversation.participants) == 2


def test_two_people_are_not_given_a_second_room(app, tutor, student):
    first = messaging.start(creator=tutor, participants=[student],
                            kind=ConversationKind.DIRECT)
    found = messaging.direct_between(tutor, student)
    assert found is not None
    assert found.id == first.id


def test_no_direct_room_is_found_when_there_is_none(app, tutor, outsider):
    assert messaging.direct_between(tutor, outsider) is None
