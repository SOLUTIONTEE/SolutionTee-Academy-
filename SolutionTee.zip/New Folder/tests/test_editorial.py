"""The Education Information Centre.

The publishing state machine is where the subtle bugs live: a scheduled
piece visible early, a draft reachable by URL, an unpublished article
still listed. Each of those is a story going out before it should, so
each has a test.
"""
from __future__ import annotations

import re
from datetime import timedelta

import pytest

from app.extensions import db
from app.models.base import utcnow
from app.models.editorial import (
    Article, ArticleRevision, ArticleStatus, Category, Tag,
)
from app.services import editorial


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def category(app):
    item = Category(name="JAMB", slug="jamb",
                    description="Registration, subjects and results.")
    db.session.add(item)
    db.session.commit()
    return item


#: Distinguishes "no body given, use the default" from "deliberately
#: empty". `body or default` would collapse the two and quietly hand back
#: 400 words when a test asked for none.
_DEFAULT_BODY = object()


def make_article(*, title="How JAMB registration works", slug=None,
                 category=None, status=ArticleStatus.PUBLISHED,
                 published_days_ago=1, reviewed_days_ago=None,
                 featured=False, body=_DEFAULT_BODY,
                 dek="What to do, in order."):
    published = (utcnow() - timedelta(days=published_days_ago)
                 if published_days_ago is not None else None)
    item = Article(
        title=title,
        slug=slug or re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-"),
        dek=dek,
        body_html=("<p>" + ("word " * 400) + "</p>"
                   if body is _DEFAULT_BODY else body),
        category_id=category.id if category else None,
        status=status,
        published_at=published,
        last_reviewed_at=(utcnow() - timedelta(days=reviewed_days_ago)
                          if reviewed_days_ago is not None else published),
        is_featured=featured,
    )
    db.session.add(item)
    db.session.commit()
    return item


# ---------------------------------------------------------------------------
# Visibility is derived
# ---------------------------------------------------------------------------

def test_a_published_article_is_live(app, category):
    assert editorial.is_live(make_article(category=category))


def test_a_draft_is_never_live(app, category):
    item = make_article(category=category, status=ArticleStatus.DRAFT)
    assert not editorial.is_live(item)


def test_a_draft_stays_hidden_even_with_a_past_date(app, category):
    """Somebody took it down deliberately; the date does not override that."""
    item = make_article(category=category, status=ArticleStatus.DRAFT,
                        published_days_ago=30)
    assert not editorial.is_live(item)


def test_an_archived_article_is_not_live(app, category):
    item = make_article(category=category, status=ArticleStatus.ARCHIVED)
    assert not editorial.is_live(item)


def test_a_scheduled_article_is_invisible_until_its_moment(app, category):
    item = make_article(category=category, status=ArticleStatus.SCHEDULED,
                        published_days_ago=None)
    item.published_at = utcnow() + timedelta(hours=2)
    db.session.commit()

    assert not editorial.is_live(item)
    assert editorial.published() == []
    assert editorial.get_published(item.slug) is None


def test_a_scheduled_article_goes_live_on_its_own(app, category):
    """No cron job. Visibility is derived, so nothing has to have run."""
    item = make_article(category=category, status=ArticleStatus.SCHEDULED,
                        published_days_ago=None)
    item.published_at = utcnow() - timedelta(minutes=1)
    db.session.commit()

    assert editorial.is_live(item)
    assert editorial.get_published(item.slug) is not None
    # And the status label has not been tidied yet, which is fine.
    assert item.status == ArticleStatus.SCHEDULED


def test_promoting_scheduled_articles_only_tidies_the_label(app, category):
    item = make_article(category=category, status=ArticleStatus.SCHEDULED,
                        published_days_ago=None)
    item.published_at = utcnow() - timedelta(minutes=1)
    db.session.commit()

    assert editorial.promote_scheduled() == 1
    db.session.refresh(item)
    assert item.status == ArticleStatus.PUBLISHED


def test_promoting_leaves_future_articles_alone(app, category):
    item = make_article(category=category, status=ArticleStatus.SCHEDULED,
                        published_days_ago=None)
    item.published_at = utcnow() + timedelta(days=1)
    db.session.commit()

    assert editorial.promote_scheduled() == 0
    db.session.refresh(item)
    assert item.status == ArticleStatus.SCHEDULED


def test_an_article_with_no_date_is_not_live(app, category):
    item = make_article(category=category, published_days_ago=None)
    assert not editorial.is_live(item)


# ---------------------------------------------------------------------------
# The workflow
# ---------------------------------------------------------------------------

def test_publishing_requires_a_headline_and_a_body(app, category):
    item = make_article(category=category, status=ArticleStatus.DRAFT,
                        body="")
    with pytest.raises(editorial.EditorialError, match="body"):
        editorial.publish(item)

    item.body_html = "<p>Something.</p>"
    item.title = "   "
    with pytest.raises(editorial.EditorialError, match="headline"):
        editorial.publish(item)


def test_publishing_with_a_future_date_schedules_it(app, category,
                                                     admin_user):
    item = make_article(category=category, status=ArticleStatus.DRAFT)
    when = utcnow() + timedelta(days=3)
    editorial.publish(item, actor=admin_user, when=when)

    assert item.status == ArticleStatus.SCHEDULED
    assert not editorial.is_live(item)


def test_publishing_now_makes_it_live(app, category, admin_user):
    item = make_article(category=category, status=ArticleStatus.DRAFT)
    editorial.publish(item, actor=admin_user)

    assert item.status == ArticleStatus.PUBLISHED
    assert editorial.is_live(item)
    # Going out is itself a sign-off.
    assert item.last_reviewed_at is not None
    assert item.editor_id == admin_user.id


def test_unpublishing_hides_it_immediately(app, category, admin_user):
    item = make_article(category=category)
    editorial.unpublish(item, actor=admin_user)

    assert not editorial.is_live(item)
    assert editorial.published() == []
    assert editorial.get_published(item.slug) is None


def test_saving_a_draft_keeps_what_it_replaced(app, category, admin_user):
    item = make_article(category=category)
    editorial.save_draft(item, title="A new headline", dek="New dek.",
                         body_html="<p>Rewritten.</p>", actor=admin_user,
                         note="Corrected the deadline")

    revisions = db.session.query(ArticleRevision).all()
    assert len(revisions) == 1
    assert revisions[0].title == "How JAMB registration works"
    assert revisions[0].note == "Corrected the deadline"
    assert item.title == "A new headline"


def test_editing_only_metadata_does_not_claim_the_content_changed(
        app, category, admin_user):
    """A typo fix must not tell every reader the guidance was revised."""
    item = make_article(category=category)
    original_body = item.body_html
    item.content_updated_at = None
    db.session.commit()

    editorial.save_draft(item, title="Same body, new headline",
                         dek=item.dek, body_html=original_body,
                         actor=admin_user)
    assert item.content_updated_at is None


def test_changing_the_body_records_when(app, category, admin_user):
    item = make_article(category=category)
    item.content_updated_at = None
    db.session.commit()

    editorial.save_draft(item, title=item.title, dek=item.dek,
                         body_html="<p>Genuinely different.</p>",
                         actor=admin_user)
    assert item.content_updated_at is not None


def test_a_saved_body_is_sanitised(app, category, admin_user):
    """An editor's account is not a security boundary."""
    item = make_article(category=category)
    editorial.save_draft(
        item, title=item.title, dek=item.dek,
        body_html='<p>Fine.</p><script>alert(1)</script>'
                  '<img src=x onerror=alert(1)>',
        actor=admin_user,
    )
    assert "<script" not in item.body_html
    assert "onerror" not in item.body_html
    assert "Fine." in item.body_html


def test_restoring_a_revision_keeps_the_version_it_replaced(app, category,
                                                             admin_user):
    item = make_article(category=category)
    original_title = item.title

    editorial.save_draft(item, title="Wrong edit", dek=item.dek,
                         body_html="<p>Wrong.</p>", actor=admin_user)
    revision = db.session.query(ArticleRevision).one()

    editorial.restore(item, revision, actor=admin_user)
    assert item.title == original_title
    # Two revisions now: the original save, and the version restore replaced.
    assert db.session.query(ArticleRevision).count() == 2


def test_a_revision_from_another_article_is_refused(app, category,
                                                     admin_user):
    first = make_article(category=category, title="One", slug="one")
    second = make_article(category=category, title="Two", slug="two")

    editorial.save_draft(first, title="Edited", dek="", body_html="<p>x</p>",
                         actor=admin_user)
    revision = db.session.query(ArticleRevision).one()

    with pytest.raises(editorial.EditorialError, match="another article"):
        editorial.restore(second, revision, actor=admin_user)


def test_marking_reviewed_is_its_own_action(app, category, admin_user):
    """Fixing a typo is not the same claim as confirming a deadline."""
    item = make_article(category=category, reviewed_days_ago=300)
    old = item.last_reviewed_at

    editorial.save_draft(item, title=item.title, dek=item.dek,
                         body_html="<p>Tweaked.</p>", actor=admin_user)
    assert item.last_reviewed_at == old       # a save is not a review

    editorial.mark_reviewed(item, actor=admin_user)
    assert item.last_reviewed_at > old


# ---------------------------------------------------------------------------
# Derived reading aids
# ---------------------------------------------------------------------------

def test_reading_time_is_computed_not_typed(app, category):
    short = make_article(category=category, slug="short",
                         body="<p>" + ("word " * 200) + "</p>")
    long = make_article(category=category, slug="long",
                        body="<p>" + ("word " * 2000) + "</p>")
    assert editorial.reading_minutes(short) == 1
    assert editorial.reading_minutes(long) == 10


def test_reading_time_is_never_zero(app, category):
    item = make_article(category=category, body="<p>Three words here.</p>")
    assert editorial.reading_minutes(item) == 1


def test_the_outline_comes_from_the_headings(app, category):
    item = make_article(category=category, body=(
        "<h2>Before you start</h2><p>x</p>"
        "<h3>What you need</h3><p>y</p>"
        "<h2>Filling the form</h2><p>z</p>"
    ))
    headings = editorial.outline(item)
    assert [h.text for h in headings] == [
        "Before you start", "What you need", "Filling the form",
    ]
    assert [h.level for h in headings] == [2, 3, 2]


def test_repeated_headings_get_distinct_anchors(app, category):
    """Two sections called "Requirements" must not share an anchor."""
    item = make_article(category=category, body=(
        "<h2>Requirements</h2><p>a</p><h2>Requirements</h2><p>b</p>"
    ))
    anchors = [h.anchor for h in editorial.outline(item)]
    assert len(set(anchors)) == 2


def test_rendered_anchors_match_the_outline(app, category):
    """A contents link that scrolls nowhere is worse than none."""
    item = make_article(category=category, body=(
        "<h2>First</h2><p>a</p><h2>First</h2><p>b</p><h3>Second</h3>"
    ))
    rendered = editorial.body_with_anchors(item)
    for heading in editorial.outline(item):
        assert f'id="{heading.anchor}"' in rendered


def test_body_with_anchors_does_not_alter_the_stored_body(app, category):
    item = make_article(category=category, body="<h2>Title</h2><p>x</p>")
    before = item.body_html
    editorial.body_with_anchors(item)
    assert item.body_html == before


# ---------------------------------------------------------------------------
# Staleness
# ---------------------------------------------------------------------------

def test_a_recent_article_carries_no_warning(app, category):
    item = make_article(category=category, reviewed_days_ago=10)
    assert not editorial.review_state(item).is_due


def test_an_old_article_warns_that_it_may_be_wrong(app, category):
    item = make_article(category=category, reviewed_days_ago=400)
    state = editorial.review_state(item)
    assert state.is_due
    assert "confirm anything time-sensitive" in state.message


def test_the_warning_appears_before_the_article_not_after(client, app,
                                                          category):
    """Somebody who acts on the guidance will not scroll back for a caveat."""
    item = make_article(category=category, reviewed_days_ago=400)
    body = client.get(f"/updates/{item.slug}").get_data(as_text=True)

    assert "This may be out of date" in body
    assert body.index("This may be out of date") < body.index("article__body")


# ---------------------------------------------------------------------------
# The front
# ---------------------------------------------------------------------------

def test_the_front_leads_with_the_featured_article(app, category):
    make_article(category=category, title="Ordinary", slug="ordinary",
                 published_days_ago=1)
    featured = make_article(category=category, title="The important one",
                            slug="important", published_days_ago=5,
                            featured=True)

    front = editorial.front_page()
    assert front.lead.id == featured.id


def test_the_front_leads_with_the_newest_when_nothing_is_featured(app,
                                                                   category):
    make_article(category=category, title="Old", slug="old",
                 published_days_ago=10)
    newest = make_article(category=category, title="New", slug="new",
                          published_days_ago=1)
    assert editorial.front_page().lead.id == newest.id


def test_nothing_appears_twice_on_the_front(app, category):
    for index in range(8):
        make_article(category=category, title=f"Story {index}",
                     slug=f"story-{index}", published_days_ago=index + 1)

    front = editorial.front_page()
    seen = [front.lead.id] + [a.id for a in front.secondary] \
        + [a.id for a in front.latest]
    assert len(seen) == len(set(seen))


def test_an_empty_front_says_why_rather_than_showing_nothing(client, app):
    body = client.get("/updates/").get_data(as_text=True)
    assert "Nothing published yet" in body
    assert "until it has been written and" in body


# ---------------------------------------------------------------------------
# The pages
# ---------------------------------------------------------------------------

def test_a_draft_url_is_404_not_a_preview(client, app, category):
    item = make_article(category=category, status=ArticleStatus.DRAFT)
    assert client.get(f"/updates/{item.slug}").status_code == 404


def test_a_scheduled_url_is_404_before_its_moment(client, app, category):
    """A leaked URL must not show tomorrow's story."""
    item = make_article(category=category, status=ArticleStatus.SCHEDULED,
                        published_days_ago=None)
    item.published_at = utcnow() + timedelta(days=1)
    db.session.commit()
    assert client.get(f"/updates/{item.slug}").status_code == 404


def test_the_article_page_shows_its_three_dates_distinctly(client, app,
                                                            category):
    item = make_article(category=category, published_days_ago=40,
                        reviewed_days_ago=5)
    item.content_updated_at = utcnow() - timedelta(days=10)
    db.session.commit()

    flat = " ".join(client.get(
        f"/updates/{item.slug}").get_data(as_text=True).split())
    assert "Published" in flat
    assert "updated" in flat
    assert "Last checked" in flat


def test_a_long_article_gets_a_contents_list(client, app, category):
    item = make_article(category=category, body=(
        "<h2>One</h2><p>a</p><h2>Two</h2><p>b</p><h2>Three</h2><p>c</p>"
    ))
    body = client.get(f"/updates/{item.slug}").get_data(as_text=True)
    assert "On this page" in body
    assert 'href="#one"' in body


def test_a_short_article_does_not_get_one(client, app, category):
    item = make_article(category=category, body="<h2>Only one</h2><p>a</p>")
    body = client.get(f"/updates/{item.slug}").get_data(as_text=True)
    assert "On this page" not in body


def test_a_category_page_lists_only_its_own_articles(client, app, category):
    other = Category(name="Scholarships", slug="scholarships")
    db.session.add(other)
    db.session.commit()

    mine = make_article(category=category, title="JAMB thing", slug="jamb-thing")
    theirs = make_article(category=other, title="Money thing",
                          slug="money-thing")

    body = client.get("/updates/category/jamb").get_data(as_text=True)
    assert mine.title in body
    assert theirs.title not in body


def test_an_unknown_category_is_404(client, app):
    assert client.get("/updates/category/nope").status_code == 404


def test_an_empty_category_explains_itself(client, app, category):
    body = client.get("/updates/category/jamb").get_data(as_text=True)
    assert "Nothing in this section yet" in body


def test_search_finds_by_headline_and_standfirst(client, app, category):
    make_article(category=category, title="Registering for UTME",
                 slug="registering", dek="A step by step walkthrough.")

    assert "Registering for UTME" in client.get(
        "/updates/?q=utme").get_data(as_text=True)
    assert "Registering for UTME" in client.get(
        "/updates/?q=walkthrough").get_data(as_text=True)


def test_search_with_no_results_says_so(client, app, category):
    make_article(category=category)
    body = client.get("/updates/?q=zzzzz").get_data(as_text=True)
    assert "Nothing matched" in body


def test_related_articles_come_from_the_same_section(app, category):
    other = Category(name="WAEC", slug="waec")
    db.session.add(other)
    db.session.commit()

    main = make_article(category=category, title="Main", slug="main")
    sibling = make_article(category=category, title="Sibling", slug="sibling")
    make_article(category=other, title="Unrelated", slug="unrelated")

    ids = [a.id for a in editorial.related(main)]
    assert sibling.id in ids
    assert main.id not in ids
    assert len(ids) == 1


def test_category_counts_exclude_unpublished_work(app, category):
    make_article(category=category, slug="live")
    make_article(category=category, slug="draft-one",
                 status=ArticleStatus.DRAFT)

    counts = dict((c.slug, n) for c, n in editorial.live_categories())
    assert counts["jamb"] == 1


def test_the_article_page_carries_structured_data(client, app, category):
    item = make_article(category=category)
    body = client.get(f"/updates/{item.slug}").get_data(as_text=True)
    assert 'type="application/ld+json"' in body
    assert '"@type": "Article"' in body
    # Inline script, so it needs the nonce like every other one.
    assert re.search(r'<script type="application/ld\+json" nonce="[^"]+"',
                     body)
