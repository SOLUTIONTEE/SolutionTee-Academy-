"""Media library: validation, processing, usage tracking and deletion."""
from __future__ import annotations

import io

import pytest
from PIL import Image

from app.extensions import db
from app.models.media import Media, MediaFolder
from app.services import media as media_service
from app.services.media.validation import (
    ValidationError, build_object_key, inspect_image, safe_display_filename,
)
from app.services.storage import get_storage
from tests.conftest import make_image_bytes


# ---------------------------------------------------------------------------
# Validation - nothing the browser claims is trusted
# ---------------------------------------------------------------------------

def test_a_real_image_is_identified_by_decoding_it(app):
    inspected = inspect_image(make_image_bytes(800, 600), max_bytes=10**7)
    assert inspected.pillow_format == "JPEG"
    assert inspected.mime_type == "image/jpeg"
    assert (inspected.width, inspected.height) == (800, 600)
    assert len(inspected.checksum) == 64


def test_a_script_renamed_as_an_image_is_rejected(app):
    """The extension says .jpg. The bytes say otherwise, and bytes win."""
    payload = b"<?php system($_GET['c']); ?>"
    with pytest.raises(ValidationError, match="not an image"):
        inspect_image(payload, max_bytes=10**7)


def test_svg_is_rejected(app):
    """SVG can carry script, so it needs sanitisation, not an allowlist."""
    svg = b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'
    with pytest.raises(ValidationError):
        inspect_image(svg, max_bytes=10**7)


def test_oversized_file_is_rejected_with_a_useful_message(app):
    data = make_image_bytes(2000, 2000)
    with pytest.raises(ValidationError, match="limit"):
        inspect_image(data, max_bytes=1024)


def test_empty_file_is_rejected(app):
    with pytest.raises(ValidationError, match="empty"):
        inspect_image(b"", max_bytes=10**7)


def test_truncated_image_is_rejected(app):
    data = make_image_bytes(400, 400)
    with pytest.raises(ValidationError):
        inspect_image(data[: len(data) // 3], max_bytes=10**7)


@pytest.mark.parametrize("supplied,expected_absent", [
    ("../../etc/passwd", ".."),
    ("..\\..\\windows\\system32\\cmd.exe", ".."),
    ("photo;rm -rf /.jpg", ";"),
    ("<script>.png", "<"),
])
def test_display_filename_is_stripped_of_anything_dangerous(
        app, supplied, expected_absent):
    cleaned = safe_display_filename(supplied)
    assert expected_absent not in cleaned
    assert "/" not in cleaned and "\\" not in cleaned


def test_object_keys_are_generated_not_derived_from_the_filename(app):
    from datetime import datetime, timezone

    created = datetime(2026, 3, 9, tzinfo=timezone.utc)
    key = build_object_key("abc123", "thumb", "webp", created=created)
    assert key == "media/2026/03/abc123/thumb.webp"


def test_object_key_cannot_be_made_to_traverse(app):
    from datetime import datetime, timezone

    created = datetime(2026, 3, 9, tzinfo=timezone.utc)
    key = build_object_key("../../evil", "../escape", "../png",
                           created=created)
    assert ".." not in key
    assert key.startswith("media/2026/03/")


# ---------------------------------------------------------------------------
# Processing
# ---------------------------------------------------------------------------

def test_upload_generates_variants_smaller_than_the_original(app, admin_user):
    media = media_service.upload_image(
        make_image_bytes(2400, 1600), "wide.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )
    assert set(media.variants) == {"thumb", "medium", "large"}
    assert media.variants["thumb"]["width"] == 400
    assert media.variants["large"]["width"] == 1600
    for entry in media.variants.values():
        assert entry["mime_type"] == "image/webp"


def test_variants_are_never_upscaled(app, admin_user):
    """A 300px image gains nothing from a 1600px 'variant'."""
    media = media_service.upload_image(
        make_image_bytes(300, 200), "small.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )
    assert media.variants == {}
    # Asking for a missing variant falls back to the original rather
    # than producing a link to nothing.
    assert (media_service.variant_url(media, "thumb")
            == media_service.variant_url(media, "original"))


def test_gps_metadata_is_stripped_from_the_stored_original(app, admin_user):
    """A photo taken in the centre must not publish its coordinates."""
    buffer = io.BytesIO()
    image = Image.new("RGB", (900, 600), (30, 60, 90))
    exif = image.getexif()
    exif[0x8825] = {}          # GPSInfo
    exif[0x010F] = "TestPhone"  # Make
    image.save(buffer, format="JPEG", exif=exif)

    media = media_service.upload_image(
        buffer.getvalue(), "gps.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )

    stored = get_storage().open(media.object_key).read()
    with Image.open(io.BytesIO(stored)) as reloaded:
        assert not dict(reloaded.getexif())


def test_portrait_orientation_is_applied_before_exif_is_dropped(app,
                                                                admin_user):
    """Otherwise every phone portrait would display on its side."""
    buffer = io.BytesIO()
    image = Image.new("RGB", (800, 400), (10, 10, 10))
    exif = image.getexif()
    exif[0x0112] = 6  # rotate 90 CW
    image.save(buffer, format="JPEG", exif=exif)

    media = media_service.upload_image(
        buffer.getvalue(), "rotated.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )

    stored = get_storage().open(media.object_key).read()
    with Image.open(io.BytesIO(stored)) as reloaded:
        # The rotation is now in the pixels: 800x400 became 400x800.
        assert reloaded.size == (400, 800)


# ---------------------------------------------------------------------------
# Storage and deduplication
# ---------------------------------------------------------------------------

def test_objects_are_actually_written(app, admin_user):
    media = media_service.upload_image(
        make_image_bytes(1200, 900), "photo.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )
    storage = get_storage()
    for key in media_service.all_object_keys(media):
        assert storage.exists(key), f"missing object {key}"


def test_uploading_identical_bytes_reuses_the_existing_asset(app, admin_user):
    data = make_image_bytes(1000, 700, colour=(200, 30, 30))
    first = media_service.upload_image(data, "a.jpg",
                                       uploaded_by_id=admin_user.id,
                                       max_bytes=10**7)
    second = media_service.upload_image(data, "same-again.jpg",
                                        uploaded_by_id=admin_user.id,
                                        max_bytes=10**7)
    assert first.id == second.id
    assert db.session.query(Media).count() == 1


def test_different_images_are_stored_separately(app, admin_user):
    media_service.upload_image(make_image_bytes(colour=(1, 2, 3)), "a.jpg",
                               uploaded_by_id=admin_user.id, max_bytes=10**7)
    media_service.upload_image(make_image_bytes(colour=(250, 250, 250)),
                               "b.jpg", uploaded_by_id=admin_user.id,
                               max_bytes=10**7)
    assert db.session.query(Media).count() == 2


def test_a_failed_upload_leaves_no_row_and_no_objects(app, admin_user,
                                                      monkeypatch):
    """A row pointing at nothing is worse than an unreferenced object."""
    from app.services.media import library

    real_save = get_storage().save
    calls = {"n": 0}

    def failing_save(key, stream, content_type):
        calls["n"] += 1
        if calls["n"] == 2:      # succeed on the original, fail on a variant
            raise RuntimeError("storage exploded")
        return real_save(key, stream, content_type)

    monkeypatch.setattr(get_storage(), "save", failing_save)

    with pytest.raises(RuntimeError):
        library.upload_image(make_image_bytes(2000, 1500), "boom.jpg",
                             uploaded_by_id=admin_user.id, max_bytes=10**7)

    assert db.session.query(Media).count() == 0


# ---------------------------------------------------------------------------
# Batch behaviour
# ---------------------------------------------------------------------------

class _FakeUpload:
    def __init__(self, data: bytes, filename: str) -> None:
        self._data = data
        self.filename = filename

    def read(self) -> bytes:
        return self._data


def test_one_bad_file_does_not_discard_the_rest_of_the_batch(app, admin_user):
    files = [
        _FakeUpload(make_image_bytes(colour=(10, 20, 30)), "good-1.jpg"),
        _FakeUpload(b"this is not an image", "broken.jpg"),
        _FakeUpload(make_image_bytes(colour=(40, 50, 60)), "good-2.jpg"),
        _FakeUpload(b"", "empty.jpg"),
        _FakeUpload(make_image_bytes(colour=(70, 80, 90)), "good-3.jpg"),
    ]

    results = media_service.upload_batch(files, uploaded_by_id=admin_user.id,
                                         max_bytes=10**7)

    assert [r.ok for r in results] == [True, False, True, False, True]
    assert db.session.query(Media).count() == 3
    # Failures explain themselves rather than reporting a generic error.
    assert "not an image" in results[1].error
    assert "empty" in results[3].error.lower()


def test_duplicate_filenames_in_one_batch_are_not_a_conflict(app, admin_user):
    files = [
        _FakeUpload(make_image_bytes(colour=(1, 1, 1)), "photo.jpg"),
        _FakeUpload(make_image_bytes(colour=(2, 2, 2)), "photo.jpg"),
    ]
    results = media_service.upload_batch(files, uploaded_by_id=admin_user.id,
                                         max_bytes=10**7)
    assert all(r.ok for r in results)
    assert db.session.query(Media).count() == 2


# ---------------------------------------------------------------------------
# Usage tracking and safe deletion
# ---------------------------------------------------------------------------

@pytest.fixture
def stored_image(app, admin_user):
    return media_service.upload_image(
        make_image_bytes(1400, 1000), "classroom.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )


def test_usage_is_recorded_once_per_place(app, stored_image):
    media_service.record_usage(stored_image, content_type="programme",
                               content_id="jamb", field_name="hero",
                               label="JAMB programme")
    media_service.record_usage(stored_image, content_type="programme",
                               content_id="jamb", field_name="hero",
                               label="JAMB programme (renamed)")

    db.session.refresh(stored_image)
    assert len(stored_image.usages) == 1
    assert stored_image.usages[0].label == "JAMB programme (renamed)"


def test_one_asset_serves_many_places(app, stored_image):
    """The whole point: three references, one upload."""
    for content_id, field in (("home", "hero"), ("jamb", "gallery"),
                              ("article-1", "hero")):
        media_service.record_usage(stored_image, content_type="page",
                                   content_id=content_id, field_name=field)
    db.session.refresh(stored_image)
    assert len(stored_image.usages) == 3
    assert db.session.query(Media).count() == 1


def test_deleting_an_in_use_image_is_refused(app, stored_image):
    media_service.record_usage(stored_image, content_type="page",
                               content_id="home", field_name="hero",
                               label="Homepage hero")
    db.session.refresh(stored_image)

    with pytest.raises(media_service.MediaInUseError):
        media_service.delete(stored_image)

    assert db.session.query(Media).count() == 1


def test_an_unused_image_deletes_along_with_every_object(app, stored_image):
    keys = media_service.all_object_keys(stored_image)
    storage = get_storage()

    media_service.delete(stored_image)

    assert db.session.query(Media).count() == 0
    for key in keys:
        assert not storage.exists(key), f"object left behind: {key}"


def test_force_deletes_only_when_explicitly_asked(app, stored_image):
    media_service.record_usage(stored_image, content_type="page",
                               content_id="home", field_name="hero")
    db.session.refresh(stored_image)

    media_service.delete(stored_image, force=True)
    assert db.session.query(Media).count() == 0


def test_archiving_keeps_the_asset_serving(app, stored_image):
    """Archiving is the safe retirement: the bytes stay."""
    media_service.archive(stored_image)
    assert stored_image.is_archived is True
    for key in media_service.all_object_keys(stored_image):
        assert get_storage().exists(key)


def test_clearing_usage_lets_an_image_be_deleted(app, stored_image):
    media_service.record_usage(stored_image, content_type="page",
                               content_id="home", field_name="hero")
    media_service.clear_usage(content_type="page", content_id="home")
    db.session.refresh(stored_image)
    media_service.delete(stored_image)
    assert db.session.query(Media).count() == 0


# ---------------------------------------------------------------------------
# Browsing
# ---------------------------------------------------------------------------

def test_browse_paginates_rather_than_loading_everything(app, admin_user):
    for index in range(12):
        media_service.upload_image(
            make_image_bytes(400, 300, colour=(index * 5, 10, 20)),
            f"image-{index}.jpg", uploaded_by_id=admin_user.id,
            max_bytes=10**7,
        )

    first = media_service.browse(page=1, per_page=5)
    assert len(first.items) == 5
    assert first.total == 12
    assert first.pages == 3
    assert first.has_next and not first.has_prev

    last = media_service.browse(page=3, per_page=5)
    assert len(last.items) == 2
    assert last.has_prev and not last.has_next


def test_search_covers_filename_alt_text_and_caption(app, admin_user):
    media = media_service.upload_image(
        make_image_bytes(colour=(9, 9, 9)), "cbt-session.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )
    media_service.update_metadata(media, alt_text="Students at computers",
                                  caption="Mock examination day")

    assert media_service.browse(query="cbt").total == 1
    assert media_service.browse(query="computers").total == 1
    assert media_service.browse(query="mock").total == 1
    assert media_service.browse(query="nothing-like-this").total == 0


def test_archived_media_is_hidden_from_the_default_listing(app, stored_image):
    media_service.archive(stored_image)
    assert media_service.browse().total == 0
    assert media_service.browse(include_archived=True).total == 1


def test_folder_filtering_and_counts(app, admin_user):
    folder = MediaFolder(name="CBT", slug="cbt")
    db.session.add(folder)
    db.session.commit()

    inside = media_service.upload_image(
        make_image_bytes(colour=(11, 22, 33)), "in.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7, folder_id=folder.id,
    )
    media_service.upload_image(
        make_image_bytes(colour=(44, 55, 66)), "out.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )

    assert media_service.browse(folder_id=folder.id).total == 1
    assert media_service.browse().total == 2
    assert media_service.counts_by_folder()[folder.id] == 1
    assert inside.folder_id == folder.id


# ---------------------------------------------------------------------------
# Alt text
# ---------------------------------------------------------------------------

def test_alt_text_is_never_defaulted_from_the_filename(app, stored_image):
    """"IMG_4821.jpg" is not a description of anything."""
    assert stored_image.alt_text == ""
    assert stored_image.accessible_alt == ""


def test_marking_an_image_decorative_clears_its_alt_text(app, stored_image):
    media_service.update_metadata(stored_image, alt_text="A classroom")
    assert stored_image.accessible_alt == "A classroom"

    media_service.update_metadata(stored_image, is_decorative=True)
    assert stored_image.is_decorative is True
    assert stored_image.accessible_alt == ""
    assert stored_image.alt_text == ""


def test_srcset_lists_every_variant_with_its_width(app, admin_user):
    media = media_service.upload_image(
        make_image_bytes(2400, 1600), "wide.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )
    srcset = media_service.srcset_for(media)
    assert "400w" in srcset and "1000w" in srcset and "1600w" in srcset
    assert "2400w" in srcset  # the original
