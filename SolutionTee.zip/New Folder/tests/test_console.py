"""The administrator's overview.

Two properties matter more than the numbers being right. First, that work
needing a person is reported even when the console for it does not exist
yet - an administrator has to know about twelve unanswered messages
whether or not there is a screen for them. Second, that a task with
nowhere to go is not dressed up as a link to somewhere else.
"""
from __future__ import annotations

from datetime import timedelta

import pytest

from app.extensions import db
from app.models.base import utcnow
from app.models.contact import ContactMessage, ContactStatus
from app.models.editorial import ArticleStatus
from app.services import console
from tests.test_editorial import category, make_article  # noqa: F401


# ---------------------------------------------------------------------------
# Access
# ---------------------------------------------------------------------------

def test_the_console_has_a_front_door(client, sign_in, admin_user):
    """/admin/ used to 404: a console with no landing page."""
    sign_in(admin_user)
    assert client.get("/admin/").status_code == 200


def test_a_student_cannot_reach_it(client, sign_in, student_user):
    sign_in(student_user)
    assert client.get("/admin/").status_code == 403


def test_anonymous_is_sent_to_sign_in(client):
    response = client.get("/admin/")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


# ---------------------------------------------------------------------------
# Work waiting
# ---------------------------------------------------------------------------

def test_an_empty_console_says_so_rather_than_showing_nothing(client, app,
                                                               sign_in,
                                                               admin_user):
    sign_in(admin_user)
    body = client.get("/admin/").get_data(as_text=True)
    assert "Nothing needs you right now" in body


def test_unanswered_messages_are_reported(app, admin_user):
    db.session.add(ContactMessage(
        full_name="A Parent", email="parent@example.test",
        message="Is there a Saturday class?", status=ContactStatus.NEW,
    ))
    db.session.commit()

    overview = console.build()
    labels = [t.label for t in overview.tasks]
    assert "Unanswered messages" in labels


def test_a_task_with_no_console_is_not_dressed_up_as_a_link(app, admin_user):
    """The contact console does not exist yet.

    Sending somebody to the Articles list under a heading that reads
    "Unanswered messages" is worse than sending them nowhere, so the task
    carries no url and renders as a statement.
    """
    db.session.add(ContactMessage(
        full_name="A Parent", email="parent@example.test",
        message="Is there a Saturday class?", status=ContactStatus.NEW,
    ))
    db.session.commit()

    task = next(t for t in console.build().tasks
                if t.label == "Unanswered messages")
    assert task.url == ""
    assert not task.is_actionable


def test_a_replied_message_stops_being_work(app, admin_user):
    db.session.add(ContactMessage(
        full_name="A Parent", email="parent@example.test",
        message="Thanks", status=ContactStatus.REPLIED,
    ))
    db.session.commit()

    labels = [t.label for t in console.build().tasks]
    assert "Unanswered messages" not in labels


def test_a_stale_article_is_flagged_and_is_actionable(app, admin_user,
                                                       category):
    """This one HAS a console, so it is a link."""
    make_article(category=category, reviewed_days_ago=400)

    task = next(t for t in console.build().tasks
                if t.label == "Articles due a check")
    assert task.count == 1
    assert task.is_actionable
    assert task.url.startswith("/admin/articles")


def test_a_recently_checked_article_is_not_flagged(app, admin_user, category):
    make_article(category=category, reviewed_days_ago=10)
    labels = [t.label for t in console.build().tasks]
    assert "Articles due a check" not in labels


def test_drafts_are_counted_separately_from_live(app, admin_user, category):
    make_article(category=category, title="Live one", slug="live-one")
    make_article(category=category, title="Draft one", slug="draft-one",
                 status=ArticleStatus.DRAFT)

    overview = console.build()
    assert overview.articles_live == 1
    assert overview.articles_draft == 1


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------

def test_people_are_counted_by_role_without_double_counting(app, admin_user,
                                                             student_user):
    """A user holding two roles must not be counted twice.

    The count goes through a join on the roles table, which multiplies
    rows; without a distinct it reports more staff than exist.
    """
    overview = console.build()
    assert overview.students >= 1
    assert overview.staff >= 1
    # Nobody is counted as both by this fixture set.
    assert overview.staff == len({admin_user.id})


def test_counting_does_not_load_every_row(app, admin_user, category):
    """Counts are done with count(), not len() over loaded rows.

    Asserted on the source because the difference is invisible on a
    development database and very visible later.
    """
    import pathlib
    source = pathlib.Path("app/services/console.py").read_text(
        encoding="utf-8")
    assert "func.count" in source
    assert "len(db.session" not in source


# ---------------------------------------------------------------------------
# Where signing in takes you
#
# Regression: every role landed on the student portal. An administrator
# arriving at a dashboard about enrolments and practice papers they do not
# have reads it as "the console does not exist".
# ---------------------------------------------------------------------------

def test_an_administrator_lands_in_the_console(client, sign_in, admin_user):
    """Asserted through /login's own redirect for an already-signed-in
    user, which runs the same _safe_next(None, user) path a fresh sign-in
    takes. The fixture users carry a placeholder password hash, so posting
    the form could never have proved anything."""
    sign_in(admin_user)
    response = client.get("/login", follow_redirects=False)
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/admin/")


def test_a_student_lands_in_the_portal(client, sign_in, student_user):
    sign_in(student_user)
    response = client.get("/login", follow_redirects=False)
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/dashboard/")


def test_the_landing_page_is_chosen_by_permission(app, admin_user,
                                                   student_user):
    from app.services import rbac

    assert rbac.landing_endpoint(admin_user) == "admin_overview.index"
    assert rbac.landing_endpoint(student_user) == "portal.dashboard"


def test_a_tutor_lands_in_their_workspace(app):
    """Between the two: no console permissions, but teaching ones."""
    from app.models.enums import AccountStatus, RoleName
    from app.models.rbac import Role
    from app.models.user import User
    from app.services import rbac

    tutor = User(email="tutor-landing@example.test", full_name="Tutor",
                 password_hash="x", status=AccountStatus.ACTIVE)
    tutor.roles.append(
        db.session.query(Role).filter_by(name=RoleName.INSTRUCTOR).one()
    )
    db.session.add(tutor)
    db.session.commit()

    # An instructor holds media.view as well, so the ordering matters:
    # teaching sits above it, or a tutor lands on a page of academy
    # totals instead of on their own students.
    assert rbac.landing_endpoint(tutor) == "teaching.workspace"


def test_the_header_sends_each_role_to_its_own_home(client, sign_in,
                                                     admin_user,
                                                     student_user):
    sign_in(admin_user)
    assert 'href="/admin/"' in client.get("/").get_data(as_text=True)

    sign_in(student_user)
    body = client.get("/").get_data(as_text=True)
    assert 'href="/dashboard/"' in body


def test_money_is_reported_in_kobo_never_as_a_float(app, admin_user):
    """Floats and money do not mix; the whole app counts in kobo."""
    overview = console.build()
    assert isinstance(overview.revenue_kobo, int)
    assert isinstance(overview.outstanding_kobo, int)
    assert isinstance(overview.revenue_30d_kobo, int)


def test_only_settled_payments_count_as_revenue(app, admin_user):
    """A pending row is a reference handed to the gateway, not income."""
    import pathlib
    source = pathlib.Path("app/services/console.py").read_text(
        encoding="utf-8")
    revenue = source[source.index("revenue_kobo = _count"):]
    assert "PaymentStatus.SUCCESS" in revenue[:400]
