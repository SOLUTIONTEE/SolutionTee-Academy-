"""The editorial admin.

The property worth testing hardest: writing and publishing are separate
permissions. Somebody who can draft is not automatically somebody who can
put a page in front of the public — that is the entire point of having an
editor.
"""
from __future__ import annotations

from datetime import timedelta

import pytest

from app.extensions import db
from app.models.base import utcnow
from app.models.editorial import Article, ArticleRevision, ArticleStatus
from app.models.enums import AccountStatus, RoleName
from app.models.rbac import Role
from app.models.user import User
from app.services import editorial
from tests.test_editorial import category, make_article  # noqa: F401


@pytest.fixture
def employee(app):
    """Holds content.edit but not content.publish."""
    user = User(email="writer@example.test", full_name="Writer",
                password_hash="x", status=AccountStatus.ACTIVE)
    user.roles.append(
        db.session.query(Role).filter_by(name=RoleName.EMPLOYEE).one()
    )
    db.session.add(user)
    db.session.commit()
    return user


# ---------------------------------------------------------------------------
# The permission split
# ---------------------------------------------------------------------------

def test_an_employee_can_write_but_not_publish(client, app, sign_in,
                                               employee, category):
    sign_in(employee)
    item = make_article(category=category, status=ArticleStatus.DRAFT)

    # Writing: allowed.
    assert client.get(f"/admin/articles/{item.public_id}").status_code == 200
    client.post(f"/admin/articles/{item.public_id}",
                data={"title": "An employee edit", "dek": "",
                      "body_html": "<p>Written by staff.</p>"},
                follow_redirects=True)
    db.session.refresh(item)
    assert item.title == "An employee edit"

    # Publishing: refused, and nothing changes.
    assert client.post(
        f"/admin/articles/{item.public_id}/publish").status_code == 403
    db.session.refresh(item)
    assert item.status == ArticleStatus.DRAFT


def test_an_employee_cannot_take_an_article_down_either(client, app, sign_in,
                                                        employee, category):
    sign_in(employee)
    item = make_article(category=category)

    assert client.post(
        f"/admin/articles/{item.public_id}/unpublish").status_code == 403
    assert editorial.is_live(item)


def test_the_editor_tells_a_writer_why_they_cannot_publish(client, app,
                                                           sign_in, employee,
                                                           category):
    """A greyed-out button with no explanation is how people give up."""
    sign_in(employee)
    item = make_article(category=category, status=ArticleStatus.DRAFT)

    body = client.get(
        f"/admin/articles/{item.public_id}").get_data(as_text=True)
    assert "content.publish" in body
    assert "Ask an editor" in body


def test_a_student_cannot_reach_the_editor(client, app, sign_in,
                                           student_user, category):
    sign_in(student_user)
    item = make_article(category=category)
    assert client.get("/admin/articles/").status_code == 403
    assert client.get(f"/admin/articles/{item.public_id}").status_code == 403


def test_anonymous_is_sent_to_sign_in(client, app):
    response = client.get("/admin/articles/")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


# ---------------------------------------------------------------------------
# Publishing
# ---------------------------------------------------------------------------

def test_an_admin_can_publish(client, app, sign_in, admin_user, category):
    sign_in(admin_user)
    item = make_article(category=category, status=ArticleStatus.DRAFT)

    client.post(f"/admin/articles/{item.public_id}/publish",
                data={"publish_at": ""}, follow_redirects=True)
    db.session.refresh(item)

    assert item.status == ArticleStatus.PUBLISHED
    assert editorial.is_live(item)


def test_scheduling_keeps_it_hidden_until_its_moment(client, app, sign_in,
                                                     admin_user, category):
    sign_in(admin_user)
    item = make_article(category=category, status=ArticleStatus.DRAFT)
    later = (utcnow() + timedelta(days=2)).strftime("%Y-%m-%dT%H:%M")

    client.post(f"/admin/articles/{item.public_id}/publish",
                data={"publish_at": later}, follow_redirects=True)
    db.session.refresh(item)

    assert item.status == ArticleStatus.SCHEDULED
    assert not editorial.is_live(item)
    assert client.get(f"/updates/{item.slug}").status_code == 404


def test_an_unreadable_publish_time_changes_nothing(client, app, sign_in,
                                                    admin_user, category):
    sign_in(admin_user)
    item = make_article(category=category, status=ArticleStatus.DRAFT)

    client.post(f"/admin/articles/{item.public_id}/publish",
                data={"publish_at": "next tuesday"}, follow_redirects=True)
    db.session.refresh(item)
    assert item.status == ArticleStatus.DRAFT


def test_taking_an_article_down_hides_it_at_once(client, app, sign_in,
                                                 admin_user, category):
    sign_in(admin_user)
    item = make_article(category=category)
    assert client.get(f"/updates/{item.slug}").status_code == 200

    client.post(f"/admin/articles/{item.public_id}/unpublish",
                follow_redirects=True)
    assert client.get(f"/updates/{item.slug}").status_code == 404


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------

def test_creating_an_article_needs_a_headline(client, app, sign_in,
                                              admin_user):
    sign_in(admin_user)
    client.post("/admin/articles/new", data={"title": "   "},
                follow_redirects=True)
    assert db.session.query(Article).count() == 0


def test_two_articles_cannot_share_a_url(client, app, sign_in, admin_user):
    """Silently overwriting somebody else's URL is worse than a suffix."""
    sign_in(admin_user)
    for _ in range(2):
        client.post("/admin/articles/new",
                    data={"title": "How JAMB works", "dek": "",
                          "body_html": "<p>x</p>"}, follow_redirects=True)

    slugs = [a.slug for a in db.session.query(Article).all()]
    assert len(slugs) == 2
    assert len(set(slugs)) == 2


def test_the_editor_sanitises_whatever_is_pasted_in(client, app, sign_in,
                                                    admin_user, category):
    """A staff account is not a security boundary."""
    sign_in(admin_user)
    item = make_article(category=category)

    client.post(f"/admin/articles/{item.public_id}",
                data={"title": item.title, "dek": "",
                      "body_html": "<p>Fine.</p><script>alert(1)</script>"},
                follow_redirects=True)
    db.session.refresh(item)

    assert "<script" not in item.body_html
    assert "Fine." in item.body_html


# ---------------------------------------------------------------------------
# Revisions
# ---------------------------------------------------------------------------

def test_saving_records_a_revision_with_its_note(client, app, sign_in,
                                                 admin_user, category):
    sign_in(admin_user)
    item = make_article(category=category)

    client.post(f"/admin/articles/{item.public_id}",
                data={"title": "Changed headline", "dek": "",
                      "body_html": "<p>Changed body.</p>",
                      "note": "Fixed the deadline"},
                follow_redirects=True)

    revision = db.session.query(ArticleRevision).one()
    assert revision.note == "Fixed the deadline"

    body = client.get(
        f"/admin/articles/{item.public_id}").get_data(as_text=True)
    assert "Earlier versions" in body
    assert "Fixed the deadline" in body


def test_restoring_through_the_editor_works(client, app, sign_in,
                                            admin_user, category):
    sign_in(admin_user)
    item = make_article(category=category)
    original = item.title

    client.post(f"/admin/articles/{item.public_id}",
                data={"title": "A wrong edit", "dek": "",
                      "body_html": "<p>Wrong.</p>"}, follow_redirects=True)
    revision = db.session.query(ArticleRevision).first()

    client.post(f"/admin/articles/{item.public_id}/restore/{revision.id}",
                follow_redirects=True)
    db.session.refresh(item)
    assert item.title == original


# ---------------------------------------------------------------------------
# Reviewing
# ---------------------------------------------------------------------------

def test_marking_checked_is_its_own_action(client, app, sign_in, admin_user,
                                           category):
    sign_in(admin_user)
    item = make_article(category=category, reviewed_days_ago=400)
    old = item.last_reviewed_at

    body = client.get(
        f"/admin/articles/{item.public_id}").get_data(as_text=True)
    assert "Mark checked today" in body

    client.post(f"/admin/articles/{item.public_id}/reviewed",
                follow_redirects=True)
    db.session.refresh(item)
    assert item.last_reviewed_at > old


def test_an_overdue_article_is_flagged_to_the_editor(client, app, sign_in,
                                                     admin_user, category):
    sign_in(admin_user)
    item = make_article(category=category, reviewed_days_ago=400)

    body = client.get(
        f"/admin/articles/{item.public_id}").get_data(as_text=True)
    assert "confirm anything time-sensitive" in body


# ---------------------------------------------------------------------------
# The list
# ---------------------------------------------------------------------------

def test_the_list_distinguishes_status_from_being_live(client, app, sign_in,
                                                       admin_user, category):
    """A scheduled piece whose moment has passed is live before anything
    has tidied its label, so the list shows both facts."""
    sign_in(admin_user)
    item = make_article(category=category, status=ArticleStatus.SCHEDULED,
                        published_days_ago=None)
    item.published_at = utcnow() - timedelta(minutes=1)
    db.session.commit()

    body = client.get("/admin/articles/").get_data(as_text=True)
    assert "Scheduled" in body
    assert "Live" in body


def test_the_list_filters_by_status(client, app, sign_in, admin_user,
                                    category):
    sign_in(admin_user)
    make_article(category=category, title="Published one", slug="pub-one")
    make_article(category=category, title="Draft one", slug="draft-one",
                 status=ArticleStatus.DRAFT)

    body = client.get("/admin/articles/?status=draft").get_data(as_text=True)
    assert "Draft one" in body
    assert "Published one" not in body


def test_an_empty_list_explains_itself(client, app, sign_in, admin_user):
    sign_in(admin_user)
    body = client.get("/admin/articles/").get_data(as_text=True)
    assert "No articles yet" in body
