"""The examination engine.

Most of these tests are attempts to cheat: extend the clock, answer
after time, read the answer key, sit somebody else's paper, get a fourth
attempt at a three-attempt mock. Each one should fail.
"""
from __future__ import annotations

import json
import re
from datetime import date, timedelta

import pytest

from app.extensions import db
from app.models.base import utcnow
from app.models.cbt import (
    Answer, Attempt, AttemptStatus, Choice, Exam, Question, QuestionKind,
    ResultVisibility, Subject,
)
from app.models.enums import RoleName
from app.services import accounts, cbt

CORRECT = "The correct option"
WRONG = "A distractor"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def subject(app):
    item = Subject(name="Mathematics", slug="mathematics", board="JAMB")
    db.session.add(item)
    db.session.commit()
    return item


def make_question(subject, *, index=0, topic="Algebra", active=True,
                  kind=QuestionKind.SINGLE, correct_value=""):
    question = Question(
        subject_id=subject.id, exam_type="jamb", topic=topic,
        kind=kind, stem_html=f"<p>Question {index}</p>",
        explanation_html=f"<p>Because of reason {index}.</p>",
        correct_value=correct_value, is_active=active,
        source="Written in-house for testing", licence="Owned",
    )
    db.session.add(question)
    db.session.commit()

    if kind in (QuestionKind.SINGLE, QuestionKind.MULTIPLE):
        db.session.add_all([
            Choice(question_id=question.id, body_html=CORRECT,
                   is_correct=True, position=0),
            Choice(question_id=question.id, body_html=WRONG,
                   is_correct=False, position=1),
            Choice(question_id=question.id, body_html="Another distractor",
                   is_correct=False, position=2),
        ])
        db.session.commit()
    db.session.refresh(question)
    return question


@pytest.fixture
def questions(app, subject):
    return [make_question(subject, index=i,
                          topic="Algebra" if i < 3 else "Geometry")
            for i in range(6)]


@pytest.fixture
def exam(app, subject, questions):
    item = Exam(
        title="JAMB Mathematics practice", slug="jamb-maths-practice",
        exam_type="jamb", subject_id=subject.id,
        duration_minutes=30, question_count=5,
        randomise_questions=False, randomise_choices=False,
        max_attempts=None, result_visibility=ResultVisibility.IMMEDIATE,
        is_published=True,
    )
    db.session.add(item)
    db.session.commit()
    return item


def make_student(email="candidate@example.com"):
    result = accounts.register(
        email=email, full_name="Ada Okoro",
        password="correct-horse-battery", role_name=RoleName.STUDENT,
        date_of_birth=date(1998, 5, 1),
    )
    accounts.mark_email_verified(result.user)
    return result.user


@pytest.fixture
def student(app):
    return make_student()


def correct_choice_id(question: Question) -> int:
    return next(c.id for c in question.choices if c.is_correct)


def wrong_choice_id(question: Question) -> int:
    return next(c.id for c in question.choices if not c.is_correct)


# ---------------------------------------------------------------------------
# Starting
# ---------------------------------------------------------------------------

def test_starting_freezes_the_paper_and_the_clock(app, exam, student):
    attempt = cbt.start_attempt(student, exam)

    assert attempt.status == AttemptStatus.IN_PROGRESS
    assert len(attempt.questions) == exam.question_count
    # The deadline is computed from the exam, on the server.
    expected = attempt.started_at + timedelta(minutes=exam.duration_minutes)
    assert abs((attempt.expires_at - expected).total_seconds()) < 2


def test_returning_resumes_rather_than_consuming_another_attempt(app, exam,
                                                                 student):
    """A refresh must not burn an attempt."""
    first = cbt.start_attempt(student, exam)
    second = cbt.start_attempt(student, exam)
    assert first.id == second.id
    assert db.session.query(Attempt).count() == 1


def test_only_active_questions_are_drawn(app, subject, student):
    """A bank row starts inactive so nothing unreviewed reaches anyone."""
    for i in range(3):
        make_question(subject, index=i, active=False)
    active = make_question(subject, index=99, active=True)

    exam = Exam(title="Practice", slug="practice", exam_type="jamb",
                subject_id=subject.id, duration_minutes=10,
                question_count=10, is_published=True)
    db.session.add(exam)
    db.session.commit()

    attempt = cbt.start_attempt(student, exam)
    drawn = {link.question_id for link in attempt.questions}
    assert drawn == {active.id}


def test_a_paper_with_no_questions_refuses_rather_than_serving_a_blank(
        app, subject, student):
    exam = Exam(title="Empty", slug="empty", exam_type="waec",
                subject_id=subject.id, duration_minutes=10,
                question_count=5, is_published=True)
    db.session.add(exam)
    db.session.commit()

    with pytest.raises(cbt.CbtError, match="no questions"):
        cbt.start_attempt(student, exam)


def test_the_paper_does_not_change_underneath_a_candidate(app, exam,
                                                          subject, student):
    """Editing the bank mid-attempt must not alter a paper being sat."""
    attempt = cbt.start_attempt(student, exam)
    original = [link.question_id for link in attempt.questions]

    make_question(subject, index=100)
    for question in db.session.query(Question).all():
        question.is_active = False
    db.session.commit()
    db.session.refresh(attempt)

    assert [link.question_id for link in attempt.questions] == original


# ---------------------------------------------------------------------------
# Attempt limits
# ---------------------------------------------------------------------------

def test_attempt_limits_are_enforced(app, exam, student):
    exam.max_attempts = 2
    db.session.commit()

    first = cbt.start_attempt(student, exam)
    cbt.submit(first)
    second = cbt.start_attempt(student, exam)
    cbt.submit(second)

    eligibility = cbt.can_start(student, exam)
    assert not eligibility.allowed
    assert eligibility.reason == "no_attempts_left"

    with pytest.raises(cbt.CbtError, match="all 2 attempts"):
        cbt.start_attempt(student, exam)


def test_an_abandoned_attempt_still_counts(app, exam, student):
    """Otherwise: start, read the paper, walk away, start again."""
    exam.max_attempts = 1
    db.session.commit()

    attempt = cbt.start_attempt(student, exam)
    attempt.status = AttemptStatus.ABANDONED
    db.session.commit()

    assert not cbt.can_start(student, exam).allowed


def test_unlimited_attempts_when_no_limit_is_set(app, exam, student):
    for _ in range(4):
        attempt = cbt.start_attempt(student, exam)
        cbt.submit(attempt)
    assert cbt.can_start(student, exam).allowed


# ---------------------------------------------------------------------------
# The clock
# ---------------------------------------------------------------------------

def test_an_answer_after_the_deadline_is_refused(app, exam, student,
                                                 questions):
    attempt = cbt.start_attempt(student, exam)
    question_id = attempt.questions[0].question_id

    # Wind the stored deadline into the past, which is the only clock
    # that matters.
    attempt.expires_at = utcnow() - timedelta(seconds=1)
    db.session.commit()

    with pytest.raises(cbt.CbtError, match="closed"):
        cbt.save_answer(attempt, question_id=question_id, choice_ids=[1])


def test_an_expired_attempt_is_auto_submitted_with_what_was_saved(
        app, exam, student, questions):
    attempt = cbt.start_attempt(student, exam)
    first = attempt.questions[0].question
    cbt.save_answer(attempt, question_id=first.id,
                    choice_ids=[correct_choice_id(first)])

    attempt.expires_at = utcnow() - timedelta(seconds=1)
    db.session.commit()

    cbt.enforce_deadline(attempt)

    assert attempt.status == AttemptStatus.EXPIRED
    assert attempt.submitted_at is not None
    assert attempt.score == 1          # the saved answer still counted


def test_seconds_remaining_never_goes_negative(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    attempt.expires_at = utcnow() - timedelta(hours=3)
    db.session.commit()
    assert cbt.seconds_remaining(attempt) == 0


def test_leaving_and_returning_does_not_grant_more_time(app, exam, student):
    """The deadline is stored, not derived from when the page loads."""
    attempt = cbt.start_attempt(student, exam)
    deadline = attempt.expires_at

    cbt.enforce_deadline(attempt)
    db.session.refresh(attempt)
    assert attempt.expires_at == deadline


# ---------------------------------------------------------------------------
# Answering
# ---------------------------------------------------------------------------

def test_answering_is_idempotent_per_question(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    question = attempt.questions[0].question

    cbt.save_answer(attempt, question_id=question.id,
                    choice_ids=[wrong_choice_id(question)])
    cbt.save_answer(attempt, question_id=question.id,
                    choice_ids=[correct_choice_id(question)])

    rows = db.session.query(Answer).filter_by(attempt_id=attempt.id).all()
    assert len(rows) == 1
    assert rows[0].selected_choice_ids == [correct_choice_id(question)]


def test_a_question_not_on_the_paper_is_refused(app, exam, subject, student):
    """Answering an unseen question would be a way to probe the bank."""
    attempt = cbt.start_attempt(student, exam)
    outsider = make_question(subject, index=500)

    with pytest.raises(cbt.CbtError, match="not on this paper"):
        cbt.save_answer(attempt, question_id=outsider.id, choice_ids=[1])


def test_choices_from_another_question_are_discarded(app, exam, student,
                                                     questions):
    """A crafted request must not attach another question's choice ids."""
    attempt = cbt.start_attempt(student, exam)
    mine = attempt.questions[0].question
    other = attempt.questions[1].question

    answer = cbt.save_answer(
        attempt, question_id=mine.id,
        choice_ids=[correct_choice_id(mine), correct_choice_id(other)],
    )
    assert answer.selected_choice_ids == [correct_choice_id(mine)]


def test_flagging_is_recorded_without_answering(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    question = attempt.questions[0].question

    answer = cbt.save_answer(attempt, question_id=question.id, flagged=True)
    assert answer.is_flagged
    assert not answer.is_answered


# ---------------------------------------------------------------------------
# The answer key never leaks
# ---------------------------------------------------------------------------

def test_the_presented_paper_carries_no_correct_flags(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    paper = cbt.present_paper(attempt)

    serialised = json.dumps([
        {"stem": q.stem_html,
         "choices": [{"id": c.id, "body": c.body_html} for c in q.choices]}
        for q in paper
    ])
    assert "is_correct" not in serialised
    assert "explanation" not in serialised


def test_an_open_attempt_page_does_not_contain_the_answers(
        client, app, exam, student, sign_in):
    """The whole point: the page a candidate is looking at."""
    attempt = cbt.start_attempt(student, exam)
    sign_in(student)

    body = client.get(f"/cbt/attempt/{attempt.public_id}").get_data(
        as_text=True)

    assert "Question 0" in body            # the paper rendered
    assert "is_correct" not in body
    assert "Because of reason" not in body  # no explanations mid-attempt


def test_answers_are_not_marked_while_the_attempt_is_open(app, exam,
                                                          student):
    """A row carrying is_correct mid-attempt would be readable evidence."""
    attempt = cbt.start_attempt(student, exam)
    question = attempt.questions[0].question
    answer = cbt.save_answer(attempt, question_id=question.id,
                             choice_ids=[correct_choice_id(question)])
    assert answer.is_correct is None


# ---------------------------------------------------------------------------
# Marking
# ---------------------------------------------------------------------------

def test_marking_counts_only_correct_answers(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    links = list(attempt.questions)

    for link in links[:3]:
        cbt.save_answer(attempt, question_id=link.question_id,
                        choice_ids=[correct_choice_id(link.question)])
    for link in links[3:]:
        cbt.save_answer(attempt, question_id=link.question_id,
                        choice_ids=[wrong_choice_id(link.question)])

    cbt.submit(attempt)
    assert attempt.score == 3
    assert attempt.total == 5
    assert attempt.percent == 60


def test_an_unanswered_question_is_wrong_not_skipped(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    cbt.submit(attempt)
    assert attempt.score == 0
    assert attempt.total == 5


def test_a_multiple_answer_question_must_match_exactly(app, subject,
                                                        student):
    question = make_question(subject, index=1, kind=QuestionKind.MULTIPLE)
    second = question.choices[1]
    second.is_correct = True
    db.session.commit()

    exam = Exam(title="Multi", slug="multi", exam_type="jamb",
                subject_id=subject.id, duration_minutes=10,
                question_count=1, is_published=True)
    db.session.add(exam)
    db.session.commit()

    attempt = cbt.start_attempt(student, exam)
    # Only one of the two correct choices: not partly right.
    cbt.save_answer(attempt, question_id=question.id,
                    choice_ids=[correct_choice_id(question)])
    cbt.submit(attempt)
    assert attempt.score == 0


def test_a_numeric_answer_honours_its_tolerance(app, subject, student):
    question = make_question(subject, index=2, kind=QuestionKind.NUMERIC,
                             correct_value="3.142")
    question.numeric_tolerance = 0.01
    db.session.commit()

    exam = Exam(title="Numeric", slug="numeric", exam_type="jamb",
                subject_id=subject.id, duration_minutes=10,
                question_count=1, is_published=True)
    db.session.add(exam)
    db.session.commit()

    attempt = cbt.start_attempt(student, exam)
    cbt.save_answer(attempt, question_id=question.id, value="3.14")
    cbt.submit(attempt)
    assert attempt.score == 1


def test_nonsense_in_a_numeric_answer_does_not_crash_marking(app, subject,
                                                              student):
    question = make_question(subject, index=3, kind=QuestionKind.NUMERIC,
                             correct_value="10")
    exam = Exam(title="Numeric2", slug="numeric2", exam_type="jamb",
                subject_id=subject.id, duration_minutes=10,
                question_count=1, is_published=True)
    db.session.add(exam)
    db.session.commit()

    attempt = cbt.start_attempt(student, exam)
    cbt.save_answer(attempt, question_id=question.id, value="not a number")
    cbt.submit(attempt)
    assert attempt.score == 0


def test_submitting_twice_does_not_re_mark(app, exam, student):
    """A double-click must not be able to alter a recorded score."""
    attempt = cbt.start_attempt(student, exam)
    link = attempt.questions[0]
    cbt.save_answer(attempt, question_id=link.question_id,
                    choice_ids=[correct_choice_id(link.question)])
    cbt.submit(attempt)

    recorded = attempt.score
    submitted_at = attempt.submitted_at

    # Change an answer directly, then re-submit.
    attempt.answers[0].selected_choice_ids = [
        wrong_choice_id(link.question)
    ]
    db.session.commit()
    cbt.submit(attempt)

    assert attempt.score == recorded
    assert attempt.submitted_at == submitted_at


def test_the_topic_breakdown_says_what_to_revise(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    for link in attempt.questions:
        if link.question.topic == "Algebra":
            cbt.save_answer(attempt, question_id=link.question_id,
                            choice_ids=[correct_choice_id(link.question)])
    cbt.submit(attempt)

    topics = cbt.topic_results(attempt)
    assert topics, "a result must say which topics were weak"
    # Weakest first.
    assert topics[0].percent <= topics[-1].percent
    assert {t.topic for t in topics} == {"Algebra", "Geometry"}


# ---------------------------------------------------------------------------
# Result visibility
# ---------------------------------------------------------------------------

def test_immediate_results_show_everything(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    cbt.submit(attempt)
    view = cbt.result_view(attempt)
    assert view.show_score and view.show_answers and view.show_explanations


def test_score_only_withholds_the_answers(app, exam, student):
    exam.result_visibility = ResultVisibility.SCORE_ONLY
    db.session.commit()
    attempt = cbt.start_attempt(student, exam)
    cbt.submit(attempt)

    view = cbt.result_view(attempt)
    assert view.show_score
    assert not view.show_answers


def test_after_close_withholds_until_the_paper_closes(app, exam, student):
    """Otherwise the first to finish tells everyone else the answers."""
    exam.result_visibility = ResultVisibility.AFTER_CLOSE
    exam.closes_at = utcnow() + timedelta(days=1)
    db.session.commit()

    attempt = cbt.start_attempt(student, exam)
    cbt.submit(attempt)
    assert not cbt.result_view(attempt).show_score

    exam.closes_at = utcnow() - timedelta(seconds=1)
    db.session.commit()
    assert cbt.result_view(attempt).show_score


def test_an_open_attempt_shows_no_result(app, exam, student):
    attempt = cbt.start_attempt(student, exam)
    assert not cbt.result_view(attempt).show_score


def test_the_result_page_withholds_answers_when_not_permitted(
        client, app, exam, student, sign_in):
    exam.result_visibility = ResultVisibility.SCORE_ONLY
    db.session.commit()
    attempt = cbt.start_attempt(student, exam)
    cbt.submit(attempt)
    sign_in(student)

    body = client.get(
        f"/cbt/attempt/{attempt.public_id}/result").get_data(as_text=True)
    assert "Because of reason" not in body


# ---------------------------------------------------------------------------
# Routes and ownership
# ---------------------------------------------------------------------------

def test_anonymous_cannot_sit_a_paper(client, app, exam):
    response = client.post(f"/cbt/{exam.slug}/start")
    assert response.status_code in (302, 401)


def test_nobody_can_open_another_candidates_attempt(client, app, exam,
                                                    student, sign_in):
    """404, not 403: confirming the id exists tells an attacker it does."""
    attempt = cbt.start_attempt(student, exam)
    intruder = make_student("intruder@example.com")
    sign_in(intruder)

    assert client.get(
        f"/cbt/attempt/{attempt.public_id}").status_code == 404
    assert client.get(
        f"/cbt/attempt/{attempt.public_id}/result").status_code == 404


def test_nobody_can_answer_another_candidates_attempt(client, app, exam,
                                                      student, sign_in):
    attempt = cbt.start_attempt(student, exam)
    question_id = attempt.questions[0].question_id
    intruder = make_student("intruder@example.com")
    sign_in(intruder)

    response = client.post(
        f"/cbt/attempt/{attempt.public_id}/answer",
        json={"question_id": question_id, "choice_ids": [1]},
    )
    assert response.status_code == 404
    assert db.session.query(Answer).count() == 0


def test_autosave_returns_the_server_clock(client, app, exam, student,
                                           sign_in):
    """The client re-syncs from this, so a sleeping tab corrects itself."""
    attempt = cbt.start_attempt(student, exam)
    sign_in(student)

    response = client.post(
        f"/cbt/attempt/{attempt.public_id}/answer",
        json={"question_id": attempt.questions[0].question_id,
              "choice_ids": []},
    )
    assert response.status_code == 200
    payload = response.get_json()
    assert payload["ok"] is True
    assert 0 < payload["seconds_remaining"] <= exam.duration_minutes * 60


def test_autosave_after_expiry_is_refused_with_409(client, app, exam,
                                                    student, sign_in):
    attempt = cbt.start_attempt(student, exam)
    attempt.expires_at = utcnow() - timedelta(seconds=1)
    db.session.commit()
    sign_in(student)

    response = client.post(
        f"/cbt/attempt/{attempt.public_id}/answer",
        json={"question_id": attempt.questions[0].question_id,
              "choice_ids": [1]},
    )
    assert response.status_code == 409
    assert response.get_json()["closed"] is True


def test_opening_an_expired_attempt_redirects_to_the_result(
        client, app, exam, student, sign_in):
    attempt = cbt.start_attempt(student, exam)
    attempt.expires_at = utcnow() - timedelta(seconds=1)
    db.session.commit()
    sign_in(student)

    response = client.get(f"/cbt/attempt/{attempt.public_id}",
                          follow_redirects=False)
    assert response.status_code == 302
    assert "result" in response.headers["Location"]

    db.session.refresh(attempt)
    assert attempt.status == AttemptStatus.EXPIRED


def test_a_malformed_autosave_payload_is_a_400_not_a_500(client, app, exam,
                                                          student, sign_in):
    attempt = cbt.start_attempt(student, exam)
    sign_in(student)

    response = client.post(f"/cbt/attempt/{attempt.public_id}/answer",
                           json={"question_id": "not-a-number"})
    assert response.status_code == 400


def test_a_paper_gated_by_an_offering_needs_payment(app, exam, student):
    from app.models.payments import Offering

    offering = Offering(title="JAMB Online", slug="jamb-online-cbt",
                        programme_slug="jamb", mode="online",
                        price_kobo=5_000_000, is_published=True)
    db.session.add(offering)
    db.session.commit()
    exam.offering_id = offering.id
    db.session.commit()

    eligibility = cbt.can_start(student, exam)
    assert not eligibility.allowed
    assert eligibility.reason == "not_enrolled"


# ---------------------------------------------------------------------------
# CSRF on the autosave endpoint
#
# Regression cover for a real defect. The suite runs with
# WTF_CSRF_ENABLED = False, so every autosave test passed while the
# feature was completely broken in the running application: the JSON
# fetch carried no CSRF token and every save came back 400. These tests
# turn CSRF back on for the duration, which is the only way to see it.
# ---------------------------------------------------------------------------

@pytest.fixture
def csrf_on(app):
    app.config["WTF_CSRF_ENABLED"] = True
    try:
        yield
    finally:
        app.config["WTF_CSRF_ENABLED"] = False


def test_the_paper_page_exposes_a_csrf_token_for_autosave(
        client, app, exam, student, sign_in):
    """Autosave posts JSON, so the token cannot come from a form field."""
    attempt = cbt.start_attempt(student, exam)
    sign_in(student)

    body = client.get(f"/cbt/attempt/{attempt.public_id}").get_data(
        as_text=True)
    assert 'name="csrf-token"' in body


def test_autosave_without_a_csrf_token_is_rejected(client, app, exam,
                                                   student, sign_in, csrf_on):
    attempt = cbt.start_attempt(student, exam)
    sign_in(student)

    response = client.post(
        f"/cbt/attempt/{attempt.public_id}/answer",
        json={"question_id": attempt.questions[0].question_id,
              "choice_ids": []},
    )
    assert response.status_code == 400


def test_autosave_with_the_csrf_header_succeeds(client, app, exam, student,
                                                sign_in, csrf_on):
    """The shape the browser actually sends: X-CSRFToken, no form."""
    attempt = cbt.start_attempt(student, exam)
    sign_in(student)

    # The token has to come from the page itself: it is tied to the
    # session that rendered it.
    page = client.get(
        f"/cbt/attempt/{attempt.public_id}").get_data(as_text=True)
    match = re.search(r'name="csrf-token" content="([^"]+)"', page)
    assert match, "the page must publish a token the client can send"

    response = client.post(
        f"/cbt/attempt/{attempt.public_id}/answer",
        json={"question_id": attempt.questions[0].question_id,
              "choice_ids": []},
        headers={"X-CSRFToken": match.group(1)},
    )
    assert response.status_code == 200, response.get_data(as_text=True)[:200]
    assert response.get_json()["ok"] is True
