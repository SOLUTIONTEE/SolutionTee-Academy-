"""Public routes: they resolve, they are complete, and they are honest.

These are the tests that would have caught the real defects found during
visual review - a panel that ignored `hidden`, grid offsets that
collapsed to one column, a CSP that blocked the page's own script. The
markup-level invariants are asserted here so a future edit cannot
silently undo them.
"""
from __future__ import annotations

import pathlib
import re

import pytest

from app import content


# ---------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------

def test_home_renders(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"Learn." in response.data


@pytest.mark.parametrize("programme", content.PROGRAMMES, ids=lambda p: p.slug)
def test_every_programme_has_a_page(client, programme):
    response = client.get(f"/programmes/{programme.slug}")
    assert response.status_code == 200
    assert programme.full_name.encode() in response.data


@pytest.mark.parametrize("mode", content.LEARNING_MODES, ids=lambda m: m.slug)
def test_every_learning_mode_has_a_page(client, mode):
    response = client.get(f"/learning/{mode.slug}")
    assert response.status_code == 200


def test_unknown_path_is_404(client):
    assert client.get("/no-such-page").status_code == 404
    assert client.get("/programmes/no-such-programme").status_code == 404


def _navigation_paths() -> set[str]:
    seen = set()
    for group in content.PRIMARY_NAV + content.FOOTER_NAV:
        if group.path:
            seen.add(group.path)
        for item in group.items:
            seen.add(item.path)
    return seen


def test_every_navigation_link_resolves(client):
    """Walk the real navigation structure rather than a hand-written list.

    Redirects are followed: a link that 308s to its canonical URL has
    reached a working page, which is the property that matters. What must
    never happen is a navigation link leading to a dead end.
    """
    broken = {
        path: client.get(path, follow_redirects=True).status_code
        for path in sorted(_navigation_paths())
        if client.get(path, follow_redirects=True).status_code != 200
    }
    assert broken == {}, f"navigation links that do not resolve: {broken}"


def test_no_destination_is_still_a_stub(client):
    """Every page in the navigation is a real page.

    Replaces an older parametrised test over a table of "not built yet"
    destinations: that table is now empty and the catch-all route that
    served it is gone. This asserts the stub page never reappears on a
    linked destination.
    """
    stubbed = [
        path for path in sorted(_navigation_paths())
        if b"Not built yet" in client.get(path, follow_redirects=True).data
    ]
    assert stubbed == [], f"still showing a stub page: {stubbed}"


# ---------------------------------------------------------------------------
# Security headers
# ---------------------------------------------------------------------------

def test_security_headers_present(client):
    headers = client.get("/").headers
    assert "Content-Security-Policy" in headers
    assert headers["X-Content-Type-Options"] == "nosniff"
    assert headers["X-Frame-Options"] == "DENY"
    assert headers["Referrer-Policy"] == "strict-origin-when-cross-origin"


def test_csp_denies_framing_and_inline_objects(client):
    csp = client.get("/").headers["Content-Security-Policy"]
    assert "frame-ancestors 'none'" in csp
    assert "object-src 'none'" in csp
    assert "default-src 'self'" in csp


def test_health_check_reports_database_separately(client):
    """Railway needs to tell a dead app from an unreachable database."""
    response = client.get("/healthz")
    assert response.status_code in (200, 503)
    payload = response.get_json()
    assert payload["status"] in ("ok", "degraded")
    assert payload["database"] in ("ok", "unavailable")


# ---------------------------------------------------------------------------
# Content-Security-Policy and the inline theme script
#
# Regression cover for a real defect: the CSP blocked the page's own
# pre-paint theme script, which left <html class="no-js"> in place. That
# hid the theme toggle entirely and reintroduced the white flash the
# script exists to prevent - with nothing failing loudly to show it.
# ---------------------------------------------------------------------------

def test_inline_script_carries_a_nonce_the_csp_allows(client):
    response = client.get("/")
    body = response.get_data(as_text=True)
    csp = response.headers["Content-Security-Policy"]

    match = re.search(r'<script nonce="([^"]+)"', body)
    assert match, "the pre-paint theme script must carry a nonce"
    nonce = match.group(1)
    assert nonce, "the nonce must not be empty"
    assert f"'nonce-{nonce}'" in csp, (
        "the CSP does not allow the nonce the page actually rendered"
    )


def test_csp_does_not_open_up_to_all_inline_script(client):
    csp = client.get("/").headers["Content-Security-Policy"]
    assert "unsafe-inline" not in csp
    assert "unsafe-eval" not in csp


def test_nonce_differs_between_requests(client):
    """A reused nonce is worth no more than 'unsafe-inline'."""
    first = re.search(r'<script nonce="([^"]+)"',
                      client.get("/").get_data(as_text=True)).group(1)
    second = re.search(r'<script nonce="([^"]+)"',
                       client.get("/").get_data(as_text=True)).group(1)
    assert first != second


def test_every_inline_script_is_nonced(client):
    """An un-nonced inline script is dead code under this policy."""
    body = client.get("/").get_data(as_text=True)
    for match in re.finditer(r"<script(?![^>]*\bsrc=)[^>]*>", body):
        assert "nonce=" in match.group(0), (
            f"inline script without a nonce will be blocked: {match.group(0)}"
        )


# ---------------------------------------------------------------------------
# Accessibility and markup invariants
# ---------------------------------------------------------------------------

def test_page_has_one_h1_and_a_skip_link(client):
    body = client.get("/").get_data(as_text=True)
    assert body.count("<h1") == 1, "exactly one h1 per page"
    assert 'class="skip-link"' in body
    assert 'id="main"' in body


def test_headings_do_not_skip_levels(client):
    body = client.get("/").get_data(as_text=True)
    levels = [int(m) for m in re.findall(r"<h([1-6])[ >]", body)]
    for previous, current in zip(levels, levels[1:]):
        assert current - previous <= 1, (
            f"heading jumps from h{previous} to h{current}"
        )


def test_collapsed_panels_are_hidden_not_merely_styled(client):
    """Every disclosure ships closed, with `hidden` on the panel.

    A panel that is only visually hidden stays in the accessibility tree
    and is announced to screen readers as though it were open.
    """
    body = client.get("/").get_data(as_text=True)
    for attr in ("data-nav-panel", "data-menu-panel", "data-disclosure-panel"):
        for match in re.finditer(rf"<[^>]*{attr}[^>]*>", body):
            assert "hidden" in match.group(0), (
                f"{attr} rendered without the hidden attribute"
            )


def test_toggles_declare_their_initial_state(client):
    body = client.get("/").get_data(as_text=True)
    for attr in ("data-nav-trigger", "data-menu-open",
                 "data-disclosure-trigger"):
        for match in re.finditer(rf"<[^>]*{attr}[^>]*>", body):
            assert 'aria-expanded="false"' in match.group(0)
            assert "aria-controls" in match.group(0)


def test_icon_buttons_have_accessible_names(client):
    """An icon-only control needs a label; its SVG is decorative."""
    body = client.get("/").get_data(as_text=True)
    for match in re.finditer(
            r"<button[^>]*class=\"[^\"]*icon-btn[^\"]*\"[^>]*>", body):
        assert "aria-label" in match.group(0)


def test_meta_description_and_canonical_are_set(client):
    body = client.get("/").get_data(as_text=True)
    assert '<meta name="description"' in body
    assert '<link rel="canonical"' in body


def test_index_rows_put_the_detail_on_its_own_line():
    """Regression: both were inline, so the detail ran on after the name.

    It only looked right while every name happened to be long enough to
    wrap, and `margin-block-start` on an inline element does nothing.
    Asserted in CSS rather than in a browser because that is where the
    bug was.
    """
    css = pathlib.Path("app/static/css/components.css").read_text(
        encoding="utf-8")
    name_rule = css.split(".index__name {")[1].split("}")[0]
    detail_rule = css.split(".index__detail {")[1].split("}")[0]
    assert "display: block" in name_rule
    assert "display: block" in detail_rule


# ---------------------------------------------------------------------------
# The header reflects who is looking at it
#
# Regression cover for a real defect: the header offered "Sign in" and
# "Create account" to everybody, including people who were already signed
# in, with no way to sign out. The first fix then linked to an account
# page that did not exist, which would have raised a BuildError on every
# page for an authenticated user - so both states are asserted here.
# ---------------------------------------------------------------------------

def test_an_anonymous_visitor_is_offered_a_way_in(client):
    body = client.get("/").get_data(as_text=True)
    assert "Sign in" in body
    assert "Create account" in body


def test_a_signed_in_visitor_is_offered_a_way_out(client, sign_in,
                                                  student_user):
    sign_in(student_user)
    body = client.get("/").get_data(as_text=True)

    assert "Sign out" in body
    # And a way in to their own account, not just a way out.
    assert "/dashboard/" in body
    # Inviting somebody to create an account they already have is noise.
    assert "Create account" not in body


def test_every_page_renders_for_a_signed_in_user(client, sign_in,
                                                 student_user):
    """A bad url_for in the shared header breaks the whole site at once."""
    sign_in(student_user)
    broken = {
        path: client.get(path, follow_redirects=True).status_code
        for path in ("/", "/programmes", "/programmes/jamb", "/learning",
                     "/academy/", "/cbt/", "/cbt/mock", "/contact",
                     "/about", "/parents", "/updates/", "/admission/",
                     "/registration", "/resources", "/enrol")
        if client.get(path, follow_redirects=True).status_code != 200
    }
    assert broken == {}


# ---------------------------------------------------------------------------
# The dashboard
# ---------------------------------------------------------------------------

def test_the_dashboard_needs_a_sign_in(client):
    response = client.get("/dashboard/")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


def test_a_new_student_dashboard_explains_itself(client, sign_in,
                                                 student_user):
    """An empty dashboard must say what would fill it."""
    sign_in(student_user)
    body = client.get("/dashboard/").get_data(as_text=True)
    assert "Nothing here yet" in body
    assert "Explore programmes" in body


# ---------------------------------------------------------------------------
# Honesty
#
# The product rule that matters most: nothing invents a fact. These tests
# fail if a future edit quietly adds a price, a pass rate or a deadline
# that nobody supplied.
# ---------------------------------------------------------------------------

FABRICATION_PATTERNS = [
    (r"₦\s?[\d,]+", "a naira price"),
    (r"\bN[\d,]{4,}", "a naira price"),
    (r"\b\d{1,3}(\.\d+)?%\s*(pass|success|admission)", "a success rate"),
    (r"\b\d[\d,]{2,}\+?\s*(students|candidates|graduates)", "a student count"),
    (r"\b(deadline|closes?)\s+(on\s+)?\d{1,2}\s+\w+\s+20\d\d", "a deadline"),
]


@pytest.mark.parametrize("path", ["/", "/programmes", "/programmes/jamb",
                                  "/learning", "/learning/online",
                                  "/about", "/parents", "/registration",
                                  "/registration/jamb", "/resources"])
def test_pages_state_no_unsupplied_facts(client, path):
    body = client.get(path).get_data(as_text=True)
    for pattern, description in FABRICATION_PATTERNS:
        match = re.search(pattern, body, re.I)
        assert match is None, (
            f"{path} appears to state {description} that was never "
            f"supplied: {match.group(0)!r}"
        )


def test_site_does_not_claim_affiliation_with_examination_boards(client):
    body = client.get("/").get_data(as_text=True).lower()
    for claim in ("official jamb", "jamb accredited", "waec accredited",
                  "in partnership with jamb", "authorised by jamb"):
        assert claim not in body


def test_footer_carries_the_independence_disclaimer(client):
    body = client.get("/").get_data(as_text=True)
    assert "Not affiliated with JAMB" in body


@pytest.mark.parametrize("path", ["/about", "/parents"])
def test_trust_pages_promise_nothing_they_cannot_deliver(client, path):
    """The pages most tempted to overclaim are the ones about us."""
    body = client.get(path).get_data(as_text=True).lower()
    for claim in ("guaranteed", "we guarantee", "100%", "best in nigeria",
                  "number one", "secure your place"):
        assert claim not in body, f"{path} claims: {claim}"


# ---------------------------------------------------------------------------
# The first-visit loader
#
# A full-screen overlay is the most dangerous thing on the site: if it
# ever fails to clear, the page is unreadable and nothing errors. These
# tests assert the two properties that make it safe - it cannot appear
# without JavaScript, and its dismissal does not depend on the external
# script that normally does it.
# ---------------------------------------------------------------------------

def test_the_loader_ships_inert(client):
    """The server never renders the overlay in its visible state.

    Visibility is gated on data-loader, which only the inline head script
    sets. So a visitor with JavaScript off is served an overlay that CSS
    keeps at display:none, rather than one covering the page.
    """
    body = client.get("/").get_data(as_text=True)
    assert 'class="loader"' in body
    # The attribute that reveals it must not be in the served markup.
    assert "data-loader" not in body.split("<body")[1]


def test_the_loader_is_removed_by_a_timer_not_only_by_its_script(client):
    """The backstop lives in the inline head script, not in loader.js.

    A CSS animation was tried first and rejected: an animation only
    advances while the document timeline runs, so a tab that is never
    composited would hold the overlay open. A timer fires regardless.
    """
    body = client.get("/").get_data(as_text=True)
    head = body.split("</head>")[0]
    assert "setTimeout" in head
    assert "removeAttribute('data-loader')" in head


def test_the_loader_never_reaches_the_exam_room(client, sign_in,
                                                 student_user):
    """A splash screen over a timed paper would be indefensible."""
    sign_in(student_user)
    body = client.get("/cbt/").get_data(as_text=True)
    assert 'class="loader"' in body  # the public shell has it

    # The bare shell the paper itself uses does not.
    bare = pathlib.Path("app/templates/layouts/bare.html").read_text(
        encoding="utf-8")
    assert "partials/loader.html" not in bare


def test_the_logo_inverts_through_tokens_rather_than_two_files(client):
    """One mark, themed by custom properties.

    Shipping a light file and a dark file means a flash on load and a
    mark that ignores an explicit theme choice. The colours are asserted
    here because a future edit that hard-codes a hex would silently
    break dark mode.
    """
    body = client.get("/").get_data(as_text=True)
    assert "var(--logo-trace)" in body
    assert "var(--logo-crossbar)" in body

    tokens = pathlib.Path("app/static/css/tokens.css").read_text(
        encoding="utf-8")
    # Defined once for light, and redefined for both dark routes.
    assert tokens.count("--logo-trace:") == 3


# ---------------------------------------------------------------------------
# Motion
#
# Smooth scroll takes ownership of the scroll position. That is a pleasant
# effect on a marketing page and an indefensible one over a timed
# examination, where a candidate who cannot reach question 40 loses marks
# to a decoration. The guard is asserted at the layout level, where it is
# strongest: the paper never even downloads the libraries.
# ---------------------------------------------------------------------------

def test_smooth_scroll_never_reaches_the_exam_paper():
    bare = pathlib.Path("app/templates/layouts/bare.html").read_text(
        encoding="utf-8")
    for asset in ("motion.js", "lenis.min.js", "gsap.min.js",
                  "ScrollTrigger.min.js"):
        assert asset not in bare, (
            f"the CBT paper must not load {asset}: smooth scroll during a "
            f"timed examination can make questions unreachable"
        )


def test_smooth_scroll_never_reaches_the_admin_console():
    """Lenis owns the wheel and a nested scroller never gets it back."""
    admin = pathlib.Path("app/templates/admin/_layout.html").read_text(
        encoding="utf-8")
    for asset in ("motion.js", "lenis.min.js"):
        assert asset not in admin


def test_motion_js_guards_itself_as_well_as_the_layouts(client):
    """Belt and braces: if a future edit adds the script to those shells,
    the script still refuses to start on them."""
    source = pathlib.Path("app/static/js/motion.js").read_text(
        encoding="utf-8")
    assert "'.bare'" in source
    assert "'.admin'" in source
    assert "prefers-reduced-motion" in source


def test_libraries_are_vendored_rather_than_pulled_from_a_cdn(client):
    """The CSP allows script-src 'self'. A CDN would mean widening it."""
    body = client.get("/").get_data(as_text=True)
    csp = client.get("/").headers["Content-Security-Policy"]
    assert "/static/vendor/gsap.min.js" in body
    assert "cdnjs" not in body and "jsdelivr" not in body
    # The policy still names no third-party script origin beyond Turnstile.
    script_src = [d for d in csp.split(";") if d.strip().startswith("script-src")][0]
    assert "unpkg" not in script_src and "jsdelivr" not in script_src


def test_motion_cannot_strand_content_invisible():
    """The reveal animations hide content before showing it.

    That makes them the most dangerous thing on the page: a tween that
    never runs leaves a blank section and raises nothing. The watchdog
    that covers it must not depend on the machinery it is covering -
    requestAnimationFrame is the loop GSAP and Lenis animate from, and the
    native scroll event stops firing entirely once Lenis owns scrolling.
    An interval depends on nothing but the clock.
    """
    source = pathlib.Path("app/static/js/motion.js").read_text(
        encoding="utf-8")

    watchdog = source[source.index("---- Watchdog"):]
    # Comments in this block necessarily name the things it avoids, so the
    # assertions look for CALLS - a trailing paren - not for mentions.
    assert "setInterval(" in watchdog, (
        "the watchdog must run on a timer, not on scroll or rAF"
    )
    assert "requestAnimationFrame(" not in watchdog, (
        "a rescue scheduled on rAF never runs when rAF is the thing that "
        "stalled"
    )
    assert "addEventListener('scroll'" not in watchdog, (
        "Lenis suppresses the native scroll event, so a scroll-bound "
        "rescue is blind on exactly the pages that enable smooth scroll"
    )
    # It reveals on evidence, not on a blind timeout, so a healthy page
    # keeps its animations.
    assert "getBoundingClientRect" in watchdog


# ---------------------------------------------------------------------------
# Brand separation
#
# SolutionTee Edu Academy and SolutionTee TechHub are different products
# and must not read as the same site. The engineering is shared
# deliberately - the motion stack, the dashboard patterns - but the visual
# identity is not, and a future edit that reaches for the other brand's
# typeface would undo that silently.
# ---------------------------------------------------------------------------

def test_edu_does_not_wear_the_techhub_typeface():
    tokens = pathlib.Path("app/static/css/tokens.css").read_text(
        encoding="utf-8")
    assert "Space Grotesk" not in tokens, (
        "Space Grotesk is the TechHub display face; Edu uses a serif so "
        "the two brands do not read as one company"
    )
    assert "Fraunces" in tokens


def test_the_display_face_falls_back_to_a_serif():
    """A sans fallback would change the page's character mid-load."""
    tokens = pathlib.Path("app/static/css/tokens.css").read_text(
        encoding="utf-8")
    block = tokens.split("--font-display:")[1].split(";")[0]
    assert "serif" in block
    assert "sans-serif" not in block


def test_fonts_are_self_hosted_and_licensed():
    fonts = pathlib.Path("app/static/fonts")
    faces = sorted(f.name for f in fonts.glob("*.woff2"))
    assert faces, "no webfonts are present"
    # Every family shipped carries its licence alongside it.
    licences = " ".join(f.name for f in fonts.glob("OFL-*.txt"))
    assert "Fraunces" in licences
    assert "Inter" in licences

    tokens = pathlib.Path("app/static/css/tokens.css").read_text(
        encoding="utf-8")
    assert "fonts.googleapis" not in tokens
    assert "fonts.gstatic" not in tokens


def test_dashboard_section_numbers_never_skip(client, sign_in, student_user):
    """The eyebrow index is wayfinding, not decoration.

    Every section on the dashboard is conditional, so hard-coded numbers
    skipped as soon as one was hidden: a student with an unpaid enrolment
    saw 01, 03, 04, 05. The numbers must count what actually rendered.
    """
    sign_in(student_user)
    body = client.get("/dashboard/").get_data(as_text=True)

    indices = re.findall(r'class="eyebrow__index">([^<]+)</span>', body)
    numbered = [i.strip() for i in indices if i.strip().isdigit()]

    assert numbered == [f"{n:02d}" for n in range(1, len(numbered) + 1)], (
        f"dashboard section numbers are not sequential: {numbered}"
    )


# ---------------------------------------------------------------------------
# One door
#
# Administrators, tutors, parents and candidates all sign in on the same
# page. There is no separate staff login, and adding one later would be a
# regression: the routing after sign-in is what differs, not the form.
# ---------------------------------------------------------------------------

def test_there_is_exactly_one_sign_in_page(app):
    paths = {
        str(rule) for rule in app.url_map.iter_rules()
        if any(word in str(rule).lower()
               for word in ("login", "signin", "sign-in"))
    }
    assert paths == {"/login"}, f"more than one way in: {sorted(paths)}"


@pytest.mark.parametrize("path", ["/login", "/register", "/forgot"])
def test_auth_pages_use_the_split_shell(client, path):
    body = client.get(path).get_data(as_text=True)
    assert '<body class="auth">' in body
    # Its own slim bar, not the site navigation competing with the form.
    assert 'class="auth__bar"' in body
    assert 'class="megamenu"' not in body


def test_the_sign_in_page_says_it_is_for_everybody(client):
    """The question gets asked constantly, so the page answers it."""
    body = client.get("/login").get_data(as_text=True)
    for audience in ("Candidates", "Parents", "Tutors", "Staff"):
        assert audience in body
    assert "no separate administrator sign-in" in body


def test_the_auth_shell_keeps_smooth_scroll_off(client):
    """Lenis owns the scroll position and has been seen pinning short
    forms at zero, putting the links underneath out of reach."""
    body = client.get("/login").get_data(as_text=True)
    assert "motion.js" not in body
    assert "lenis.min.js" not in body
