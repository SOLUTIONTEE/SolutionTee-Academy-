"""Admin media routes: authorisation, upload handling and file serving.

Authorisation is asserted at the route, not at the template. A hidden
button is presentation; these tests check that the request itself is
refused.
"""
from __future__ import annotations

import io

import pytest

from app.extensions import db
from app.models.media import Media
from app.services import media as media_service
from app.services.rbac import has_permission, permissions_for
from tests.conftest import make_image_bytes


@pytest.fixture
def stored_image(app, admin_user):
    return media_service.upload_image(
        make_image_bytes(1400, 1000), "classroom.jpg",
        uploaded_by_id=admin_user.id, max_bytes=10**7,
    )


def post_image(client, data=None, filename="photo.jpg"):
    payload = data if data is not None else make_image_bytes(900, 600)
    return client.post(
        "/admin/media/upload",
        data={"file": (io.BytesIO(payload), filename)},
        content_type="multipart/form-data",
    )


# ---------------------------------------------------------------------------
# Anonymous access
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("path", [
    "/admin/media/", "/admin/media/picker",
])
def test_anonymous_cannot_reach_the_library(client, path):
    response = client.get(path)
    assert response.status_code in (401, 302)


def test_anonymous_cannot_upload(client):
    assert post_image(client).status_code in (401, 302)


def test_anonymous_cannot_delete(client, stored_image):
    response = client.post(
        f"/admin/media/{stored_image.public_id}/delete"
    )
    assert response.status_code in (401, 302)
    assert db.session.query(Media).count() == 1


# ---------------------------------------------------------------------------
# Role boundaries
# ---------------------------------------------------------------------------

def test_a_student_is_refused_outright(client, sign_in, student_user):
    sign_in(student_user)
    assert client.get("/admin/media/").status_code == 403
    assert post_image(client).status_code == 403


def test_a_student_holds_no_media_permissions(app, student_user):
    assert permissions_for(student_user) == frozenset()


def test_an_instructor_may_view_and_upload_but_not_edit(client, sign_in,
                                                        instructor_user,
                                                        stored_image):
    sign_in(instructor_user)

    assert client.get("/admin/media/").status_code == 200
    assert post_image(client, filename="tutor-upload.jpg").status_code == 200

    # Editing metadata is a separate permission an instructor lacks.
    response = client.post(
        f"/admin/media/{stored_image.public_id}/edit",
        data={"alt_text": "should not apply"},
    )
    assert response.status_code == 403
    db.session.refresh(stored_image)
    assert stored_image.alt_text == ""


def test_an_instructor_cannot_delete(client, sign_in, instructor_user,
                                     stored_image):
    sign_in(instructor_user)
    response = client.post(f"/admin/media/{stored_image.public_id}/delete")
    assert response.status_code == 403
    assert db.session.query(Media).count() == 1


def test_an_admin_may_edit_and_delete(client, sign_in, admin_user,
                                      stored_image):
    sign_in(admin_user)

    response = client.post(
        f"/admin/media/{stored_image.public_id}/edit",
        data={"alt_text": "Students sitting a mock paper", "title": "Mock day",
              "caption": "", "folder": "0"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    db.session.refresh(stored_image)
    assert stored_image.alt_text == "Students sitting a mock paper"

    assert client.post(
        f"/admin/media/{stored_image.public_id}/delete", follow_redirects=True
    ).status_code == 200
    assert db.session.query(Media).count() == 0


# ---------------------------------------------------------------------------
# Deletion protection through the route
# ---------------------------------------------------------------------------

def test_route_refuses_to_delete_an_in_use_image(client, sign_in, admin_user,
                                                 stored_image):
    media_service.record_usage(stored_image, content_type="page",
                               content_id="home", field_name="hero",
                               label="Homepage hero")
    sign_in(admin_user)

    response = client.post(
        f"/admin/media/{stored_image.public_id}/delete",
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"still used in" in response.data
    assert db.session.query(Media).count() == 1


def test_an_admin_cannot_force_past_the_in_use_check(client, sign_in,
                                                     admin_user,
                                                     stored_image):
    """force_delete is a super-admin permission, so the flag is ignored."""
    media_service.record_usage(stored_image, content_type="page",
                               content_id="home", field_name="hero")
    sign_in(admin_user)
    assert not has_permission(admin_user, "media.force_delete")

    client.post(f"/admin/media/{stored_image.public_id}/delete",
                data={"force": "1"}, follow_redirects=True)
    assert db.session.query(Media).count() == 1


def test_a_super_admin_can_force_delete(client, sign_in, super_admin_user,
                                        stored_image):
    media_service.record_usage(stored_image, content_type="page",
                               content_id="home", field_name="hero")
    sign_in(super_admin_user)

    client.post(f"/admin/media/{stored_image.public_id}/delete",
                data={"force": "1"}, follow_redirects=True)
    assert db.session.query(Media).count() == 0


def test_a_suspended_admin_loses_every_permission(app, client, sign_in,
                                                  admin_user):
    from app.models.enums import AccountStatus

    admin_user.status = AccountStatus.SUSPENDED
    db.session.commit()

    assert permissions_for(admin_user) == frozenset()
    sign_in(admin_user)
    assert client.get("/admin/media/").status_code in (401, 403, 302)


# ---------------------------------------------------------------------------
# Upload endpoint
# ---------------------------------------------------------------------------

def test_upload_returns_the_stored_asset(client, sign_in, admin_user):
    sign_in(admin_user)
    response = post_image(client)
    assert response.status_code == 200

    payload = response.get_json()
    assert payload["ok"] is True
    assert payload["media"]["public_id"]
    # A fresh upload has no alt text, and the client is told so it can
    # prompt for one.
    assert payload["media"]["needs_alt_text"] is True


def test_upload_rejects_a_non_image_with_a_readable_reason(client, sign_in,
                                                           admin_user):
    sign_in(admin_user)
    response = post_image(client, data=b"#!/bin/sh\nrm -rf /",
                          filename="evil.jpg")
    assert response.status_code == 422
    assert "not an image" in response.get_json()["error"]
    assert db.session.query(Media).count() == 0


def test_upload_with_no_file_is_a_bad_request(client, sign_in, admin_user):
    sign_in(admin_user)
    response = client.post("/admin/media/upload", data={},
                           content_type="multipart/form-data")
    assert response.status_code == 400


def test_upload_records_an_audit_entry(client, sign_in, admin_user):
    from app.models.security import AuditLog

    sign_in(admin_user)
    post_image(client)

    entry = db.session.query(AuditLog).one()
    assert entry.action == "media.upload"
    assert entry.actor_user_id == admin_user.id


# ---------------------------------------------------------------------------
# Library rendering
# ---------------------------------------------------------------------------

def test_library_shows_an_empty_state_before_anything_is_uploaded(
        client, sign_in, admin_user):
    sign_in(admin_user)
    response = client.get("/admin/media/")
    assert b"No images yet" in response.data


def test_search_with_no_results_differs_from_an_empty_library(
        client, sign_in, admin_user, stored_image):
    sign_in(admin_user)
    response = client.get("/admin/media/?q=nothing-matches-this")
    assert b"Nothing matches" in response.data
    assert b"No images yet" not in response.data


def test_the_grid_flags_images_missing_alt_text(client, sign_in, admin_user,
                                                stored_image):
    sign_in(admin_user)
    assert b"Needs alt text" in client.get("/admin/media/").data

    media_service.update_metadata(stored_image, alt_text="A CBT session")
    assert b"Needs alt text" not in client.get("/admin/media/").data


def test_the_grid_requests_thumbnails_not_originals(client, sign_in,
                                                    admin_user, stored_image):
    """Loading originals into a grid would download megabytes per tile."""
    sign_in(admin_user)
    body = client.get("/admin/media/").get_data(as_text=True)
    assert stored_image.variants["thumb"]["key"] in body
    assert stored_image.object_key not in body


def test_detail_lists_where_an_image_is_used(client, sign_in, admin_user,
                                             stored_image):
    media_service.record_usage(stored_image, content_type="programme",
                               content_id="jamb", field_name="hero",
                               label="JAMB programme")
    sign_in(admin_user)
    body = client.get(f"/admin/media/{stored_image.public_id}").data
    assert b"JAMB programme" in body


def test_unknown_asset_is_404(client, sign_in, admin_user):
    sign_in(admin_user)
    assert client.get("/admin/media/does-not-exist").status_code == 404


# ---------------------------------------------------------------------------
# Serving files
# ---------------------------------------------------------------------------

def test_uploaded_files_are_served_with_nosniff(client, sign_in, admin_user,
                                                stored_image):
    sign_in(admin_user)
    response = client.get(f"/media/{stored_image.object_key}")
    assert response.status_code == 200
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["Content-Disposition"] == "inline"


@pytest.mark.parametrize("attempt", [
    "../../../config.py",
    "..%2f..%2fconfig.py",
    "media/../../../../etc/passwd",
])
def test_path_traversal_through_the_file_route_is_refused(client, attempt):
    response = client.get(f"/media/{attempt}")
    assert response.status_code in (400, 404, 308)


def test_uploads_are_stored_outside_the_served_static_tree(app, stored_image):
    """Uploaded content must never land where the app serves code from."""
    import pathlib

    root = pathlib.Path(app.config["LOCAL_STORAGE_ROOT"]).resolve()
    static = pathlib.Path(app.static_folder).resolve()
    assert static not in root.parents and root != static
